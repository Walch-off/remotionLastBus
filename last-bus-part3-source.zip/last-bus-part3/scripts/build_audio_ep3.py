import json, os, re, subprocess, wave
import numpy as np
from scipy.signal import butter, lfilter
from vosk import Model, KaldiRecognizer, SetLogLevel

SetLogLevel(-1)

RAW_WAV = '/tmp/ep3-ref/ep3_voice_raw.wav'
OUT_DIR = '/tmp/ep3-work/public/audio'
DATA_DIR = '/tmp/ep3-work/src/data'
FFMPEG = '/tmp/ep3-work/node_modules/@remotion/compositor-linux-x64-gnu/ffmpeg'
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

# 1. Load untouched raw WAV (44.1 kHz mono)
with wave.open(RAW_WAV, 'rb') as wf:
    sr = wf.getframerate()
    assert wf.getnchannels() == 1 and wf.getsampwidth() == 2
    raw_pcm = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float64) / 32768.0

raw_dur = len(raw_pcm) / sr
print(f"Loaded untouched raw WAV: {raw_dur:.3f}s @ {sr}Hz")

# Find nearest low-energy zero-crossing in a small window around target raw timestamp
def find_split_sample(sig, sr, t_sec, win=0.12):
    c = int(round(t_sec * sr))
    a = max(1, c - int(win * sr))
    b = min(len(sig) - 2, c + int(win * sr))
    # Prefer quietest 15ms window inside [a, b], then zero crossing
    wlen = int(0.015 * sr)
    best_i = c
    best_e = 1e9
    for i in range(a, b - wlen, int(0.003 * sr)):
        e = float(np.mean(sig[i:i+wlen] ** 2))
        if e < best_e:
            best_e = e
            best_i = i + wlen // 2
    # Snap to nearest zero crossing within +-100 samples
    z0 = max(1, best_i - 100)
    z1 = min(len(sig) - 2, best_i + 100)
    for k in range(z0, z1):
        if (sig[k] <= 0 < sig[k+1]) or (sig[k] >= 0 > sig[k+1]):
            return k
    return best_i

# 9 dramatic micro-pauses in natural silent gaps between phrases (raw timestamps verified from Vosk):
PAUSES_SPEC = [
    (26.64, 0.75, "after 'фонарь погас'"),
    (41.58, 0.55, "after 'три пальца'"),
    (43.40, 0.55, "after 'загнул один'"),
    (60.86, 0.75, "after 'выключил свет в салоне'"),
    (64.40, 0.55, "after 'Один.'"),
    (65.34, 0.55, "after 'Второй.'"),
    (66.30, 0.60, "after 'Третий.'"),
    (99.30, 0.80, "after 'Не отвечай ему'"),
    (124.24, 0.731, "after 'Свет мигнул'"),
]

# Assemble voice_final_ep3.wav with clean 5ms cosine fades around inserted silence
pieces = []
prev_idx = 0
fade_n = int(0.005 * sr)
fade_out = np.linspace(1.0, 0.0, fade_n)
fade_in = np.linspace(0.0, 1.0, fade_n)

for raw_t, dur_s, label in PAUSES_SPEC:
    idx = find_split_sample(raw_pcm, sr, raw_t)
    seg = raw_pcm[prev_idx:idx].copy()
    if len(seg) > 2 * fade_n:
        seg[-fade_n:] *= fade_out
        if prev_idx > 0:
            seg[:fade_n] *= fade_in
    pieces.append(seg)
    pieces.append(np.zeros(int(round(dur_s * sr)), dtype=np.float64))
    prev_idx = idx

last_seg = raw_pcm[prev_idx:].copy()
if len(last_seg) > fade_n:
    last_seg[:fade_n] *= fade_in
pieces.append(last_seg)

# Pad exact tail hold so total duration = 160.000s (4800 frames @ 30fps)
TARGET_SEC = 160.0
voice_full = np.concatenate(pieces)
target_samples = int(round(TARGET_SEC * sr))
if len(voice_full) < target_samples:
    voice_full = np.concatenate([voice_full, np.zeros(target_samples - len(voice_full), dtype=np.float64)])
else:
    voice_full = voice_full[:target_samples]

def save_wav(path, sig, sample_rate=sr):
    pcm16 = np.clip(np.round(sig * 32767.0), -32768, 32767).astype(np.int16)
    with wave.open(path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm16.tobytes())

voice_final_path = os.path.join(OUT_DIR, 'voice_final_ep3.wav')
save_wav(voice_final_path, voice_full, sr)
print(f"Saved {voice_final_path}: {len(voice_full)/sr:.3f}s ({int(round(len(voice_full)/sr*30))} frames @ 30fps)")

# 2. Run Vosk directly on FINAL edited voice_final_ep3.wav (Section 3 step 5 & Section 13!)
tmp_16k = '/tmp/ep3_final_16k.wav'
subprocess.run([FFMPEG, '-y', '-i', voice_final_path, '-ac', '1', '-ar', '16000', tmp_16k, '-loglevel', 'error'], check=True)

model = Model('/tmp/vosk-repo/model')
rec = KaldiRecognizer(model, 16000)
rec.SetWords(True)
asr_words = []
with wave.open(tmp_16k, 'rb') as wf16:
    while True:
        buf = wf16.readframes(4000)
        if not buf:
            break
        if rec.AcceptWaveform(buf):
            asr_words.extend(json.loads(rec.Result()).get('result', []))
    asr_words.extend(json.loads(rec.FinalResult()).get('result', []))

SCRIPT_TEXT = """
В прошлой серии вы выбрали остаться в автобусе. И в ту секунду, когда двери закрылись, мой двойник снаружи улыбнулся.
Только улыбка была неправильной. Слишком широкой. А мокрая ладонь всё ещё лежала на стекле.
Я хотел спросить его, почему он не уходит. Но автобус тронулся раньше, чем я успел открыть рот.
Двойник остался на остановке. Я видел, как он становится всё меньше в окне. А потом фонарь погас.
Когда он снова загорелся, остановка была прямо перед автобусом. Та же скамейка. Тот же фонарь. И мой двойник всё ещё стоял там.
Только теперь он уже не улыбался.
Он медленно поднял руку и показал мне три пальца. Затем загнул один. Осталось два.
Я бросился к водителю. В зеркале над рулём по-прежнему было моё лицо. Только его глаза смотрели не на дорогу. Они смотрели на меня.
«Почему мы вернулись на эту остановку?» — спросил я.
Водитель не ответил. Вместо этого он выключил свет в салоне.
В темноте я услышал мокрые шаги. Один. Второй. Третий. Кто-то шёл по проходу прямо ко мне.
Я включил фонарик на телефоне. Луч выхватил пустые сиденья. Но на полу появлялись мокрые следы. Один за другим. Они приближались.
Я отступил и ударялся спиной о поручень. Шаги остановились совсем рядом.
Потом в окне я увидел своё отражение. Оно стояло за моей спиной. Хотя сам я был лицом к окну.
Отражение подняло руку и медленно указало на зеркало водителя.
На запотевшем стекле проступили слова: «Не отвечай ему».
Я моргнул — и надпись исчезла. А водитель наконец заговорил. Его голос звучал точно как мой.
«Если ты настоящий, скажи, как тебя зовут».
Я уже открыл рот, но вспомнил предупреждение в зеркале. И в этот момент автобус снова остановился.
За окном была та самая остановка. Двойник смотрел на меня и держал поднятым один палец.
Свет мигнул. В зеркале водитель улыбался. Но когда я посмотрел прямо на него, его лицо было неподвижным.
А потом из пустого прохода снова донёсся голос: «Разбей зеркало. Пока оно тебя не запомнило».
Водитель медленно повернулся ко мне. В его руке был ключ от дверей.
Что мне делать: разбить зеркало или ответить водителю? Выбирайте в голосовании. Ваш выбор решит, что произойдёт дальше. Продолжение — в четвёртой части.
""".replace("ударялся", "ударился").strip()

# Tokenize script keeping attached punctuation (merging standalone em-dashes onto preceding word)
raw_tokens = SCRIPT_TEXT.split()
script_tokens = []
for tok in raw_tokens:
    if tok == '—' and script_tokens:
        script_tokens[-1] = script_tokens[-1] + ' —'
    else:
        script_tokens.append(tok)

def norm(w):
    return re.sub(r'[^а-яa-z0-9]', '', w.lower().replace('ё', 'е'))

def char_sim(a, b):
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    # Levenshtein similarity
    m, n = len(a), len(b)
    dp = list(range(n + 1))
    for i in range(1, m + 1):
        prev = dp[0]
        dp[0] = i
        for j in range(1, n + 1):
            cur = dp[j]
            cost = 0 if a[i-1] == b[j-1] else 1
            dp[j] = min(dp[j] + 1, dp[j-1] + 1, prev + cost)
            prev = cur
    return 1.0 - dp[n] / max(m, n)

# Align script_tokens (N) to asr_words (M) using DP allowing 1:1, 1:2 (split ASR word like 'два ник'->'двойник'), or 2:1
N, M = len(script_tokens), len(asr_words)
sn = [norm(t) for t in script_tokens]
an = [norm(w['word']) for w in asr_words]

INF = -1e9
dp = np.full((N + 1, M + 1), INF)
bt = [[None] * (M + 1) for _ in range(N + 1)]
dp[0, 0] = 0.0

for i in range(N + 1):
    for j in range(M + 1):
        if dp[i, j] <= INF / 2:
            continue
        # 1:1
        if i < N and j < M:
            sc = dp[i, j] + char_sim(sn[i], an[j]) * 2.0
            if sc > dp[i+1, j+1]:
                dp[i+1, j+1] = sc
                bt[i+1][j+1] = (i, j, '1:1')
        # 1:2 (one script word split into 2 ASR tokens, e.g. 'два'+'ник' -> 'двойник')
        if i < N and j + 1 < M:
            sc = dp[i, j] + char_sim(sn[i], an[j] + an[j+1]) * 2.1 - 0.05
            if sc > dp[i+1, j+2]:
                dp[i+1, j+2] = sc
                bt[i+1][j+2] = (i, j, '1:2')
        # 1:3 (e.g. 'на'+'пятьдесят'+'ще'+'зла' -> 'надпись'+'исчезла')
        if i < N and j + 2 < M:
            sc = dp[i, j] + char_sim(sn[i], an[j] + an[j+1] + an[j+2]) * 2.1 - 0.12
            if sc > dp[i+1, j+3]:
                dp[i+1, j+3] = sc
                bt[i+1][j+3] = (i, j, '1:3')
        # Skip ASR noise word
        if j < M:
            sc = dp[i, j] - 0.55
            if sc > dp[i, j+1]:
                dp[i, j+1] = sc
                bt[i][j+1] = (i, j, '0:1')
        # Unmatched script short word
        if i < N:
            sc = dp[i, j] - 0.65
            if sc > dp[i+1, j]:
                dp[i+1, j] = sc
                bt[i+1][j] = (i, j, '1:0')

aligned = [None] * N
ci, cj = N, M
while ci > 0 or cj > 0:
    pi, pj, op = bt[ci][cj]
    if op in ('1:1', '1:2', '1:3'):
        aligned[pi] = (asr_words[pj]['start'], asr_words[cj - 1]['end'])
    ci, cj = pi, pj

# Interpolate any rare '1:0' token smoothly between neighbors
for i in range(N):
    if aligned[i] is None:
        prev_end = aligned[i-1][1] if i > 0 and aligned[i-1] else 0.0
        k = i + 1
        while k < N and aligned[k] is None:
            k += 1
        next_start = aligned[k][0] if k < N else TARGET_SEC - 1.0
        span = max(0.08, (next_start - prev_end) / (k - i))
        for m in range(i, k):
            aligned[m] = (round(prev_end + (m - i) * span, 3), round(prev_end + (m - i + 1) * span, 3))

words_out = [
    {"idx": i, "word": script_tokens[i], "start": round(float(aligned[i][0]), 3), "end": round(float(aligned[i][1]), 3)}
    for i in range(N)
]
with open(os.path.join(DATA_DIR, 'words_ep3.json'), 'w', encoding='utf-8') as f:
    json.dump(words_out, f, ensure_ascii=False, indent=2)

print(f"Aligned {len(words_out)} script words to voice_final_ep3.wav!")

# Helper to lookup exact word start/end by substring phrase
def find_phrase(phrase):
    target = [norm(x) for x in phrase.split() if norm(x)]
    L = len(target)
    for i in range(len(words_out) - L + 1):
        if [norm(words_out[i+k]['word']) for k in range(L)] == target:
            return words_out[i]['start'], words_out[i+L-1]['end'], i
    raise ValueError(f"Phrase not found: {phrase}")

KEY_EVENTS = {
    "stayVote": find_phrase("вы выбрали остаться")[0],
    "doorsClosed": find_phrase("двери закрылись")[0],
    "doubleSmiled": find_phrase("снаружи улыбнулся")[0],
    "tooWide": find_phrase("слишком широкой")[0],
    "wetPalm": find_phrase("мокрая ладонь")[0],
    "wantedAsk": find_phrase("хотел спросить")[0],
    "busMoved": find_phrase("автобус тронулся")[0],
    "doubleSmaller": find_phrase("становится всё меньше")[0],
    "lampOff": find_phrase("фонарь погас")[0],
    "lampOn": find_phrase("снова загорелся")[0],
    "sameBench": find_phrase("та же скамейка")[0],
    "sameLamp": find_phrase("тот же фонарь")[0],
    "notSmiling": find_phrase("не улыбался")[0],
    "raisedHand": find_phrase("медленно поднял руку")[0],
    "threeFingers": find_phrase("три пальца")[0],
    "bentOne": find_phrase("загнул один")[0],
    "leftTwo": find_phrase("осталось два")[0],
    "rushedDriver": find_phrase("бросился к водителю")[0],
    "mirrorMyFace": find_phrase("моё лицо")[0],
    "eyesOnMe": find_phrase("смотрели на меня")[0],
    "heroQuestion": find_phrase("почему мы вернулись")[0],
    "driverSilent": find_phrase("водитель не ответил")[0],
    "lightsOff": find_phrase("выключил свет")[0],
    "darkStepsIntro": find_phrase("услышал мокрые шаги")[0],
    "step1": find_phrase("один второй третий")[0],
    "step2": find_phrase("второй третий")[0],
    "step3": find_phrase("третий кто-то")[0],
    "flashlightOn": find_phrase("включил фонарик")[0],
    "emptySeats": find_phrase("пустые сиденья")[0],
    "wetTracks": find_phrase("мокрые следы")[0],
    "oneByOne": find_phrase("один за другим")[0],
    "approaching": find_phrase("они приближались")[0],
    "steppedBack": find_phrase("я отступил")[0],
    "hitPole": find_phrase("ударился спиной о поручень")[0],
    "stepsStopped": find_phrase("шаги остановились")[0],
    "sawRefl": find_phrase("увидел своё отражение")[0],
    "behindBack": find_phrase("за моей спиной")[0],
    "facingWin": find_phrase("лицом к окну")[0],
    "reflRaisedArm": find_phrase("отражение подняло руку")[0],
    "pointedMirror": find_phrase("указало на зеркало")[0],
    "foggedGlass": find_phrase("на запотевшем стекле")[0],
    "dontAnswer": find_phrase("не отвечай ему")[0],
    "blinked": find_phrase("я моргнул")[0],
    "vanished": find_phrase("надпись исчезла")[0],
    "driverSpoke": find_phrase("водитель наконец заговорил")[0],
    "driverQuestion": find_phrase("если ты настоящий")[0],
    "openedMouth": find_phrase("уже открыл рот")[0],
    "busStopped": find_phrase("снова остановился")[0],
    "sameStopAgain": find_phrase("та самая остановка")[0],
    "oneFinger": find_phrase("один палец")[0],
    "lightFlicker": find_phrase("свет мигнул")[0],
    "mirrorDriverSmiled": find_phrase("в зеркале водитель улыбался")[0],
    "directMotionless": find_phrase("посмотрел прямо на него")[0],
    "faceMotionlessWord": find_phrase("было неподвижным")[0],
    "voiceFromAisle": find_phrase("из пустого прохода")[0],
    "breakMirrorVoice": find_phrase("разбей зеркало")[0],
    "driverTurned": find_phrase("медленно повернулся ко мне")[0],
    "keyInHand": find_phrase("ключ от дверей")[0],
    "pollQuestion": find_phrase("что мне делать")[0],
    "optBreakMirror": find_phrase("разбить зеркало или")[0],
    "optAnswerDriver": find_phrase("ответить водителю")[0],
    "part4Footer": find_phrase("продолжение — в четвёртой")[0],
}

with open(os.path.join(DATA_DIR, 'events_ep3.json'), 'w', encoding='utf-8') as f:
    json.dump(KEY_EVENTS, f, ensure_ascii=False, indent=2)

print("\nMapped Key Events (s):")
for k, v in KEY_EVENTS.items():
    print(f"  {k:22s}: {v:7.3f}s")

# 3. Synthesize Ambience, Music, and all 14 Story SFX synced to KEY_EVENTS!
rng = np.random.default_rng(42)
N_SAMP = target_samples
t_arr = np.arange(N_SAMP, dtype=np.float64) / sr

def lp(sig, cutoff):
    b, a = butter(2, cutoff / (sr / 2.0), btype='low')
    return lfilter(b, a, sig)

def bp(sig, f1, f2):
    b, a = butter(2, [f1 / (sr / 2.0), f2 / (sr / 2.0)], btype='band')
    return lfilter(b, a, sig)

# 3a. Night rain + bus engine idle/drive ambience
rain = bp(rng.standard_normal(N_SAMP), 650, 4200) * 0.030
# Bus engine hum: stronger during moving sections (busMoved..lampOn and openedMouth..busStopped), subtle idle otherwise
drive_env = np.ones(N_SAMP) * 0.35
i_m1, i_m2 = int(KEY_EVENTS['busMoved'] * sr), int(KEY_EVENTS['lampOn'] * sr)
i_m3, i_m4 = int(46.0 * sr), int(KEY_EVENTS['busStopped'] * sr)
drive_env[i_m1:i_m2] = 0.95
drive_env[i_m3:i_m4] = 0.72
drive_env = lp(drive_env, 1.5)
engine = (np.sin(2 * np.pi * 56.0 * t_arr) * 0.032 + np.sin(2 * np.pi * 112.0 * t_arr) * 0.014) * drive_env
ambience = np.clip(rain + engine, -0.8, 0.8)
save_wav(os.path.join(OUT_DIR, 'ambience_ep3.wav'), ambience, sr)

# 3b. Subtle mystical C-minor drone pad (C2=65.41Hz, G2=98.0Hz, Eb3=155.56Hz)
lfo = 0.65 + 0.35 * np.sin(2 * np.pi * 0.09 * t_arr)
music = (
    np.sin(2 * np.pi * 65.41 * t_arr) * 0.034
    + np.sin(2 * np.pi * 98.00 * t_arr) * 0.022
    + np.sin(2 * np.pi * 155.56 * t_arr + 0.4 * np.sin(2 * np.pi * 0.2 * t_arr)) * 0.015
) * lfo
# Fade in first 1.5s, gentle tension rise in final poll
poll_idx = int(KEY_EVENTS['pollQuestion'] * sr)
music[poll_idx:] *= np.linspace(1.0, 1.35, N_SAMP - poll_idx)
music[:int(1.5 * sr)] *= np.linspace(0.0, 1.0, int(1.5 * sr))
save_wav(os.path.join(OUT_DIR, 'music_ep3.wav'), music, sr)

# 3c. Story SFX cues (clean, distinct, never masking speech)
sfx = np.zeros(N_SAMP, dtype=np.float64)

def add_sfx(t_sec, wave_seg):
    i0 = max(0, int(round(t_sec * sr)))
    i1 = min(N_SAMP, i0 + len(wave_seg))
    if i1 > i0:
        sfx[i0:i1] += wave_seg[:i1 - i0]

# (1) Doors closing pneumatic hiss + rubber seal thud
def make_door_close():
    d = int(1.25 * sr)
    tt = np.arange(d) / sr
    hiss = bp(rng.standard_normal(d), 1400, 5200) * np.exp(-tt * 2.8) * 0.16
    thud_t = np.maximum(0, tt - 0.85)
    thud = (tt >= 0.85) * np.sin(2 * np.pi * (95 * np.exp(-thud_t * 14)) * thud_t) * np.exp(-thud_t * 16) * 0.32
    return hiss + thud

add_sfx(KEY_EVENTS['doorsClosed'] - 0.85, make_door_close())

# (2) Bus pull-away low rev
def make_bus_start():
    d = int(2.2 * sr)
    tt = np.arange(d) / sr
    f = 48 + 28 * (1 - np.exp(-tt * 1.6))
    ph = 2 * np.pi * np.cumsum(f) / sr
    return (np.sin(ph) * 0.14 + bp(rng.standard_normal(d), 90, 340) * 0.08) * np.sin(np.pi * tt / 2.2)

add_sfx(KEY_EVENTS['busMoved'] - 0.1, make_bus_start())

# (3) Electric crackle when streetlamp goes out & relights + cabin light flicker
def make_elec_crackle(dur=0.42, amp=0.18):
    d = int(dur * sr)
    tt = np.arange(d) / sr
    buzz = (np.sin(2 * np.pi * 100 * tt) + 0.6 * np.sin(2 * np.pi * 300 * tt)) * 0.08
    sparks = (rng.random(d) > 0.985).astype(np.float64) * rng.uniform(-1, 1, d)
    sparks = bp(sparks, 1800, 6500) * 1.8
    return (buzz + sparks) * np.exp(-tt * 4.5) * (amp / 0.18)

add_sfx(KEY_EVENTS['lampOff'] + 0.15, make_elec_crackle(0.50, 0.22))
add_sfx(KEY_EVENTS['lampOn'] - 0.08, make_elec_crackle(0.35, 0.18))
add_sfx(KEY_EVENTS['lightFlicker'] + 0.12, make_elec_crackle(0.55, 0.22))

# (4) Cabin light switch mechanical click
def make_click(amp=0.26):
    d = int(0.09 * sr)
    tt = np.arange(d) / sr
    return (bp(rng.standard_normal(d), 900, 4200) * np.exp(-tt * 75) + np.sin(2 * np.pi * 320 * tt) * np.exp(-tt * 55)) * amp

add_sfx(KEY_EVENTS['lightsOff'] + 0.35, make_click(0.28))

# (5) Wet footsteps in the dark (in pauses!) + approaching wet footsteps
def make_wet_step(amp=0.28):
    d = int(0.32 * sr)
    tt = np.arange(d) / sr
    sole = np.sin(2 * np.pi * (125 * np.exp(-tt * 18)) * tt) * np.exp(-tt * 22) * 0.55
    squelch = bp(rng.standard_normal(d), 950, 4800) * np.exp(-np.maximum(0, tt - 0.02) * 18) * 0.65
    return (sole + squelch) * amp

# Place the 3 dark steps cleanly in the pauses right after "Один.", "Второй.", "Третий."!
add_sfx(KEY_EVENTS['step1'] + 0.52, make_wet_step(0.32))
add_sfx(KEY_EVENTS['step2'] + 0.60, make_wet_step(0.35))
add_sfx(KEY_EVENTS['step3'] + 0.58, make_wet_step(0.38))

# Approaching wet footprints under flashlight (softer so speech stays clear)
for k, dt in enumerate([0.1, 0.75, 1.4, 2.05, 2.7, 3.35]):
    add_sfx(KEY_EVENTS['wetTracks'] + dt, make_wet_step(0.14 + k * 0.018))

# (6) Phone flashlight button tap
add_sfx(KEY_EVENTS['flashlightOn'] + 0.12, make_click(0.20))

# (7) Back hitting metal stanchion pole (hollow damped metallic thud + faint 440/690Hz ring)
def make_pole_bump():
    d = int(0.65 * sr)
    tt = np.arange(d) / sr
    thud = np.sin(2 * np.pi * 115 * np.exp(-tt * 14) * tt) * np.exp(-tt * 15) * 0.28
    ring = (np.sin(2 * np.pi * 468 * tt) * 0.08 + np.sin(2 * np.pi * 712 * tt) * 0.05) * np.exp(-tt * 6.5)
    return thud + ring

add_sfx(KEY_EVENTS['hitPole'] + 0.05, make_pole_bump())

# (8) Eerie glassy harmonic accent when reflection moves independently
def make_eerie_swell(dur=1.6, f0=392.0, amp=0.10):
    d = int(dur * sr)
    tt = np.arange(d) / sr
    env = np.sin(np.pi * tt / dur) ** 1.5
    return (np.sin(2 * np.pi * f0 * tt) + 0.5 * np.sin(2 * np.pi * (f0 * 1.498) * tt)) * env * amp

add_sfx(KEY_EVENTS['reflRaisedArm'], make_eerie_swell(1.8, 370.0, 0.09))

# (9) Soft glassy shimmer on mirror inscription "Не отвечай ему"
add_sfx(KEY_EVENTS['dontAnswer'] - 0.15, make_eerie_swell(1.4, 523.25, 0.08))

# (10) Bus stopping brake hiss
def make_bus_stop():
    d = int(1.4 * sr)
    tt = np.arange(d) / sr
    hiss = bp(rng.standard_normal(d), 1800, 6000) * np.sin(np.pi * tt / 1.4) * 0.13
    low = np.sin(2 * np.pi * 62 * tt) * np.exp(-tt * 2.5) * 0.12
    return hiss + low

add_sfx(KEY_EVENTS['busStopped'] - 0.15, make_bus_stop())

# (11) Driver jacket rustle + metallic key clink
def make_key_clink():
    d = int(0.55 * sr)
    tt = np.arange(d) / sr
    rustle = bp(rng.standard_normal(d), 400, 1800) * np.sin(np.pi * np.minimum(1, tt / 0.35)) * 0.07
    t2 = np.maximum(0, tt - 0.18)
    clink = (tt >= 0.18) * (
        np.sin(2 * np.pi * 2480 * t2) * 0.12 + np.sin(2 * np.pi * 3710 * t2) * 0.08
    ) * np.exp(-t2 * 24)
    return rustle + clink

add_sfx(KEY_EVENTS['driverTurned'] + 0.1, bp(rng.standard_normal(int(0.7 * sr)), 350, 1400) * np.hanning(int(0.7 * sr)) * 0.06)
add_sfx(KEY_EVENTS['keyInHand'] - 0.08, make_key_clink())

# (12) Final suspense pulse + soft clock ticks during viewer choice
add_sfx(KEY_EVENTS['pollQuestion'] - 0.1, make_eerie_swell(2.2, 130.81, 0.14))
for tick_t in np.arange(KEY_EVENTS['pollQuestion'] + 0.5, TARGET_SEC - 0.3, 1.0):
    d = int(0.04 * sr)
    tt = np.arange(d) / sr
    add_sfx(float(tick_t), np.sin(2 * np.pi * 1150 * tt) * np.exp(-tt * 110) * 0.07)

sfx = np.clip(sfx, -0.85, 0.85)
save_wav(os.path.join(OUT_DIR, 'sfx_ep3.wav'), sfx, sr)

# Verify audio mix balance numerically (voice vs combined bg during active speech)
bg_mix = ambience * 0.35 + music * 0.30 + sfx * 0.70
speech_mask = np.abs(voice_full) > 0.015
v_rms = 20 * np.log10(np.sqrt(np.mean(voice_full[speech_mask] ** 2)) + 1e-12)
bg_rms = 20 * np.log10(np.sqrt(np.mean(bg_mix[speech_mask] ** 2)) + 1e-12)
print(f"\nMIX CHECK during active speech: Voice RMS = {v_rms:.2f} dBFS | Combined BG+SFX RMS = {bg_rms:.2f} dBFS | SNR = +{v_rms - bg_rms:.1f} dB")
