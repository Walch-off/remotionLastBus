import React from 'react';
import {Composition} from 'remotion';
import '@fontsource/inter/700.css';
import '@fontsource/inter/800.css';
import '@fontsource/inter/900.css';
import {LastBusEpisode3, LastBusEpisode3Test} from './ep3/Episode3';
import {
  TOTAL_FRAMES as EP3_FRAMES,
  TEST_FRAMES as EP3_TEST_FRAMES,
  FPS as EP3_FPS,
  W as EP3_W,
  H as EP3_H,
} from './ep3/storyEp3';

export const Root: React.FC = () => (
  <>
    <Composition
      id="LastBusPart3"
      component={LastBusEpisode3}
      durationInFrames={EP3_FRAMES}
      fps={EP3_FPS}
      width={EP3_W}
      height={EP3_H}
    />
    <Composition
      id="LastBusPart3Test"
      component={LastBusEpisode3Test}
      durationInFrames={EP3_TEST_FRAMES}
      fps={EP3_FPS}
      width={EP3_W}
      height={EP3_H}
    />
  </>
);
