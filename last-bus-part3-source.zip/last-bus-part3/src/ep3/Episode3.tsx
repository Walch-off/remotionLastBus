import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {
  SHOTS3,
  TOTAL_FRAMES,
  FPS,
  W,
  H,
  XFADE,
  TEST_START_SEC,
} from './storyEp3';
import {SHOT_COMPONENTS_EP3} from './scenes';
import {TopVoteBadgeEp3, InteractiveChoiceEp3} from './overlays';
import {SubtitlesEp3} from './subtitles';
import {Episode3AudioTracks} from './audio';

const SmoothCrossFade: React.FC<{children: React.ReactNode; fade: boolean}> = ({children, fade}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{opacity: fade ? Math.min(1, (f + 1) / XFADE) : 1}}>
      {children}
    </AbsoluteFill>
  );
};

/** Полная композиция 3-й серии «Последний автобус» (160.0 с / 4800 кадров). */
export const LastBusEpisode3: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#070c1a', fontFamily: 'Inter, DejaVu Sans, sans-serif'}}>
    {SHOTS3.map((s, i) => {
      const Comp = SHOT_COMPONENTS_EP3[s.id];
      const off = i === 0 ? 0 : XFADE;
      const from = Math.max(0, Math.round(s.a * FPS) - off);
      const end = i === SHOTS3.length - 1 ? TOTAL_FRAMES : Math.round(SHOTS3[i + 1].a * FPS);
      return (
        <Sequence key={s.id} from={from} durationInFrames={Math.max(1, end - from)} name={s.id}>
          <SmoothCrossFade fade={i > 0}>
            <Comp t0={from / FPS} />
          </SmoothCrossFade>
        </Sequence>
      );
    })}

    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
        <TopVoteBadgeEp3 />
        <InteractiveChoiceEp3 />
        <SubtitlesEp3 />
      </svg>
    </AbsoluteFill>

    <Episode3AudioTracks startFromFrame={0} />
  </AbsoluteFill>
);

/**
 * Тестовый фрагмент 14.5 с (73.0..87.5 с, Раздел 16 промпта):
 * включение фонарика телефона в руке -> освещение прохода -> мокрые следы на полу -> касание спиной поручня.
 */
export const LastBusEpisode3Test: React.FC = () => {
  const offsetFrames = Math.round(TEST_START_SEC * FPS);
  return (
    <AbsoluteFill style={{backgroundColor: '#070c1a', fontFamily: 'Inter, DejaVu Sans, sans-serif'}}>
      {SHOTS3.map((s, i) => {
        const Comp = SHOT_COMPONENTS_EP3[s.id];
        const off = i === 0 ? 0 : XFADE;
        const absFrom = Math.max(0, Math.round(s.a * FPS) - off);
        const absEnd = i === SHOTS3.length - 1 ? TOTAL_FRAMES : Math.round(SHOTS3[i + 1].a * FPS);
        if (absEnd <= offsetFrames || absFrom >= offsetFrames + 450) return null;
        return (
          <Sequence key={s.id} from={absFrom - offsetFrames} durationInFrames={Math.max(1, absEnd - absFrom)} name={s.id}>
            <SmoothCrossFade fade={i > 0}>
              <Comp t0={absFrom / FPS} />
            </SmoothCrossFade>
          </Sequence>
        );
      })}

      <AbsoluteFill style={{pointerEvents: 'none'}}>
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
          <SubtitlesEp3 timeOffsetSec={TEST_START_SEC} />
        </svg>
      </AbsoluteFill>

      <Episode3AudioTracks startFromFrame={offsetFrames} />
    </AbsoluteFill>
  );
};
