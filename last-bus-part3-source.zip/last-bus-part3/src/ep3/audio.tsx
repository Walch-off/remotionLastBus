import React from 'react';
import {Audio, staticFile} from 'remotion';

/**
 * Многослойное звуковое оформление 3-й серии:
 * - voice_final_ep3.wav (1.00) — основной слой речи, всегда чётко слышен поверх фона;
 * - ambience_ep3.wav (0.35) — ночной дождь и двигатель автобуса;
 * - music_ep3.wav (0.28) — ненавязчивый мистический эмбиент без скримеров;
 * - sfx_ep3.wav (0.70) — синхронные звуки дверей, фонаря, тумблера, мокрых шагов, фонарика, поручня и ключа.
 */
export const Episode3AudioTracks: React.FC<{startFromFrame?: number}> = ({startFromFrame = 0}) => (
  <>
    <Audio src={staticFile('audio/voice_final_ep3.wav')} startFrom={startFromFrame} volume={1.0} />
    <Audio src={staticFile('audio/ambience_ep3.wav')} startFrom={startFromFrame} volume={0.35} />
    <Audio src={staticFile('audio/music_ep3.wav')} startFrom={startFromFrame} volume={0.28} />
    <Audio src={staticFile('audio/sfx_ep3.wav')} startFrom={startFromFrame} volume={0.70} />
  </>
);
