import {CabinContext} from './cabinContext';
import React from 'react';
import {useCurrentFrame} from 'remotion';
import {lerp} from '../common';
import {Street, StreetDefs, FIGURE_X} from '../components/Street';
import {
  HeroFigure,
  HeroHeadCanonical,
  DoubleCountingHandCloseUp,
  DriverInCabFigure,
  PalmPressedOnGlassHand,
  HERO_PAL,
} from './characters';
import {W, H} from './storyEp3';

/**
 * Сцена 1 (план 1): Герой ОСТАЁТСЯ внутри автобуса, створки дверей плавно закрываются,
 * а за стеклом на остановке стоит Двойник и начинает слишком широко улыбаться.
 */
export const DoorClosingStayStage: React.FC<{
  doorOpen: number;    // 0.62 -> 0.00
  doubleSmile: number; // 0..1
}> = ({doorOpen, doubleSmile}) => {
  const doorX = 486;
  const doorY = 296;
  const doorW = 504;
  const doorH = 1236;
  const leafW = doorW / 2 - 3;

  return (
    <g>
      <StreetDefs />
      <rect width={W} height={H} fill="#0a1124" />
      {/* Потолок салона и тёплые плафоны */}
      <rect x={0} y={0} width={W} height={258} fill="#080d1d" />
      <rect x={110} y={138} width={215} height={14} rx={7} fill="#fff2cc" opacity={0.82} />
      <rect x={640} y={138} width={215} height={14} rx={7} fill="#fff2cc" opacity={0.82} />
      {/* Пол салона */}
      <rect x={0} y={doorY + doorH} width={W} height={H - (doorY + doorH)} fill="#070b16" />
      <line x1={0} y1={doorY + doorH} x2={W} y2={doorY + doorH} stroke="#233055" strokeWidth={6} />
      {/* Вертикальный поручень у входа (позади дверного проёма, не пересекает героя) */}
      <rect x={doorX - 38} y={240} width={14} height={1310} rx={7} fill="#8f9dbb" />

      {/* Дверной проём с видом на ночную остановку №12 */}
      <rect x={doorX - 14} y={doorY - 14} width={doorW + 28} height={doorH + 28} rx={18} fill="#182240" stroke="#2f406e" strokeWidth={6} />
      <defs>
        <clipPath id="ep3EntryDoorClip">
          <rect x={doorX} y={doorY} width={doorW} height={doorH} rx={12} />
        </clipPath>
      </defs>

      <g clipPath="url(#ep3EntryDoorClip)">
        <rect x={doorX} y={doorY} width={doorW} height={doorH} fill="#060a16" />
        <g transform={`translate(${doorX - 120} ${doorY + 92}) scale(1.95)`}>
          <Street camX={1915} width={520} lampLit={1} />
        </g>
        <ellipse cx={doorX + doorW * 0.54} cy={doorY + 140} rx={240} ry={320} fill="#ffc95c" opacity={0.12} />

        {/* Двойник СНАРУЖИ за дверью */}
        <HeroFigure
          id="doorOutsideDouble"
          x={doorX + doorW * 0.54}
          y={doorY + doorH * 0.91}
          scale={1.06}
          emotion="calm"
          look={[-0.3, 0.03]}
          wideSmile={doubleSmile}
          armL={52} frontLeftArm={true} handLNode={<PalmPressedOnGlassHand />}
          elbowL={-130}
          armR={82}
          shade={0.16}
          blinkSeed={999}
        />

        {/* Две стеклянные створки дверей автобуса */}
        <g transform={`translate(${-leafW * doorOpen} 0)`}>
          <rect x={doorX} y={doorY} width={leafW} height={doorH} fill="#0e172e" opacity={0.68} stroke="#283761" strokeWidth={8} />
          <rect x={doorX + 18} y={doorY + 38} width={leafW - 36} height={doorH * 0.62} rx={10} fill="#84aae0" opacity={0.18} />
          <rect x={doorX + leafW - 8} y={doorY} width={8} height={doorH} fill="#0d1324" />
        </g>
        <g transform={`translate(${leafW * doorOpen} 0)`}>
          <rect x={doorX + doorW - leafW} y={doorY} width={leafW} height={doorH} fill="#0e172e" opacity={0.68} stroke="#283761" strokeWidth={8} />
          <rect x={doorX + doorW - leafW + 18} y={doorY + 38} width={leafW - 36} height={doorH * 0.62} rx={10} fill="#84aae0" opacity={0.18} />
          <rect x={doorX + doorW - leafW} y={doorY} width={8} height={doorH} fill="#0d1324" />
        </g>
      </g>

      {/* Главный герой ОСТАЁТСЯ ВНУТРИ автобуса слева */}
      <HeroFigure
        id="doorInsideHero"
        x={244}
        y={1542}
        scale={1.30}
        emotion="worried"
        look={[0.58, 0.02]}
        dampShoulders={true}
        blinkSeed={17}
      />
    </g>
  );
};

/**
 * Сцена 1 (план 2): Крупный план лица Двойника за закрытым мокрым стеклом двери —
 * отчётливо видна неправильная, слишком широкая улыбка («Только улыбка была неправильной. Слишком широкой.»).
 */
export const DoubleWideSmileCloseStage: React.FC<{
  smileProgress: number;
  zoom: number;
}> = ({smileProgress, zoom}) => (
  <g transform={`translate(540 760) scale(${zoom}) translate(-540 -760)`}>
    <StreetDefs />
    <CabinContext />
    <rect x={68} y={220} width={944} height={1120} rx={36} fill="#121b36" stroke="#2c3c68" strokeWidth={10} />
    <defs>
      <clipPath id="doubleSmileWinClip">
        <rect x={92} y={244} width={896} height={1072} rx={24} />
      </clipPath>
    </defs>
    <g clipPath="url(#doubleSmileWinClip)">
      <g transform="translate(540 835) scale(2.48) translate(-540 -260)">
        <Street
          camX={FIGURE_X - 540}
          width={1080}
          lampLit={1}
          figure={
            <HeroFigure
              id="closeSmileDoubleFig"
              x={0}
              y={0}
              scale={0.62}
              emotion="calm"
              look={[0, 0.04]}
              wideSmile={smileProgress}
              armL={52} frontLeftArm={true} handLNode={<PalmPressedOnGlassHand />}
              elbowL={-130}
              armR={82}
              shade={0.14}
              blinkSeed={999}
            />
          }
        />
      </g>
      {/* Резиновый шов закрытой двери, блик стекла и капли дождя */}
      <rect x={92} y={244} width={20} height={1072} fill="#090e1d" opacity={0.85} />
      <polygon points="116,244 310,244 168,1316 116,1316" fill="#ffffff" opacity={0.07} />
      {[
        [240, 460, 4.5],
        [780, 420, 4.8],
        [825, 710, 5.2],
        [210, 960, 4.2],
        [745, 1060, 4.0],
      ].map(([cx, cy, r], idx) => (
        <circle key={idx} cx={cx} cy={cy} r={r} fill="#a4d4ff" opacity={0.5} />
      ))}
    </g>
  </g>
);

/**
 * Окно автобуса с узнаваемой ночной остановкой №12 (скамейка, треснувший павильон, фонарь и Двойник):
 * используется в Сценах 2, 3 и 10 для идеальной пространственной преемственности!
 */
export const BusWindowStopStage: React.FC<{
  camXOffset?: number;
  stopScale?: number;
  lampLit?: number;
  doubleSmile?: number;
  doubleRaiseArm?: number;
  rainStreakSpeed?: number;
}> = ({
  camXOffset = 0,
  stopScale = 1.22,
  lampLit = 1,
  doubleSmile = 0,
  doubleRaiseArm = 0,
  rainStreakSpeed = 0,
}) => {
  const frame = useCurrentFrame();
  return (
    <g>
      <StreetDefs />
      <CabinContext />
      <rect x={64} y={244} width={952} height={1056} rx={42} fill="#121b36" stroke="#2c3b66" strokeWidth={8} />
      <defs>
        <clipPath id="busStopWinClipEp3">
          <rect x={86} y={266} width={908} height={1012} rx={30} />
        </clipPath>
      </defs>
      <g clipPath="url(#busStopWinClipEp3)">
        <rect x={86} y={266} width={908} height={1012} fill="#050914" />
        <g transform={`translate(540 792) scale(${stopScale * 1.62}) translate(-540 -295)`}>
          <Street
            camX={FIGURE_X - 540 + camXOffset}
            width={1080}
            lampLit={lampLit}
            lampFlicker={lampLit > 0.2}
            figure={
              <HeroFigure
                id="winStopDoubleClean"
                x={0}
                y={0}
                scale={0.54}
                emotion="serious"
                look={[0, 0.04]}
                wideSmile={doubleSmile}
                armR={lerp(82, 34, doubleRaiseArm)}
                elbowR={lerp(6, 104, doubleRaiseArm)}
                shade={lampLit < 0.25 ? 0.80 : 0.15}
                blinkSeed={67}
              />
            }
          />
        </g>
        {lampLit < 0.95 && (
          <rect x={86} y={266} width={908} height={1012} fill="#03060f" opacity={(1 - lampLit) * 0.76} />
        )}
        {rainStreakSpeed > 0.05 &&
          Array.from({length: 10}).map((_, i) => {
            const rx = ((i * 139 + frame * 22 * rainStreakSpeed) % 880) + 95;
            const ry = ((i * 191 + frame * 7) % 860) + 305;
            return (
              <line
                key={i}
                x1={rx}
                y1={ry}
                x2={rx - 36 * rainStreakSpeed}
                y2={ry + 11}
                stroke="#9ecbff"
                strokeWidth={2.4}
                strokeLinecap="round"
                opacity={0.32 * rainStreakSpeed}
              />
            );
          })}
        <polygon points="90,266 285,266 142,1278 90,1278" fill="#ffffff" opacity={0.06} />
      </g>
    </g>
  );
};

/**
 * Чистый крупный план руки Двойника за мокрым стеклом окна на фоне мягкого боке ночной остановки
 * (без дублирования маленькой фигуры с двумя руками позади крупной руки!).
 */
export const WindowHandCountStage: React.FC<{
  mode: 'threeToTwo' | 'one';
  bendProgress?: number;
  raiseProgress?: number;
  cabinFlickerDark?: number;
}> = ({mode, bendProgress = 0, raiseProgress = 1, cabinFlickerDark = 0}) => (
  <g>
    <CabinContext />
    {/* Рама автобусного окна */}
    <rect x={64} y={220} width={952} height={1120} rx={42} fill="#121b36" stroke="#2c3b66" strokeWidth={8} />
    <defs>
      <clipPath id="handCountWinClip">
        <rect x={86} y={242} width={908} height={1076} rx={30} />
      </clipPath>
      <radialGradient id="amberBokeh" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#ffd470" stopOpacity={0.38} />
        <stop offset="60%" stopColor="#ffae38" stopOpacity={0.12} />
        <stop offset="100%" stopColor="#ffae38" stopOpacity={0} />
      </radialGradient>
    </defs>

    <g clipPath="url(#handCountWinClip)">
      {/* Размытый ночной фон остановки за стеклом (глубина резкости крупного плана) */}
      <rect x={86} y={242} width={908} height={1076} fill="#060b18" />
      <rect x={140} y={480} width={520} height={420} rx={12} fill="#131f3d" opacity={0.55} />
      <path d="M 210 520 l 35 95 l -28 50 l 48 80" stroke="#9ec0e6" strokeWidth={3} fill="none" opacity={0.28} />
      <circle cx={820} cy={430} r={220} fill="url(#amberBokeh)" />
      <circle cx={280} cy={610} r={110} fill="url(#amberBokeh)" opacity={0.45} />

      <g opacity={0.48}><HeroFigure id="countBackgroundDouble" x={345} y={1260} scale={0.70} emotion="serious" shade={0.3} /><text x={195} y={405} fill="#d4dfec" fontSize={42}>12</text><path d="M 135 1200 H 470 M 155 1200 V 1270 M 450 1200 V 1270" stroke="#6a6053" strokeWidth={16}/></g>
      {/* Крупный анатомичный план руки Двойника (3 -> 2 пальца или 1 палец) */}
      <DoubleCountingHandCloseUp mode={mode} bendProgress={bendProgress} raiseProgress={raiseProgress} />

      {/* Блик и капли дождя на внешней стороне стекла поверх руки (рука находится СНАРУЖИ за стеклом!) */}
      <polygon points="90,242 295,242 155,1318 90,1318" fill="#ffffff" opacity={0.07} />
      {[
        [245, 440, 4.2],
        [785, 515, 5.0],
        [310, 820, 3.8],
        [760, 940, 4.5],
      ].map(([cx, cy, r], i) => (
        <circle key={i} cx={cx} cy={cy} r={r} fill="#9fd2ff" opacity={0.46} />
      ))}
    </g>

    {cabinFlickerDark > 0.01 && <rect width={W} height={H} fill="#02040a" opacity={cabinFlickerDark} />}
  </g>
);

/**
 * Сцена 4 (финал): Водитель в кабине молча щёлкает тумблером «СВЕТ САЛОНА» на приборной панели,
 * выключая освещение автобуса (цельная рука от плеча/локтя водителя, настоящая приборная панель).
 */
export const CabLightSwitchStage: React.FC<{
  reachProgress: number; // 0..1
  lightsOn: number;      // 1 -> 0
}> = ({reachProgress, lightsOn}) => {
  const handX = lerp(330, 542, reachProgress);
  const handY = lerp(1190, 910, reachProgress);

  return (
    <g>
      <rect width={W} height={H} fill={lightsOn > 0.5 ? '#0b1328' : '#040711'} />
      {/* Верхний плафон кабины/салона, который гаснет при щелчке тумблера */}
      <rect x={0} y={0} width={W} height={220} fill="#070c1b" />
      <rect x={280} y={110} width={520} height={18} rx={9} fill={lightsOn > 0.5 ? '#fff3cf' : '#1b233b'} />
      {lightsOn > 0.5 && <ellipse cx={540} cy={175} rx={480} ry={160} fill="#fff2c6" opacity={0.22} />}

      {/* Лобовое стекло вверху и приборная торпеда автобуса */}
      <rect x={70} y={250} width={940} height={310} rx={26} fill="#060a17" stroke="#1d2a4f" strokeWidth={5} />
      <rect x={60} y={540} width={960} height={740} rx={36} fill="#0e162e" stroke="#283866" strokeWidth={6} />

      {/* Обод руля слева и цифровые часы 00:48 */}
      <ellipse cx={210} cy={980} rx={240} ry={95} fill="none" stroke="#161d33" strokeWidth={28} />
      <rect x={135} y={625} width={170} height={58} rx={10} fill="#050811" stroke="#23325c" strokeWidth={3} />
      <text x={220} y={666} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={700} fontSize={36} fill="#ff6a3d">
        00:48
      </text>

      {/* Блок тумблера освещения салона */}
      <rect x={420} y={630} width={360} height={410} rx={28} fill="#131e3d" stroke="#364a80" strokeWidth={4} />
      <text x={600} y={696} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={800} fontSize={27} letterSpacing={1.5} fill="#9eb4e8">
        СВЕТ САЛОНА
      </text>
      <rect x={495} y={735} width={210} height={250} rx={26} fill="#080d1c" stroke="#415794" strokeWidth={4} />
      <rect
        x={525}
        y={lightsOn > 0.5 ? 762 : 850}
        width={150}
        height={106}
        rx={16}
        fill={lightsOn > 0.5 ? '#3b589c' : '#1b2544'}
        stroke="#6a85c7"
        strokeWidth={3}
      />
      <circle cx={600} cy={lightsOn > 0.5 ? 800 : 920} r={11} fill={lightsOn > 0.5 ? '#48e892' : '#ff5247'} />

      {/* Правая рука водителя в тёмно-синем рукаве куртки, нажимающая клавишу тумблера */}
      <g transform={`translate(${handX} ${handY}) rotate(-22)`}>
        <rect x={-14} y={-90} width={28} height={104} rx={14} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2.6} />
        <ellipse cx={24} cy={8} rx={36} ry={26} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2.5} />
        <path d="M -28 18 C -42 -8, -26 -36, -4 -24 C 12 -16, 8 14, -8 32 Z" fill={HERO_PAL.skinTop} stroke={HERO_PAL.skinLine} strokeWidth={2.5} />
        <path d="M -32 12 L 50 12 L 58 106 L -36 106 Z" fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2.5} />
        <rect x={-48} y={98} width={120} height={36} rx={9} fill="#223059" stroke="#394f8a" strokeWidth={3} />
        <path d="M -54 130 L 74 130 L 96 620 L -88 620 Z" fill="#17213e" stroke="#2c3d6e" strokeWidth={3} />
      </g>

      {lightsOn < 0.5 && <rect width={W} height={H} fill="#02050d" opacity={0.52} />}
    </g>
  );
};

/**
 * Пустой ночной проход автобуса (Сцена 12: «А потом из пустого прохода снова донёсся голос» —
 * источник голоса остаётся полностью нераскрытым, сиденья пусты!).
 */
export const EmptyCabinAisleStage: React.FC<{lightsLevel?: number}> = ({lightsLevel = 0.65}) => (
  <g>
    <rect width={W} height={H} fill="#060a17" />
    <polygon points="0,0 1080,0 840,510 240,510" fill="#091022" />
    {[105, 245, 375].map((ly, i) => (
      <rect
        key={i}
        x={540 - (110 - i * 22)}
        y={ly}
        width={(110 - i * 22) * 2}
        height={14}
        rx={7}
        fill="#fff2cc"
        opacity={0.75 * lightsLevel}
      />
    ))}
    <rect x={240} y={510} width={600} height={740} rx={16} fill="#0c152e" stroke="#1e2d54" strokeWidth={5} />
    <rect x={295} y={565} width={490} height={265} rx={20} fill="#050813" stroke="#1d2a4d" strokeWidth={4} />
    <polygon points="240,1250 840,1250 1080,1920 0,1920" fill="#080d1c" />
    {[-80, -40, 0, 40, 80].map((ofs, i) => (
      <line key={i} x1={540 + ofs * 0.45} y1={1250} x2={540 + ofs * 1.9} y2={1920} stroke="#141e3b" strokeWidth={3} />
    ))}
    {[0, 1, 2, 3].map((r) => {
      const p = r / 3;
      const sy = lerp(890, 1225, p);
      const sw = lerp(165, 335, p);
      const sh = lerp(175, 315, p);
      const gap = lerp(105, 195, p);
      return (
        <g key={r}>
          <rect x={540 - gap - sw} y={sy} width={sw} height={sh} rx={24} fill="#1f2e54" stroke="#141e3b" strokeWidth={4} />
          <rect x={540 + gap} y={sy} width={sw} height={sh} rx={24} fill="#1f2e54" stroke="#141e3b" strokeWidth={4} />
        </g>
      );
    })}
    <line x1={392} y1={510} x2={348} y2={1690} stroke="#7888ab" strokeWidth={10} opacity={0.8} />
    <line x1={688} y1={510} x2={732} y2={1690} stroke="#7888ab" strokeWidth={10} opacity={0.8} />
  </g>
);

/**
 * Прямой взгляд на кабину водителя (Сцены 9, 11, 12, 13):
 * - в Сцене 11 (turnProgress = 0): лицо водителя при прямом взгляде АБСОЛЮТНО НЕПОДВИЖНО и БЕЗ УЛЫБКИ!
 * - в Сцене 12 (turnProgress 0 -> 1, keyRaise 0 -> 1): водитель медленно поворачивается к герою с ключом от дверей в руке!
 * - в Сцене 13 (compactForPoll = true): живая мизансцена под карточки выбора зрителей (герой НЕ делает выбор сам!).
 */
export const CabDirectAndTurnStage: React.FC<{
  driverTurn?: number;
  driverKey?: number;
  driverTalk?: number;
  cabinLights?: number;
  compactForPoll?: boolean;
}> = ({
  driverTurn = 0,
  driverKey = 0,
  driverTalk = 0,
  cabinLights = 0.85,
  compactForPoll = false,
}) => {
  const frame = useCurrentFrame();
  const wrapTransform = compactForPoll ? `translate(540 760) scale(${1+Math.min(frame/360,1)*0.035}) translate(-540 -760)` : undefined;

  return (
    <g>
      <CabinContext />
      <g transform={wrapTransform}>
        <rect x={76} y={140} width={928} height={1180} rx={36} fill="#0b1328" stroke="#1f2d54" strokeWidth={6} />
        <rect x={165} y={185} width={210} height={14} rx={7} fill="#fff2cc" opacity={0.78 * cabinLights} />
        <rect x={705} y={185} width={210} height={14} rx={7} fill="#fff2cc" opacity={0.78 * cabinLights} />

        {/* Верхнее зеркало заднего вида над водителем */}
        <rect x={372} y={246} width={28} height={90} fill="#233056" />
        <rect x={214} y={324} width={344} height={130} rx={24} fill="#101830" stroke="#536ba6" strokeWidth={7} />
        <defs>
          <clipPath id={compactForPoll ? 'cabMirClipP' : 'cabMirClipF'}>
            <rect x={228} y={338} width={316} height={102} rx={16} />
          </clipPath>
        </defs>
        <g clipPath={`url(#${compactForPoll ? 'cabMirClipP' : 'cabMirClipF'})`}>
          <rect x={228} y={338} width={316} height={102} fill="#162347" />
          <g transform="translate(386 396) scale(0.75) translate(-505 -242)">
            <HeroHeadCanonical
              id={compactForPoll ? 'cabMirHeadP' : 'cabMirHeadF'}
              emotion="serious"
              look={[0.22, 0.14]}
              driverCap={true}
              wideSmile={0}
              blinkSeed={999}
            />
          </g>
          <polygon points="234,338 304,338 264,440 228,440" fill="#ffffff" opacity={0.12} />
        </g>

        {/* Фигура Водителя (неподвижное лицо без улыбки; плавный поворот и ключ от дверей в руке) */}
        <DriverInCabFigure
          id={compactForPoll ? 'cabDriverP' : 'cabDriverF'}
          x={375}
          y={1085}
          scale={1.16}
          turnProgress={driverTurn}
          keyRaise={driverKey}
          keySqueeze={compactForPoll ? 0.5+0.5*Math.sin(frame/24) : 0}
          keyGlint={0.5+0.5*Math.sin(frame/31)}
          talkOpen={driverTalk}
        />

        {/* Рулевое колесо и приборная панель */}
        <ellipse cx={250} cy={1065} rx={190} ry={52} fill="none" stroke="#141a2e" strokeWidth={22} />
        <rect x={76} y={1085} width={544} height={235} rx={18} fill="#0d1428" stroke="#25345e" strokeWidth={4} />
        <rect x={132} y={1126} width={148} height={48} rx={8} fill="#050811" />
        <text x={206} y={1161} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={700} fontSize={32} fill="#ff6a3d">
          00:50
        </text>

        {/* Главный герой справа в проходе кабины */}
        <HeroFigure
          id={compactForPoll ? 'cabHeroP' : 'cabHeroF'}
          x={800}
          y={1435}
          scale={1.12}
          emotion="scared"
          look={compactForPoll ? [-0.65, -0.35+0.30*Math.sin(frame/40)] : [-0.65,-0.12]}
          dampShoulders={true}
          shade={1 - cabinLights * 0.92}
          blinkSeed={29}
        />
      </g>
    </g>
  );
};
