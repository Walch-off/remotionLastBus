import React from 'react';
import {useCurrentFrame} from 'remotion';
export const CabinContext: React.FC<{cab?: boolean}> = ({cab=false}) => {
 const f=useCurrentFrame();
 return <g>
 <rect width="1080" height="1920" fill="#142039"/>
 <path d="M 0 0 H 1080 L 1000 205 H 80 Z" fill="#24334e"/>
 <path d="M 0 140 H 1080 M 0 180 H 1080" stroke="#61718c" strokeWidth="6"/>
 {[180,700].map(x=><g key={x}><rect x={x} y="90" width="200" height="16" rx="8" fill="#f5d49a" opacity=".8"/><ellipse cx={x+100} cy="120" rx="160" ry="75" fill="#edc17d" opacity=".05"/></g>)}
 {[140,940].map(x=><g key={x}><path d={`M ${x} 180 v 90`} stroke="#75849b" strokeWidth="9"/><path d={`M ${x-28} 270 h 56 l -10 55 h -36 Z`} fill="none" stroke="#8592a9" strokeWidth="9"/></g>)}
 <rect y="1330" width="1080" height="590" fill="#1c2941"/>
 <path d="M 0 1360 H 1080 M 0 1400 H 1080" stroke="#66758d" strokeWidth="8"/>
 <path d="M 0 1920 L 370 1400 H 710 L 1080 1920" fill="#101a2d"/>
 {[0,820].map(x=><g key={x}><rect x={x} y="1450" width="260" height="440" rx="44" fill="#2a3b5c" stroke="#52637b" strokeWidth="7"/><path d={`M ${x+30} 1495 v 320 M ${x+220} 1495 v 320`} stroke="#354c70" strokeWidth="6"/></g>)}
 <rect x="24" y="175" width="20" height="1745" rx="10" fill="#8a9ab2"/><rect x="29" y="175" width="5" height="1745" fill="#d5e2ee" opacity=".5"/>
 {cab && <g><path d="M 0 1000 L 160 930 H 920 L 1080 1000 V 1330 H 0 Z" fill="#293955"/><ellipse cx="300" cy="1190" rx="215" ry="100" fill="none" stroke="#080e1d" strokeWidth="32"/><path d="M 300 1190 v 140 m 0 -140 l -180 -25 m 180 25 l 180 -25" stroke="#4e607a" strokeWidth="12"/>{[650,770,890].map(x=><circle key={x} cx={x} cy="1200" r="32" fill="#111c30" stroke="#638394" strokeWidth="3"/>)}</g>}
 {Array.from({length:12},(_,i)=><line key={i} x1={100+i*80} x2={92+i*80} y1={350+(i*87+f*3)%580} y2={380+(i*87+f*3)%580} stroke="#a7c6dd" opacity=".15" strokeWidth="2"/>)}
 </g>;
};
