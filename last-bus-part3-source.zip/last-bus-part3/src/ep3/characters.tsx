import React from 'react';
import {useCurrentFrame} from 'remotion';
import {lerp, clamp} from '../common';

/**
 * Палитра персонажа 1:1 по референсу hero.png:
 * каштановые волосы с 3 прядями на макушке, тёплый бежевый тон кожи, карие глаза,
 * синяя толстовка с капюшоном, шнурками и карманом-кенгуру, тёмно-графитовые брюки и кроссовки.
 */
export const HERO_PAL = {
  skinTop: '#f5c798',
  skinBase: '#efb989',
  skinShade: '#dfa373',
  skinLine: '#c48358',
  hairLight: '#8c5432',
  hairBase: '#754426',
  hairDark: '#59321b',
  brow: '#4d2b17',
  iris: '#693c1f',
  hoodLight: '#607eb8',
  hoodBase: '#516ea6',
  hoodDark: '#425d92',
  hoodDeep: '#344b79',
  pantsLight: '#383a47',
  pantsBase: '#2d2f3a',
  pantsDark: '#23252e',
  shoeBase: '#22242d',
  shoeSole: '#5c5f69',
};

export type HeroEmotion = 'calm' | 'worried' | 'surprised' | 'scared' | 'serious';

const EMO_SPEC: Record<
  HeroEmotion,
  {lid: number; eyeScale: number; irisR: number; browY: number; browTilt: number; mouthW: number; mouthCurve: number; mouthOpen: number}
> = {
  calm: {lid: 0.10, eyeScale: 1.0, irisR: 9.6, browY: 0, browTilt: 1, mouthW: 30, mouthCurve: 0, mouthOpen: 0},
  serious: {lid: 0.14, eyeScale: 0.98, irisR: 9.5, browY: 2, browTilt: -2, mouthW: 28, mouthCurve: -2, mouthOpen: 0},
  worried: {lid: 0.08, eyeScale: 1.05, irisR: 9.0, browY: -3, browTilt: 7, mouthW: 26, mouthCurve: -5, mouthOpen: 0},
  surprised: {lid: 0.0, eyeScale: 1.15, irisR: 8.6, browY: -9, browTilt: 3, mouthW: 16, mouthCurve: 0, mouthOpen: 0.52},
  scared: {lid: 0.0, eyeScale: 1.20, irisR: 7.8, browY: -9, browTilt: 9, mouthW: 22, mouthCurve: -3, mouthOpen: 0.72},
};

const EyeUnit: React.FC<{
  clipId: string;
  cx: number;
  cy: number;
  eyeScale: number;
  irisR: number;
  look: [number, number];
  lid: number;
}> = ({clipId, cx, cy, eyeScale, irisR, look, lid}) => {
  const rx = 20.5 * eyeScale;
  const ry = 14.5 * eyeScale;
  const lidY = cy - ry + 2 * ry * clamp(lid, 0, 0.96);
  const px = cx + clamp(look[0], -1, 1) * 7.5;
  const py = cy + clamp(look[1], -1, 1) * 4.5;

  return (
    <g>
      <defs>
        <clipPath id={clipId}>
          <ellipse cx={cx} cy={cy} rx={rx} ry={ry} />
        </clipPath>
      </defs>
      <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="#fffaf2" />
      <g clipPath={`url(#${clipId})`}>
        <circle cx={px} cy={py} r={irisR} fill={HERO_PAL.iris} />
        <circle cx={px} cy={py} r={irisR * 0.52} fill="#231108" />
        <circle cx={px - 3.2} cy={py - 3.0} r={2.7} fill="#ffffff" />
        <rect x={cx - rx - 4} y={cy - ry - 4} width={rx * 2 + 8} height={Math.max(0, lidY - (cy - ry - 4))} fill={HERO_PAL.skinBase} />
      </g>
      <path
        d={`M ${cx - rx} ${lidY + 2.5} Q ${cx} ${lidY - 6.5} ${cx + rx} ${lidY + 2.5}`}
        fill="none"
        stroke="#2b160b"
        strokeWidth={4.4}
        strokeLinecap="round"
      />
      <path
        d={`M ${cx - rx + 4} ${cy + ry - 1} Q ${cx} ${cy + ry + 2.8} ${cx + rx - 4} ${cy + ry - 1}`}
        fill="none"
        stroke={HERO_PAL.skinLine}
        strokeWidth={1.5}
        opacity={0.65}
      />
    </g>
  );
};

/**
 * Каноническая голова героя (используется у Героя, Двойника, Отражения и Водителя):
 * уши всегда плотно прилегают к контуру головы при любом повороте headYaw.
 */
export const HeroHeadCanonical: React.FC<{
  id: string;
  emotion?: HeroEmotion;
  look?: [number, number];
  tilt?: number;
  headYaw?: number;   // -0.6..+0.6: плавный параллакс черт лица без отрыва ушей
  wideSmile?: number; // 0..1: тревожная слишком широкая улыбка
  talkOpen?: number;  // 0..1: артикуляция речи / приоткрытый рот
  driverCap?: boolean;
  blinkSeed?: number;
}> = ({
  id,
  emotion = 'calm',
  look = [0, 0],
  tilt = 0,
  headYaw = 0,
  wideSmile = 0,
  talkOpen = 0,
  driverCap = false,
  blinkSeed = 0,
}) => {
  const frame = useCurrentFrame();
  const spec = EMO_SPEC[emotion];
  const cyc = (frame + blinkSeed * 13) % 124;
  const autoBlink = blinkSeed >= 900 ? 0 : cyc < 5 ? Math.sin((cyc / 5) * Math.PI) * (1 - spec.lid) : 0;
  const lid = clamp(spec.lid + autoBlink, 0, 0.96);

  const yaw = clamp(headYaw, -0.65, 0.65);
  const fx = yaw * 18;
  // Уши двигаются в противофазе с поворотом и всегда перекрываются контуром лица (без малейшего зазора!)
  const earLX = 412 + Math.max(0, yaw) * 10;
  const earRX = 598 + Math.min(0, yaw) * 10;
  const browY = 204 + spec.browY;

  return (
    <g transform={`rotate(${tilt} 505 300)`}>
      <defs>
        <linearGradient id={`${id}-faceG`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={HERO_PAL.skinTop} />
          <stop offset="100%" stopColor={HERO_PAL.skinBase} />
        </linearGradient>
        <linearGradient id={`${id}-hairG`} x1="0" y1="0" x2="0.8" y2="1">
          <stop offset="0%" stopColor={HERO_PAL.hairLight} />
          <stop offset="55%" stopColor={HERO_PAL.hairBase} />
          <stop offset="100%" stopColor={HERO_PAL.hairDark} />
        </linearGradient>
      </defs>

      {/* Уши (прикреплены к голове с перекрытием 6px внутрь овала лица) */}
      <ellipse cx={earLX} cy={238} rx={14} ry={21} fill={HERO_PAL.skinShade} />
      <path d={`M ${earLX - 3} 231 q 6 -4 8 6`} fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.6} strokeLinecap="round" />
      <ellipse cx={earRX} cy={238} rx={14} ry={21} fill={HERO_PAL.skinShade} />
      <path d={`M ${earRX + 3} 231 q -6 -4 -8 6`} fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.6} strokeLinecap="round" />

      {/* Овал головы и челюсти 1:1 по hero.png */}
      <path
        d="M 416 214 C 416 286, 456 314, 505 314 C 554 314, 594 286, 594 214 C 594 166, 560 148, 505 148 C 450 148, 416 166, 416 214 Z"
        fill={`url(#${id}-faceG)`}
      />

      {/* Причёска с 3 фирменными прядями на макушке из hero.png */}
      <path d="M 472 134 L 483 97 L 502 126 L 522 95 L 532 124 L 551 107 L 549 140 Z" fill={`url(#${id}-hairG)`} />
      <path
        d="M 407 236 C 398 168, 432 120, 505 118 C 580 118, 613 168, 603 236 L 592 214 C 588 190, 570 180, 548 188 C 526 174, 472 170, 442 190 C 428 198, 420 212, 417 236 Z"
        fill={`url(#${id}-hairG)`}
      />

      {/* Форменная фуражка водителя (только для водителя, лицо и виски остаются узнаваемыми!) */}
      {driverCap && (
        <g>
          <path d="M 402 184 C 404 114, 606 114, 608 184 Z" fill="#18223d" stroke="#2d3e6e" strokeWidth={3} />
          <rect x={402} y={172} width={206} height={18} rx={6} fill="#10172b" />
          <ellipse cx={505} cy={152} rx={15} ry={9} fill="#3a4f87" />
          <path d="M 396 184 Q 505 208 614 184 Q 588 168 505 168 Q 422 168 396 184 Z" fill="#0b1020" />
        </g>
      )}

      {/* Черты лица с мягким параллаксом fx */}
      <g transform={`translate(${fx} 0)`}>
        {/* Брови */}
        <path
          d={`M 452 ${browY + spec.browTilt * 0.5} L 493 ${browY - spec.browTilt * 0.7}`}
          stroke={HERO_PAL.brow}
          strokeWidth={8.5}
          strokeLinecap="round"
        />
        <path
          d={`M 517 ${browY - spec.browTilt * 0.7} L 558 ${browY + spec.browTilt * 0.5}`}
          stroke={HERO_PAL.brow}
          strokeWidth={8.5}
          strokeLinecap="round"
        />

        {/* Глаза */}
        <EyeUnit clipId={`${id}-eL`} cx={475} cy={229} eyeScale={spec.eyeScale} irisR={spec.irisR} look={look} lid={lid} />
        <EyeUnit clipId={`${id}-eR`} cx={535} cy={229} eyeScale={spec.eyeScale} irisR={spec.irisR} look={look} lid={lid} />

        {/* Нос */}
        <path d="M 504 240 q 10 16 -2 22" fill="none" stroke={HERO_PAL.skinLine} strokeWidth={3.8} strokeLinecap="round" />

        {/* Рот: спокойный / эмоция / речь / тревожная слишком широкая улыбка */}
        {wideSmile > 0.02 ? (
          <g>
            <path
              d={`M ${lerp(489, 458, wideSmile)} ${lerp(280, 263, wideSmile)}
                  C ${lerp(496, 478, wideSmile)} ${lerp(281, 303, wideSmile)},
                    ${lerp(514, 532, wideSmile)} ${lerp(281, 303, wideSmile)},
                    ${lerp(521, 552, wideSmile)} ${lerp(280, 263, wideSmile)}`}
              fill={wideSmile > 0.28 ? '#471d1a' : 'none'}
              stroke="#854232"
              strokeWidth={4}
              strokeLinecap="round"
            />
            {wideSmile > 0.35 && (
              <path
                d={`M ${lerp(486, 467, wideSmile)} ${lerp(278, 268, wideSmile)}
                    Q 505 286 ${lerp(524, 543, wideSmile)} ${lerp(278, 268, wideSmile)}
                    Q 505 294 ${lerp(486, 467, wideSmile)} ${lerp(278, 268, wideSmile)} Z`}
                fill="#f6f1e9"
                opacity={0.88}
              />
            )}
            <path d="M 454 259 q -4 6 2 10 M 556 259 q 4 6 -2 10" fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.3} strokeLinecap="round" opacity={wideSmile} />
          </g>
        ) : Math.max(spec.mouthOpen, talkOpen) > 0.06 ? (
          <g>
            <ellipse
              cx={505}
              cy={280}
              rx={lerp(11, 14, Math.max(spec.mouthOpen, talkOpen))}
              ry={3 + Math.max(spec.mouthOpen, talkOpen) * 7.5}
              fill="#54211d"
            />
            <ellipse
              cx={505}
              cy={283 + Math.max(spec.mouthOpen, talkOpen) * 2.5}
              rx={7}
              ry={2.2 + Math.max(spec.mouthOpen, talkOpen) * 2}
              fill="#bf6457"
            />
          </g>
        ) : (
          <path
            d={`M ${505 - spec.mouthW / 2} 280 Q 505 ${280 + spec.mouthCurve} ${505 + spec.mouthW / 2} 280`}
            fill="none"
            stroke="#8a4c38"
            strokeWidth={4.2}
            strokeLinecap="round"
          />
        )}
      </g>
    </g>
  );
};

/** Аккуратная кисть в спокойном положении (соединена с запястьем без зазоров). */
const RelaxedHand: React.FC<{flipThumb?: boolean}> = ({flipThumb = false}) => (
  <g transform={flipThumb ? 'scale(-1 1)' : undefined}>
    {/* Основание запястья уходит на 10px внутрь манжеты рукава */}
    <rect x={-16} y={-12} width={32} height={18} rx={8} fill={HERO_PAL.skinBase} />
    <path
      d="M -19 -2 Q -22 34 -10 50 Q 0 58 12 50 Q 22 34 19 -2 Z"
      fill={HERO_PAL.skinBase}
      stroke={HERO_PAL.skinLine}
      strokeWidth={2}
    />
    <path
      d="M -18 12 Q -31 20 -27 38 Q -23 45 -15 38 Z"
      fill={HERO_PAL.skinBase}
      stroke={HERO_PAL.skinLine}
      strokeWidth={2}
    />
    <path d="M -6 26 V 46 M 3 26 V 48 M 11 25 V 43" stroke={HERO_PAL.skinLine} strokeWidth={1.8} strokeLinecap="round" opacity={0.75} />
  </g>
);

/** Рука (плечо -> локоть -> предплечье -> манжета -> кисть) со сферическими шарнирами в плече и локте. */
const ConnectedArm: React.FC<{
  gid: string;
  elbowDeg: number;
  side: 'L' | 'R';
  handNode?: React.ReactNode;
}> = ({gid, elbowDeg, side, handNode}) => (
  <g>
    <defs>
      <linearGradient id={gid} x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stopColor={HERO_PAL.hoodLight} />
        <stop offset="55%" stopColor={HERO_PAL.hoodBase} />
        <stop offset="100%" stopColor={HERO_PAL.hoodDark} />
      </linearGradient>
    </defs>
    {/* Шарнир плеча (гарантирует отсутствие разрывов и вырезов при любом угле!) */}
    <circle cx={0} cy={0} r={31} fill={`url(#${gid})`} />
    <path d="M -30 0 Q -32 68 -27 146 L 27 146 Q 32 68 30 0 Z" fill={`url(#${gid})`} />
    <g transform={`translate(0 146) rotate(${elbowDeg})`}>
      {/* Шарнир локтя */}
      <circle cx={0} cy={0} r={27} fill={HERO_PAL.hoodBase} />
      <path d="M -27 0 Q -26 58 -23 128 L 23 128 Q 26 58 27 0 Z" fill={`url(#${gid})`} />
      {/* Трикотажная манжета */}
      <rect x={-25} y={110} width={50} height={24} rx={8} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={1.8} />
      {/* Кисть плотно соединена с манжетой */}
      <g transform="translate(0 132)">
        {handNode !== undefined ? handNode : <RelaxedHand flipThumb={side === 'R'} />}
      </g>
    </g>
  </g>
);

export type HeroFigureProps = {
  id: string;
  x: number;
  y: number;
  scale?: number;
  anchor?: [number, number];
  flip?: boolean;
  emotion?: HeroEmotion;
  look?: [number, number];
  tilt?: number;
  headYaw?: number;
  wideSmile?: number;
  talkOpen?: number;
  armL?: number;   // 90 = спокойно вдоль тела, 0 = горизонтально в сторону
  armR?: number;
  elbowL?: number;
  elbowR?: number;
  handLNode?: React.ReactNode;
  handRNode?: React.ReactNode;
  legs?: boolean;
  walkPhase?: number; // если задан — естественный шаг ногами от бедра и колена (без скольжения!)
  dampShoulders?: boolean; // лёгкие следы влаги на плечах из 2-й серии
  shade?: number;
  shadeColor?: [number, number, number];
  opacity?: number;
  blinkSeed?: number;
};

/**
 * Главный герой / Двойник / Отражение в полный рост или по пояс (строго по пропорциям hero.png).
 */
export const HeroFigure: React.FC<HeroFigureProps> = ({
  id,
  x,
  y,
  scale = 1,
  anchor = [505, 930],
  flip = false,
  emotion = 'calm',
  look = [0, 0],
  tilt = 0,
  headYaw = 0,
  wideSmile = 0,
  talkOpen = 0,
  armL = 82,
  armR = 82,
  elbowL = 6,
  elbowR = 6,
  handLNode,
  handRNode,
  legs = true,
  walkPhase,
  dampShoulders = false,
  shade = 0,
  shadeColor = [0.05, 0.08, 0.18],
  opacity = 1,
  blinkSeed = 0,
}) => {
  const frame = useCurrentFrame();
  const breathe = Math.sin(frame / 22 + blinkSeed) * 1.2;
  const walkBob = walkPhase !== undefined ? Math.abs(Math.sin(walkPhase)) * -8 : 0;

  const rL = 90 - armL;
  const rR = -(90 - armR);

  // Углы шага для левой и правой ноги (без скольжения по полу)
  const legSwingL = walkPhase !== undefined ? Math.sin(walkPhase) * 14 : 0;
  const legSwingR = walkPhase !== undefined ? -Math.sin(walkPhase) * 14 : 0;

  const [sr, sg, sb] = shadeColor;
  const matrix = `${1 - shade} 0 0 0 ${shade * sr}  0 ${1 - shade} 0 0 ${shade * sg}  0 0 ${1 - shade} 0 ${shade * sb}  0 0 0 1 0`;

  return (
    <g
      transform={`translate(${x} ${y + walkBob}) scale(${flip ? -scale : scale} ${scale}) translate(${-anchor[0]} ${-anchor[1]})`}
      opacity={opacity}
    >
      <defs>
        <filter id={`${id}-shf`} colorInterpolationFilters="sRGB">
          <feColorMatrix type="matrix" values={matrix} />
        </filter>
        <linearGradient id={`${id}-torsoG`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={HERO_PAL.hoodBase} />
          <stop offset="48%" stopColor={HERO_PAL.hoodLight} />
          <stop offset="100%" stopColor={HERO_PAL.hoodDark} />
        </linearGradient>
        <linearGradient id={`${id}-pantsG`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={HERO_PAL.pantsLight} />
          <stop offset="100%" stopColor={HERO_PAL.pantsDark} />
        </linearGradient>
      </defs>

      <g filter={shade > 0.005 ? `url(#${id}-shf)` : undefined}>
        {/* Естественная A-стойка ног и кроссовок 1:1 по hero.png */}
        {legs && (
          <g>
            {/* Левая нога (от бедра 464,564) */}
            <g transform={`rotate(${legSwingL} 464 564)`}>
              <path d="M 424 560 L 502 560 L 484 880 L 414 880 Z" fill={`url(#${id}-pantsG)`} />
              <path
                d="M 414 878 L 484 878 L 487 908 Q 486 926 468 928 L 382 929 Q 368 924 375 906 Q 382 892 414 878 Z"
                fill={HERO_PAL.shoeBase}
              />
              <path d="M 374 911 Q 371 928 386 930 L 472 929 Q 487 926 486 912 Z" fill={HERO_PAL.shoeSole} />
              <path d="M 406 894 l 20 -5 M 400 903 l 24 -6 M 416 886 l 16 -3" stroke="#626673" strokeWidth={2.8} strokeLinecap="round" />
            </g>

            {/* Правая нога (от бедра 546,564) */}
            <g transform={`rotate(${legSwingR} 546 564)`}>
              <path d="M 508 560 L 586 560 L 596 880 L 526 880 Z" fill={`url(#${id}-pantsG)`} />
              <path
                d="M 526 878 L 596 878 Q 628 892 635 906 Q 642 924 628 929 L 542 928 Q 524 926 523 908 Z"
                fill={HERO_PAL.shoeBase}
              />
              <path d="M 524 912 Q 523 926 538 929 L 624 930 Q 639 928 636 911 Z" fill={HERO_PAL.shoeSole} />
              <path d="M 604 894 l -20 -5 M 610 903 l -24 -6 M 594 886 l -16 -3" stroke="#626673" strokeWidth={2.8} strokeLinecap="round" />
            </g>
            {/* Паховый шов брюк */}
            <path d="M 492 560 L 518 560 L 510 605 L 500 605 Z" fill={HERO_PAL.pantsDark} />
          </g>
        )}

        {/* Руки крепятся к плечам (рисуются с перекрытием торса, чтобы силуэт плеч всегда был цельным) */}
        <g transform={`translate(432 ${370 + breathe * 0.4}) rotate(${rL})`}>
          <ConnectedArm gid={`${id}-armL`} elbowDeg={-elbowL} side="L" handNode={handLNode} />
        </g>
        <g transform={`translate(578 ${370 + breathe * 0.4}) rotate(${rR})`}>
          <ConnectedArm gid={`${id}-armR`} elbowDeg={elbowR} side="R" handNode={handRNode} />
        </g>

        {/* Торс синей толстовки */}
        <g transform={`translate(0 ${breathe * 0.4})`}>
          <path
            d="M 426 338 Q 505 322 584 338 Q 596 346 592 380 L 588 552 L 422 552 L 418 380 Q 414 346 426 338 Z"
            fill={`url(#${id}-torsoG)`}
          />
          {/* Мягкие плечевые переходы поверх шарнира */}
          <path d="M 418 392 Q 428 358 446 346" fill="none" stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} opacity={0.45} />
          <path d="M 592 392 Q 582 358 564 346" fill="none" stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} opacity={0.45} />

          {/* Деликатные потемнения влажной ткани на верхушках плеч (память о 2-й серии без лишних деталей) */}
          {dampShoulders && (
            <g opacity={0.34}>
              <ellipse cx={448} cy={352} rx={22} ry={10} fill="#1f3159" transform="rotate(-12 448 352)" />
              <ellipse cx={562} cy={352} rx={22} ry={10} fill="#1f3159" transform="rotate(12 562 352)" />
            </g>
          )}

          {/* Нижняя резинка и карман-кенгуру */}
          <rect x={420} y={538} width={170} height={34} rx={11} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
          <path
            d="M 452 476 L 558 476 Q 568 476 572 486 L 583 538 L 427 538 L 438 486 Q 442 476 452 476 Z"
            fill={HERO_PAL.hoodDark}
            opacity={0.62}
            stroke={HERO_PAL.hoodDeep}
            strokeWidth={2.8}
          />

          {/* Шея (соединена с головой и воротником без зазора) и ворот капюшона со шнурками */}
          <rect x={479} y={292} width={52} height={60} rx={14} fill={HERO_PAL.skinShade} />
          <path
            d="M 428 350 C 424 318, 448 298, 480 304 L 505 352 L 530 304 C 562 298, 586 318, 582 350 L 560 358 C 546 344, 524 348, 505 368 C 486 348, 464 344, 450 358 Z"
            fill={HERO_PAL.hoodLight}
            stroke={HERO_PAL.hoodDeep}
            strokeWidth={3}
            strokeLinejoin="round"
          />
          <path d="M 487 360 V 436 M 523 360 V 436" stroke={HERO_PAL.hoodDeep} strokeWidth={7} strokeLinecap="round" />
          <circle cx={487} cy={439} r={4.5} fill={HERO_PAL.hoodDeep} />
          <circle cx={523} cy={439} r={4.5} fill={HERO_PAL.hoodDeep} />
        </g>

        {/* Каноническая голова */}
        <g transform={`translate(0 ${breathe * 0.55})`}>
          <HeroHeadCanonical
            id={id}
            emotion={emotion}
            look={look}
            tilt={tilt}
            headYaw={headYaw}
            wideSmile={wideSmile}
            talkOpen={talkOpen}
            blinkSeed={blinkSeed}
          />
        </g>
      </g>
    </g>
  );
};

/**
 * СЦЕНА 6: Герой в понятном ракурсе 3/4 в профиль, отступающий спиной к вертикальному поручню!
 * - Параметр backX задаёт ТОЧНУЮ координату контура спины героя: когда backX === poleRightX,
 *   спина физически соприкасается с поручнем (без зазора и без прохождения сквозь металл!).
 * - Правая рука вытянута вперёд, ПАЛЬЦЫ КРЕПКО ОБХВАТЫВАЮТ ТЕЛЕФОН (телефон внутри кисти, не висит рядом!),
 *   и функция возвращает точные координаты светодиода фонарика через рендер-слот!
 */
export const HeroSteppingBackToPole: React.FC<{
  id: string;
  backX: number;       // точная X-координата спины героя (останавливается ровно на правом краю поручня!)
  floorY: number;      // Y-координата подошв на полу
  stepCycle: number;   // фаза переступания ног при отступлении (0 = стоит у поручня)
  impactJolt: number;  // 0..1 лёгкий импульс в момент касания спиной поручня
}> = ({id, backX, floorY, stepCycle, impactJolt}) => {
  // Внутренний контур спины толстовки в локальных координатах находится при x = 0!
  // Поэтому translate(backX, floorY) гарантирует, что левый край спины = ровно backX!
  const legA = Math.sin(stepCycle) * 10;
  const legB = -Math.sin(stepCycle) * 10;

  return (
    <g transform={`translate(${backX} ${floorY})`}>
      {/* Дальняя (левая) рука — естественно вдоль корпуса, НЕ пересекает поручень! */}
      <g transform="translate(82 -480) rotate(-6)">
        <circle cx={0} cy={0} r={24} fill={HERO_PAL.hoodDark} />
        <rect x={-22} y={0} width={44} height={118} rx={20} fill={HERO_PAL.hoodDark} />
        <g transform="translate(0 110) rotate(-8)">
          <rect x={-20} y={0} width={40} height={105} rx={18} fill={HERO_PAL.hoodDark} />
          <ellipse cx={0} cy={114} rx={17} ry={22} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2} />
        </g>
      </g>

      {/* Дальняя и ближняя ноги (опираются ровно на floorY, переступают при отступлении назад) */}
      <g transform={`translate(56 -330) rotate(${legA})`}>
        <path d="M -28 0 L 34 0 L 38 286 L -22 286 Z" fill={HERO_PAL.pantsDark} />
        <path d="M -24 284 L 40 284 Q 76 296 82 314 Q 86 328 70 330 L -18 330 Q -28 328 -24 284 Z" fill={HERO_PAL.shoeBase} />
        <rect x={-24} y={318} width={104} height={12} rx={5} fill={HERO_PAL.shoeSole} />
      </g>
      <g transform={`translate(96 -330) rotate(${legB})`}>
        <path d="M -30 0 L 36 0 L 42 286 L -22 286 Z" fill={HERO_PAL.pantsBase} />
        <path d="M -24 284 L 44 284 Q 82 296 88 314 Q 92 328 76 330 L -18 330 Q -28 328 -24 284 Z" fill={HERO_PAL.shoeBase} />
        <rect x={-24} y={318} width={110} height={12} rx={5} fill={HERO_PAL.shoeSole} />
        <path d="M 48 298 l -18 -4 M 56 306 l -20 -4" stroke="#636775" strokeWidth={2.6} strokeLinecap="round" />
      </g>

      {/* Торс в ракурсе 3/4 вправо: ЛЕВЫЙ КРАЙ СПИНЫ проходит СТРОГО по x = 0 (точка контакта с поручнем!) */}
      <path
        d={`M 0 -495
            C 2 -430, 0 -375, 3 -330
            L 146 -330
            L 152 -492
            C 150 -528, 122 -546, 76 -546
            C 28 -546, 2 -528, 0 -495 Z`}
        fill={HERO_PAL.hoodBase}
        stroke={HERO_PAL.hoodDeep}
        strokeWidth={3}
      />
      {/* Мягкая складка ткани на спине в момент соприкосновения с поручнем */}
      {impactJolt > 0.05 && (
        <path d="M 3 -480 Q 16 -445 4 -410 M 3 -395 Q 14 -368 4 -345" fill="none" stroke={HERO_PAL.hoodDeep} strokeWidth={3} opacity={impactJolt * 0.85} />
      )}
      {/* Резинка толстовки и карман сбоку-спереди */}
      <rect x={2} y={-354} width={146} height={28} rx={9} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
      <path d="M 62 -412 L 142 -412 L 147 -354 L 52 -354 Z" fill={HERO_PAL.hoodDark} opacity={0.6} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />

      {/* Шея и сложенный капюшон у ворота (левый край капюшона при x = 2) */}
      <rect x={58} y={-586} width={48} height={54} rx={12} fill={HERO_PAL.skinShade} />
      <path
        d="M 4 -528 C 6 -558, 38 -570, 74 -562 L 116 -528 L 142 -554 C 156 -542, 156 -518, 140 -512 C 102 -504, 34 -506, 4 -528 Z"
        fill={HERO_PAL.hoodLight}
        stroke={HERO_PAL.hoodDeep}
        strokeWidth={3}
      />
      <path d="M 106 -514 V -446 M 128 -514 V -448" stroke={HERO_PAL.hoodDeep} strokeWidth={6} strokeLinecap="round" />

      {/* Голова (повёрнута вправо к следам на полу, вздрагивает при касании поручня) */}
      <g transform={`translate(${82 - 505} ${-560 - 300}) rotate(${-impactJolt * 4} 505 300)`}>
        <HeroHeadCanonical
          id={`${id}-head`}
          emotion="scared"
          look={[0.68, 0.35]}
          headYaw={0.34}
          blinkSeed={31}
        />
      </g>

      {/* Ближняя (правая) рука вытянута вперёд-вправо, КИСТЬ ПЛОТНО ДЕРЖИТ СМАРТФОН С ВКЛЮЧЁННЫМ ФОНАРИКОМ! */}
      <g transform="translate(86 -484) rotate(-52)">
        <circle cx={0} cy={0} r={27} fill={HERO_PAL.hoodLight} />
        <path d="M -25 0 L 25 0 L 23 128 L -23 128 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
        <g transform="translate(0 124) rotate(-18)">
          <circle cx={0} cy={0} r={24} fill={HERO_PAL.hoodBase} />
          <path d="M -23 0 L 23 0 L 21 114 L -21 114 Z" fill={HERO_PAL.hoodLight} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
          <rect x={-23} y={98} width={46} height={20} rx={7} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />

          {/* КИСТЬ И ТЕЛЕФОН В РУКЕ (единый узел на запястье (0, 122)): пальцы обхватывают корпус телефона! */}
          <g transform="translate(0 122)">
            {/* Ладонь соединена с запястьем */}
            <ellipse cx={0} cy={12} rx={19} ry={22} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
            {/* Корпус смартфона в ладони (направлен фонариком вперёд-вниз к полу!) */}
            <g transform="translate(8 20) rotate(24)">
              <rect x={-16} y={-34} width={34} height={74} rx={8} fill="#0c101d" stroke="#536694" strokeWidth={2.6} />
              {/* Яркий светодиод фонарика на нижней/передней грани телефона */}
              <circle cx={18} cy={18} r={8} fill="#ffffff" />
              <circle cx={18} cy={18} r={20} fill="#d4e8ff" opacity={0.48} />
              {/* Светодиод телефона направлен вперёд-вниз к мокрым следам на полу */}
              {/* 4 пальца героя плотно обхватывают корпус смартфона сверху/сбоку */}
              {[-18, -5, 8, 20].map((fy, fi) => (
                <rect
                  key={fi}
                  x={-21}
                  y={fy}
                  width={18}
                  height={10}
                  rx={5}
                  fill={HERO_PAL.skinBase}
                  stroke={HERO_PAL.skinLine}
                  strokeWidth={1.6}
                />
              ))}
              {/* Большой палец прижимает телефон с другой стороны */}
              <path
                d="M -6 -22 C 8 -28, 20 -18, 16 -4 C 12 6, -2 4, -8 -8 Z"
                fill={HERO_PAL.skinTop}
                stroke={HERO_PAL.skinLine}
                strokeWidth={1.8}
              />
            </g>
          </g>
        </g>
      </g>
    </g>
  );
};

/**
 * СЦЕНА 7: Настоящий Герой со спины (3/4 сзади), стоящий ЛИЦОМ К ОКНУ с ОБЕИМИ ОПУЩЕННЫМИ РУКАМИ!
 * Показывает зрителю без слов, что сам герой НЕ поднимает руку — руку поднимает только его отражение в стекле!
 */
export const HeroRearFacingWindow: React.FC<{
  x: number;
  y: number;
  scale?: number;
}> = ({x, y, scale = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${scale}) translate(-505 -930)`}>
    {/* Ноги в A-стойке */}
    <path d="M 424 560 L 502 560 L 486 890 L 418 890 Z" fill={HERO_PAL.pantsBase} />
    <path d="M 508 560 L 586 560 L 592 890 L 524 890 Z" fill={HERO_PAL.pantsDark} />
    {/* ОПУЩЕННЫЕ ВДОЛЬ ТЕЛА РУКИ (настоящий герой НЕ повторяет жест отражения!) */}
    <path d="M 398 366 Q 388 468 394 590 L 434 590 L 438 366 Z" fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />
    <ellipse cx={412} cy={612} rx={17} ry={24} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2} />
    <path d="M 572 366 L 576 590 L 616 590 Q 622 468 612 366 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />
    <ellipse cx={598} cy={612} rx={17} ry={24} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />

    {/* Спина синей толстовки и сложенный капюшон сзади */}
    <path
      d="M 424 340 Q 505 324 586 340 Q 598 350 594 384 L 590 562 L 420 562 L 416 384 Q 412 350 424 340 Z"
      fill={HERO_PAL.hoodBase}
      stroke={HERO_PAL.hoodDeep}
      strokeWidth={3}
    />
    <rect x={420} y={538} width={170} height={30} rx={10} fill={HERO_PAL.hoodDark} />
    <path
      d="M 430 344 C 434 416, 474 444, 505 446 C 536 444, 576 416, 580 344 C 554 330, 456 330, 430 344 Z"
      fill={HERO_PAL.hoodLight}
      stroke={HERO_PAL.hoodDeep}
      strokeWidth={3.2}
    />
    <path d="M 505 340 V 442" stroke={HERO_PAL.hoodDeep} strokeWidth={3} opacity={0.5} />

    {/* Шея, правое ухо и каштановый затылок с 3 фирменными прядями (без черт лица — герой стоит лицом к стеклу!) */}
    <rect x={480} y={292} width={50} height={56} rx={12} fill={HERO_PAL.skinShade} />
    <ellipse cx={586} cy={242} rx={12} ry={20} fill={HERO_PAL.skinShade} />
    <path d="M 470 134 L 482 98 L 502 126 L 522 96 L 532 124 L 550 108 L 548 140 Z" fill={HERO_PAL.hairBase} />
    <path
      d="M 412 232 C 404 162, 442 118, 506 118 C 572 118, 598 164, 586 226 C 574 264, 550 290, 504 294 C 452 294, 420 268, 412 232 Z"
      fill={HERO_PAL.hairBase}
    />
    <path d="M 418 242 C 436 278, 476 294, 534 290 C 558 284, 574 266, 580 242 C 552 262, 468 264, 418 242 Z" fill={HERO_PAL.hairDark} opacity={0.5} />
  </g>
);

/**
 * КРУПНЫЙ ПЛАН ПРАВОЙ РУКИ ДВОЙНИКА НА ОТСЧЁТЕ ПАЛЬЦЕВ (Сцена 3: 3 -> 2 пальца; Сцена 10: 1 палец).
 * Чистый самостоятельный крупный план за мокрым стеклом окна (без дублирования второго тела позади руки!).
 * Анатомия правой ладони к зрителю: большой палец слева (-x), далее указательный (-46), средний (-15), безымянный (+16), мизинец (+46).
 */
export const DoubleCountingHandCloseUp: React.FC<{
  mode: 'threeToTwo' | 'one';
  bendProgress?: number;  // 0..1 плавное сгибание безымянного пальца (3 -> 2)
  raiseProgress?: number; // 0..1 плавный вход руки в кадр
}> = ({mode, bendProgress = 0, raiseProgress = 1}) => {
  const ySlide = lerp(220, 0, raiseProgress);
  const idxRatio = 1;
  const midRatio = mode === 'one' ? 0 : 1;
  const ringRatio = mode === 'one' ? 0 : 1 - clamp(bendProgress, 0, 1);
  const pinkyRatio = 0;

  const drawFinger = (fx: number, baseY: number, fullLen: number, fw: number, up: number, key: string) => {
    // Плавная двухсуставная артикуляция сгибания пальца без скачков!
    const curLen = lerp(-36, fullLen, up);
    if (curLen >= 18) {
      return (
        <g key={key}>
          <rect
            x={fx - fw / 2}
            y={baseY - curLen}
            width={fw}
            height={curLen + 20}
            rx={fw / 2}
            fill={HERO_PAL.skinBase}
            stroke={HERO_PAL.skinLine}
            strokeWidth={3.2}
          />
          <line x1={fx - fw * 0.3} y1={baseY - curLen * 0.36} x2={fx + fw * 0.3} y2={baseY - curLen * 0.36} stroke={HERO_PAL.skinLine} strokeWidth={2.3} strokeLinecap="round" />
          <line x1={fx - fw * 0.28} y1={baseY - curLen * 0.68} x2={fx + fw * 0.28} y2={baseY - curLen * 0.68} stroke={HERO_PAL.skinLine} strokeWidth={2.1} strokeLinecap="round" />
        </g>
      );
    }
    const foldH = lerp(28, 54, -curLen / 36);
    return (
      <g key={key}>
        <rect
          x={fx - fw / 2}
          y={baseY - 16}
          width={fw}
          height={foldH}
          rx={fw / 2}
          fill={HERO_PAL.skinShade}
          stroke={HERO_PAL.skinLine}
          strokeWidth={3.2}
        />
        <ellipse cx={fx} cy={baseY + foldH - 26} rx={fw * 0.32} ry={6.5} fill="#fae2cb" opacity={0.65} />
      </g>
    );
  };

  return (
    <g transform={`translate(540 ${935 + ySlide}) scale(1.78)`}>
      {/* Рукав синей толстовки и манжета (соединены с запястьем без зазора) */}
      <path d="M -82 178 L -102 380 L 104 380 L 84 178 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={3.8} />
      <rect x={-88} y={146} width={176} height={40} rx={13} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={3.4} />

      {/* Запястье и ладонь */}
      <rect x={-56} y={104} width={112} height={52} rx={16} fill={HERO_PAL.skinBase} />
      <path
        d="M -78 16 C -84 -18, -68 -38, -46 -38 L 48 -38 C 72 -38, 84 -16, 80 22 L 74 86 C 68 122, 38 136, 0 136 C -42 136, -72 118, -76 80 Z"
        fill={HERO_PAL.skinBase}
        stroke={HERO_PAL.skinLine}
        strokeWidth={3.4}
      />
      <path d="M -50 26 Q 6 12 54 34 M -34 58 Q 10 46 46 70" fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.5} strokeLinecap="round" opacity={0.7} />

      {/* Сначала выпрямленные пальцы, затем согнутые на переднем плане ладони */}
      {idxRatio > 0.34 && drawFinger(-46, -28, 138, 27, idxRatio, 'u-idx')}
      {midRatio > 0.34 && drawFinger(-15, -34, 154, 28, midRatio, 'u-mid')}
      {ringRatio > 0.34 && drawFinger(16, -30, 140, 27, ringRatio, 'u-ring')}
      {pinkyRatio > 0.34 && drawFinger(46, -20, 112, 24, pinkyRatio, 'u-pnk')}

      {idxRatio <= 0.34 && drawFinger(-46, -28, 138, 27, idxRatio, 'f-idx')}
      {midRatio <= 0.34 && drawFinger(-15, -34, 154, 28, midRatio, 'f-mid')}
      {ringRatio <= 0.34 && drawFinger(16, -30, 140, 27, ringRatio, 'f-ring')}
      {pinkyRatio <= 0.34 && drawFinger(46, -20, 112, 24, pinkyRatio, 'f-pnk')}

      {/* Большой палец слева, естественно прижимающий согнутые пальцы */}
      <path
        d={
          mode === 'one'
            ? 'M -76 66 C -92 34, -70 -4, -34 -2 L 18 8 C 34 12, 32 34, 14 36 L -38 38 C -48 56, -58 74, -76 66 Z'
            : 'M -76 70 C -90 40, -66 10, -28 14 L 38 22 C 54 25, 50 46, 32 46 L -32 46 C -46 62, -58 76, -76 70 Z'
        }
        fill={HERO_PAL.skinTop}
        stroke={HERO_PAL.skinLine}
        strokeWidth={3.4}
        strokeLinejoin="round"
      />
      <ellipse cx={mode === 'one' ? 14 : 32} cy={mode === 'one' ? 21 : 33} rx={7.5} ry={5.5} fill="#fae2cb" opacity={0.75} />
    </g>
  );
};

/**
 * Водитель в кабине с каноническим лицом Героя под козырьком фуражки:
 * - turnProgress = 0: сидит в полоборота к лобовому стеклу с АБСОЛЮТНО НЕПОДВИЖНЫМ ЛИЦОМ (Сцена 11),
 * - turnProgress 0 -> 1: медленно поворачивается к герою и поднимает руку с металлическим КЛЮЧОМ ОТ ДВЕРЕЙ (Сцена 12).
 */
export const DriverInCabFigure: React.FC<{
  id: string;
  x: number;
  y: number;
  scale?: number;
  turnProgress?: number; // 0 = в полоборота к дороге, 1 = повернулся к герою
  keyRaise?: number;     // 0..1 рука с ключом от дверей
  talkOpen?: number;
}> = ({id, x, y, scale = 1, turnProgress = 0, keyRaise = 0, talkOpen = 0}) => {
  const headYaw = lerp(-0.52, 0.08, turnProgress);
  const lookX = lerp(-0.45, 0.22, turnProgress);

  return (
    <g transform={`translate(${x} ${y}) scale(${scale}) translate(-505 -620)`}>
      {/* Кресло водителя */}
      <rect x={352} y={235} width={296} height={465} rx={44} fill="#17203a" stroke="#283761" strokeWidth={5} />

      {/* Торс в тёмно-синей куртке водителя */}
      <path
        d="M 412 344 Q 505 324 598 344 Q 618 358 614 402 L 606 625 L 404 625 L 396 402 Q 392 358 412 344 Z"
        fill="#1c2747"
        stroke="#2f4070"
        strokeWidth={3.5}
      />
      <rect x={479} y={292} width={52} height={58} rx={14} fill={HERO_PAL.skinShade} />
      <path d="M 446 340 L 482 314 L 505 366 L 528 314 L 564 340 L 542 378 L 505 366 L 468 378 Z" fill="#263561" stroke="#3b508a" strokeWidth={2.5} />
      <line x1={505} y1={366} x2={505} y2={620} stroke="#10172b" strokeWidth={5} />

      {/* Левое и правое плечи куртки (цельные рукава без разрывов) */}
      <path d="M 398 360 Q 374 455 382 600 L 428 600 L 432 368 Z" fill="#161f3a" />
      <path d="M 578 360 Q 626 445 616 575 L 566 575 L 568 372 Z" fill="#182240" stroke="#2f4070" strokeWidth={3} />

      {/* Каноническое лицо Героя под фуражкой (СТРОГО БЕЗ УЛЫБКИ при прямом взгляде!) */}
      <HeroHeadCanonical
        id={id}
        emotion="serious"
        look={[lookX, 0.05]}
        headYaw={headYaw}
        driverCap={true}
        wideSmile={0}
        talkOpen={talkOpen}
        blinkSeed={999}
      />

      {/* Правая рука водителя, цельно соединённая с локтем и сжимающая крупный КЛЮЧ ОТ ДВЕРЕЙ */}
      {keyRaise > 0.02 && (
        <g
          transform={`translate(${lerp(586, 540, keyRaise)} ${lerp(566, 470, keyRaise)}) rotate(${lerp(28, -8, keyRaise)})`}
          opacity={Math.min(1, keyRaise * 1.4)}
        >
          <path d="M 18 18 L 86 92 L 50 128 L -22 44 Z" fill="#223059" stroke="#374c82" strokeWidth={3} />
          <circle cx={68} cy={108} r={21} fill="#223059" />
          <rect x={-24} y={20} width={54} height={22} rx={8} fill="#16203d" stroke="#374c82" strokeWidth={2.5} transform="rotate(-36)" />

          {/* Крупный металлический ключ от дверей автобуса на кольце с синим брелоком */}
          <g transform="translate(-38 -16) rotate(-22) scale(1.18)">
            <rect x={-18} y={18} width={36} height={58} rx={9} fill="#2c63dc" stroke="#85b0ff" strokeWidth={2.4} />
            <circle cx={0} cy={28} r={4} fill="#0d152b" />
            <rect x={-9} y={39} width={18} height={22} rx={2.5} fill="none" stroke="#e2edff" strokeWidth={2.2} />
            <circle cx={0} cy={12} r={11} fill="none" stroke="#d5dff7" strokeWidth={3.4} />
            <circle cx={0} cy={-4} r={17} fill="#e2ebff" stroke="#7888b2" strokeWidth={3} />
            <circle cx={0} cy={-4} r={5.5} fill="#131c36" />
            <path
              d="M -5.5 -21 L -5.5 -88 L 3.5 -88 L 8 -79 L 3.5 -71 L 9 -62 L 3.5 -54 L 8 -45 L 4.5 -38 L 4.5 -21 Z"
              fill="#eef4ff"
              stroke="#7888b2"
              strokeWidth={2.3}
            />
            <circle cx={0} cy={-58} r={26} fill="#a8d0ff" opacity={0.2} />
          </g>

          {/* Пальцы водителя плотно удерживают головку ключа (не висит в воздухе!) */}
          <ellipse cx={-2} cy={16} rx={24} ry={20} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2.4} />
          <path d="M -18 7 h 22 M -20 16 h 24 M -16 25 h 20" stroke={HERO_PAL.skinLine} strokeWidth={2.1} strokeLinecap="round" />
          <path
            d="M -10 4 C -32 -4, -42 -15, -31 -24 C -20 -31, -2 -16, 8 -2 Z"
            fill={HERO_PAL.skinTop}
            stroke={HERO_PAL.skinLine}
            strokeWidth={2.4}
          />
        </g>
      )}
    </g>
  );
};
