import React from 'react';
import {useCurrentFrame} from 'remotion';
import {lerp, clamp} from '../common';

export const HERO_PAL = {
  skinTop: '#f5c798',
  skinBase: '#efb989',
  skinShade: '#dfa373',
  skinLine: '#c48358',
  hairLight: '#8c5432',
  hairBase: '#754426',
  hairDark: '#59321b',
  brow: '#4d2b17',
  iris: '#693c1f',
  hoodLight: '#607eb8',
  hoodBase: '#516ea6',
  hoodDark: '#425d92',
  hoodDeep: '#344b79',
  pantsLight: '#383a47',
  pantsBase: '#2d2f3a',
  pantsDark: '#23252e',
  shoeBase: '#22242d',
  shoeSole: '#5c5f69',
};

export type HeroEmotion = 'calm' | 'worried' | 'surprised' | 'scared' | 'serious';

const EMO_SPEC: Record<
  HeroEmotion,
  {lid: number; eyeScale: number; irisR: number; browY: number; browTilt: number; mouthW: number; mouthCurve: number; mouthOpen: number}
> = {
  calm: {lid: 0.10, eyeScale: 1.0, irisR: 9.6, browY: 0, browTilt: 1, mouthW: 30, mouthCurve: 0, mouthOpen: 0},
  serious: {lid: 0.14, eyeScale: 0.98, irisR: 9.5, browY: 2, browTilt: -2, mouthW: 28, mouthCurve: -2, mouthOpen: 0},
  worried: {lid: 0.08, eyeScale: 1.05, irisR: 9.0, browY: -3, browTilt: 7, mouthW: 26, mouthCurve: -5, mouthOpen: 0},
  surprised: {lid: 0.0, eyeScale: 1.15, irisR: 8.6, browY: -9, browTilt: 3, mouthW: 16, mouthCurve: 0, mouthOpen: 0.52},
  scared: {lid: 0.0, eyeScale: 1.20, irisR: 7.8, browY: -9, browTilt: 9, mouthW: 22, mouthCurve: -3, mouthOpen: 0.72},
};

const EyeUnit: React.FC<{
  clipId: string;
  cx: number;
  cy: number;
  eyeScale: number;
  irisR: number;
  look: [number, number];
  lid: number;
  lowerSquint?: number; // приподнятое нижнее веко при широкой тревожной улыбке
}> = ({clipId, cx, cy, eyeScale, irisR, look, lid, lowerSquint = 0}) => {
  const rx = 20.5 * eyeScale;
  const ry = 14.5 * eyeScale;
  const lidY = cy - ry + 2 * ry * clamp(lid, 0, 0.96);
  const botLift = lowerSquint * 4.5;
  const px = cx + clamp(look[0], -1, 1) * 7.5;
  const py = cy + clamp(look[1], -1, 1) * 4.5;

  return (
    <g>
      <defs>
        <clipPath id={clipId}>
          <ellipse cx={cx} cy={cy} rx={rx} ry={ry} />
        </clipPath>
      </defs>
      <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="#fffaf2" />
      <g clipPath={`url(#${clipId})`}>
        <circle cx={px} cy={py} r={irisR} fill={HERO_PAL.iris} />
        <circle cx={px} cy={py} r={irisR * 0.52} fill="#231108" />
        <circle cx={px - 3.2} cy={py - 3.0} r={2.7} fill="#ffffff" />
        <rect x={cx - rx - 4} y={cy - ry - 4} width={rx * 2 + 8} height={Math.max(0, lidY - (cy - ry - 4))} fill={HERO_PAL.skinBase} />
        {botLift > 0.2 && (
          <path
            d={`M ${cx - rx - 3} ${cy + ry + 5} L ${cx - rx - 3} ${cy + ry - botLift} Q ${cx} ${cy + ry - botLift - 4.5} ${cx + rx + 3} ${cy + ry - botLift} L ${cx + rx + 3} ${cy + ry + 5} Z`}
            fill={HERO_PAL.skinBase}
          />
        )}
      </g>
      <path
        d={`M ${cx - rx} ${lidY + 2.5} Q ${cx} ${lidY - 6.5} ${cx + rx} ${lidY + 2.5}`}
        fill="none"
        stroke="#2b160b"
        strokeWidth={4.4}
        strokeLinecap="round"
      />
      <path
        d={`M ${cx - rx + 3} ${cy + ry - 1 - botLift} Q ${cx} ${cy + ry + 2.5 - botLift * 1.3} ${cx + rx - 3} ${cy + ry - 1 - botLift}`}
        fill="none"
        stroke={HERO_PAL.skinLine}
        strokeWidth={1.7 + lowerSquint * 0.6}
        opacity={0.78}
      />
    </g>
  );
};

/**
 * Проработанная, объёмная и тревожная «слишком широкая улыбка» (Раздел 5):
 * плавное раскрытие уголков рта, приподнятые щёки, носогубные складки, глубина полости рта,
 * раздельные верхние и нижние зубы с мягким боковым затенением и контуром губ (НЕ белая полоска!).
 */
const ExpressiveUncannySmile: React.FC<{id: string; amount: number}> = ({id, amount}) => {
  const s = clamp(amount, 0, 1);
  const xL = lerp(489, 452, s);
  const xR = lerp(521, 558, s);
  const yCorner = lerp(280, 255, s);
  const yTopMid = lerp(280, 270, s);
  const yBotMid = lerp(281, 304, s);

  const mouthPath = `M ${xL} ${yCorner}
    C ${lerp(495, 478, s)} ${yTopMid}, ${lerp(515, 532, s)} ${yTopMid}, ${xR} ${yCorner}
    C ${lerp(518, 542, s)} ${yBotMid}, ${lerp(492, 468, s)} ${yBotMid}, ${xL} ${yCorner} Z`;

  return (
    <g>
      <defs>
        <clipPath id={`${id}-mouthClip`}>
          <path d={mouthPath} />
        </clipPath>
        <linearGradient id={`${id}-teethShade`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#cfc3b4" />
          <stop offset="18%" stopColor="#efe9de" />
          <stop offset="50%" stopColor="#fbf8f2" />
          <stop offset="82%" stopColor="#efe9de" />
          <stop offset="100%" stopColor="#cfc3b4" />
        </linearGradient>
        <linearGradient id={`${id}-oralDepth`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#240a0d" />
          <stop offset="100%" stopColor="#46161a" />
        </linearGradient>
      </defs>

      {/* Приподнятые яблочки щёк и напряжённые складки у уголков слишком широкого рта */}
      <ellipse cx={448} cy={258} rx={19} ry={11} fill="#e59e73" opacity={0.38 * s} transform="rotate(-12 448 258)" />
      <ellipse cx={562} cy={258} rx={19} ry={11} fill="#e59e73" opacity={0.38 * s} transform="rotate(12 562 258)" />
      <path
        d={`M ${xL + 5} ${yCorner - 10} Q ${xL - 8} ${yCorner + 2} ${xL + 2} ${yCorner + 15}`}
        fill="none"
        stroke={HERO_PAL.skinLine}
        strokeWidth={2.6}
        strokeLinecap="round"
        opacity={0.85 * s}
      />
      <path
        d={`M ${xR - 5} ${yCorner - 10} Q ${xR + 8} ${yCorner + 2} ${xR - 2} ${yCorner + 15}`}
        fill="none"
        stroke={HERO_PAL.skinLine}
        strokeWidth={2.6}
        strokeLinecap="round"
        opacity={0.85 * s}
      />

      {s > 0.16 ? (
        <g>
          {/* Внутренняя объёмная полость рта */}
          <g clipPath={`url(#${id}-mouthClip)`}>
            <rect x={445} y={248} width={120} height={64} fill={`url(#${id}-oralDepth)`} />
            {/* Глубина языка внизу полости рта */}
            <ellipse cx={505} cy={yBotMid + 3} rx={28 * s} ry={10 * s} fill="#7e3435" opacity={0.85} />

            {/* Верхний ряд проработанных зубов с индивидуальными межзубными линиями и тенью от верхней губы */}
            <path
              d={`M ${xL - 2} ${yCorner - 4}
                  Q 505 ${yTopMid - 4} ${xR + 2} ${yCorner - 4}
                  L ${xR - 4} ${lerp(280, 279, s)}
                  Q 505 ${lerp(281, 285, s)} ${xL + 4} ${lerp(280, 279, s)} Z`}
              fill={`url(#${id}-teethShade)`}
              stroke="#b5a695"
              strokeWidth={1.2}
            />
            {/* Мягкая тень под верхней губой */}
            <path
              d={`M ${xL} ${yCorner} Q 505 ${yTopMid + 2} ${xR} ${yCorner}`}
              fill="none"
              stroke="#c4b5a4"
              strokeWidth={2.6}
              opacity={0.65}
            />
            {/* Разделители отдельных верхних зубов */}
            {[-31, -20, -10, 0, 10, 20, 31].map((dx, ti) => (
              <line
                key={`ut-${ti}`}
                x1={505 + dx * s}
                y1={yTopMid - 3}
                x2={505 + dx * 0.96 * s}
                y2={285}
                stroke="#b8aa99"
                strokeWidth={ti === 3 ? 1.6 : 1.3}
                opacity={0.82}
              />
            ))}

            {/* Нижний ряд зубов (чуть в тени, придаёт настоящую челюстную анатомию) */}
            {s > 0.35 && (
              <g opacity={(s - 0.35) / 0.65}>
                <path
                  d={`M ${xL + 10} ${yBotMid - 5}
                      Q 505 ${yBotMid - 10} ${xR - 10} ${yBotMid - 5}
                      L ${xR - 8} ${yBotMid + 4}
                      Q 505 ${yBotMid + 6} ${xL + 8} ${yBotMid + 4} Z`}
                  fill="#ded5c7"
                  stroke="#a89a89"
                  strokeWidth={1.1}
                />
                {[-22, -11, 0, 11, 22].map((dx, bi) => (
                  <line
                    key={`bt-${bi}`}
                    x1={505 + dx * s}
                    y1={yBotMid - 10}
                    x2={505 + dx * s}
                    y2={yBotMid + 3}
                    stroke="#a89a89"
                    strokeWidth={1.2}
                    opacity={0.75}
                  />
                ))}
              </g>
            )}
          </g>

          {/* Верхняя и нижняя губы */}
          <path
            d={`M ${xL} ${yCorner} C ${lerp(495, 478, s)} ${yTopMid}, ${lerp(515, 532, s)} ${yTopMid}, ${xR} ${yCorner}`}
            fill="none"
            stroke="#7d3b2c"
            strokeWidth={3.8}
            strokeLinecap="round"
          />
          <path
            d={`M ${xL} ${yCorner} C ${lerp(492, 468, s)} ${yBotMid}, ${lerp(518, 542, s)} ${yBotMid}, ${xR} ${yCorner}`}
            fill="none"
            stroke="#9c513f"
            strokeWidth={3.4}
            strokeLinecap="round"
          />
          {/* Световая грань нижней губы */}
          <path
            d={`M ${lerp(492, 478, s)} ${yBotMid + 2.5} Q 505 ${yBotMid + 5.5} ${lerp(518, 532, s)} ${yBotMid + 2.5}`}
            fill="none"
            stroke="#f7cfb0"
            strokeWidth={2}
            strokeLinecap="round"
            opacity={0.55 * s}
          />
        </g>
      ) : (
        <path
          d={`M ${xL} ${yCorner} Q 505 ${yBotMid} ${xR} ${yCorner}`}
          fill="none"
          stroke="#854232"
          strokeWidth={4.2}
          strokeLinecap="round"
        />
      )}
    </g>
  );
};

export const HeroHeadCanonical: React.FC<{
  id: string;
  emotion?: HeroEmotion;
  look?: [number, number];
  tilt?: number;
  headYaw?: number;
  wideSmile?: number;
  talkOpen?: number;
  driverCap?: boolean;
  blinkSeed?: number;
}> = ({
  id,
  emotion = 'calm',
  look = [0, 0],
  tilt = 0,
  headYaw = 0,
  wideSmile = 0,
  talkOpen = 0,
  driverCap = false,
  blinkSeed = 0,
}) => {
  const frame = useCurrentFrame();
  const spec = EMO_SPEC[emotion];
  const cyc = (frame + blinkSeed * 13) % 124;
  const autoBlink = blinkSeed >= 900 ? 0 : cyc < 5 ? Math.sin((cyc / 5) * Math.PI) * (1 - spec.lid) : 0;
  const lid = clamp((wideSmile > 0.35 ? 0.02 : spec.lid) + autoBlink, 0, 0.96);
  const eyeBonus = wideSmile > 0.2 ? 1 + wideSmile * 0.08 : 1;

  const yaw = clamp(headYaw, -0.75, 0.75);
  const fx = yaw * 20;
  const earLX = 412 + Math.max(0, yaw) * 11;
  const earRX = 598 + Math.min(0, yaw) * 11;
  const browY = 204 + spec.browY - wideSmile * 3;

  return (
    <g transform={`rotate(${tilt} 505 300)`}>
      <defs>
        <linearGradient id={`${id}-faceG`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={HERO_PAL.skinTop} />
          <stop offset="100%" stopColor={HERO_PAL.skinBase} />
        </linearGradient>
        <linearGradient id={`${id}-hairG`} x1="0" y1="0" x2="0.8" y2="1">
          <stop offset="0%" stopColor={HERO_PAL.hairLight} />
          <stop offset="55%" stopColor={HERO_PAL.hairBase} />
          <stop offset="100%" stopColor={HERO_PAL.hairDark} />
        </linearGradient>
      </defs>

      <ellipse cx={earLX} cy={238} rx={14} ry={21} fill={HERO_PAL.skinShade} />
      <path d={`M ${earLX - 3} 231 q 6 -4 8 6`} fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.6} strokeLinecap="round" />
      <ellipse cx={earRX} cy={238} rx={14} ry={21} fill={HERO_PAL.skinShade} />
      <path d={`M ${earRX + 3} 231 q -6 -4 -8 6`} fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.6} strokeLinecap="round" />

      <path
        d="M 416 214 C 416 286, 456 314, 505 314 C 554 314, 594 286, 594 214 C 594 166, 560 148, 505 148 C 450 148, 416 166, 416 214 Z"
        fill={`url(#${id}-faceG)`}
      />

      <path d="M 472 134 L 483 97 L 502 126 L 522 95 L 532 124 L 551 107 L 549 140 Z" fill={`url(#${id}-hairG)`} />
      <path
        d="M 407 236 C 398 168, 432 120, 505 118 C 580 118, 613 168, 603 236 L 592 214 C 588 190, 570 180, 548 188 C 526 174, 472 170, 442 190 C 428 198, 420 212, 417 236 Z"
        fill={`url(#${id}-hairG)`}
      />

      {driverCap && (
        <g transform={`translate(${fx * 0.35} 0)`}>
          <path d="M 402 184 C 404 114, 606 114, 608 184 Z" fill="#18223d" stroke="#2d3e6e" strokeWidth={3} />
          <rect x={402} y={172} width={206} height={18} rx={6} fill="#10172b" />
          <ellipse cx={505} cy={152} rx={15} ry={9} fill="#3a4f87" />
          <path d="M 396 184 Q 505 208 614 184 Q 588 168 505 168 Q 422 168 396 184 Z" fill="#0b1020" />
        </g>
      )}

      <g transform={`translate(${fx} 0)`}>
        <path
          d={`M 452 ${browY + spec.browTilt * 0.5} L 493 ${browY - spec.browTilt * 0.7}`}
          stroke={HERO_PAL.brow}
          strokeWidth={8.5}
          strokeLinecap="round"
        />
        <path
          d={`M 517 ${browY - spec.browTilt * 0.7} L 558 ${browY + spec.browTilt * 0.5}`}
          stroke={HERO_PAL.brow}
          strokeWidth={8.5}
          strokeLinecap="round"
        />

        <EyeUnit
          clipId={`${id}-eL`}
          cx={475}
          cy={229}
          eyeScale={spec.eyeScale * eyeBonus}
          irisR={spec.irisR * (1 - wideSmile * 0.12)}
          look={look}
          lid={lid}
          lowerSquint={wideSmile}
        />
        <EyeUnit
          clipId={`${id}-eR`}
          cx={535}
          cy={229}
          eyeScale={spec.eyeScale * eyeBonus}
          irisR={spec.irisR * (1 - wideSmile * 0.12)}
          look={look}
          lid={lid}
          lowerSquint={wideSmile}
        />

        <path d="M 504 240 q 10 16 -2 22" fill="none" stroke={HERO_PAL.skinLine} strokeWidth={3.8} strokeLinecap="round" />

        {wideSmile > 0.02 ? (
          <ExpressiveUncannySmile id={`${id}-sm`} amount={wideSmile} />
        ) : Math.max(spec.mouthOpen, talkOpen) > 0.06 ? (
          <g>
            <ellipse
              cx={505}
              cy={280}
              rx={lerp(11, 14, Math.max(spec.mouthOpen, talkOpen))}
              ry={3 + Math.max(spec.mouthOpen, talkOpen) * 7.5}
              fill="#54211d"
            />
            <ellipse
              cx={505}
              cy={283 + Math.max(spec.mouthOpen, talkOpen) * 2.5}
              rx={7}
              ry={2.2 + Math.max(spec.mouthOpen, talkOpen) * 2}
              fill="#bf6457"
            />
          </g>
        ) : (
          <path
            d={`M ${505 - spec.mouthW / 2} 280 Q 505 ${280 + spec.mouthCurve} ${505 + spec.mouthW / 2} 280`}
            fill="none"
            stroke="#8a4c38"
            strokeWidth={4.2}
            strokeLinecap="round"
          />
        )}
      </g>
    </g>
  );
};

/**
 * Различимый влажный след ладони на плече толстовки Героя из 2-й серии (Раздел 3Б):
 * мягкий ореол намокшей ткани + контур ладони и 5 пальцев поверх плеча, единообразный между кадрами.
 */
export const WetShoulderHandprintMark: React.FC<{
  cx: number;
  cy: number;
  side: 'left' | 'right';
  opacity?: number;
}> = ({cx, cy, side, opacity = 0.72}) => {
  const sx = side === 'left' ? 1 : -1;
  return (
    <g transform={`translate(${cx} ${cy}) scale(${sx * 0.88} 0.86) rotate(-8)`} opacity={opacity}>
      {/* Влажный тёмный ореол впитавшейся воды на синей ткани */}
      <ellipse cx={0} cy={6} rx={30} ry={26} fill="#253c6e" opacity={0.55} />
      {/* Пятно мокрой ладони и 5 пальцев, заходящих сверху на плечо */}
      <path
        d="M -18 -14
           C -10 -20, 12 -20, 19 -12
           C 23 -4, 22 6, 18 14
           L 19 28 C 19 33, 13 33, 12 28 L 10 15
           L 8 32 C 8 37, 2 37, 1 32 L 0 16
           L -3 31 C -4 36, -10 36, -10 30 L -9 15
           L -14 26 C -15 31, -21 29, -20 24 L -17 11
           C -22 6, -24 -6, -18 -14 Z"
        fill="#1a2c54"
        stroke="#6da6e8"
        strokeWidth={1.1}
        strokeOpacity={0.35}
      />
      {/* Отпечаток большого пальца с внутренней стороны */}
      <path d="M 16 -2 L 29 8 C 33 12, 28 18, 23 14 L 14 6 Z" fill="#1a2c54" />
      {/* Едва заметный влажный холодный отблеск */}
      <circle cx={-5} cy={2} r={2.2} fill="#8cc2ff" opacity={0.42} />
    </g>
  );
};

/**
 * Ладонь Двойника, прижатая снаружи к стеклу в ОБЩЕМ и СРЕДНЕМ планах (Раздел 3А):
 * крепится прямо к поднятому предплечью Двойника, поэтому между общим планом, средним планом
 * и крупным планом мокрой ладони сохраняется 100% непрерывность положения руки, конденсата и капель!
 */
export const PalmPressedOnGlassHand: React.FC<{dripPhase?: number}> = ({dripPhase = 0}) => {
  const d1 = (dripPhase * 18) % 44;
  const d2 = ((dripPhase + 1.1) * 15) % 36;
  // Предплечье при armL=52, elbowL=-130 направлено вверх (около 168°), поэтому rotate(188) ставит пальцы вертикально вверх!
  return (
    <g transform="rotate(188) translate(0 -28)">
      {/* Ореол запотевания на стекле вокруг ладони */}
      <ellipse cx={0} cy={-18} rx={48} ry={58} fill="#bfe0ff" opacity={0.26} />
      {/* Запястье внахлёст с манжетой */}
      <rect x={-16} y={14} width={32} height={22} rx={8} fill={HERO_PAL.skinBase} />
      {/* Открытая 5-палая ладонь, прижатая к стеклу */}
      <path
        d="M -21 22
           C -25 4, -25 -12, -21 -22
           L -24 -52 C -25 -60, -16 -61, -15 -52 L -11 -24
           L -9 -60 C -9 -68, -1 -68, 0 -60 L 1 -25
           L 6 -56 C 7 -64, 15 -63, 15 -55 L 11 -22
           L 19 -44 C 21 -51, 28 -49, 27 -41 L 19 -12
           C 23 0, 23 12, 20 22
           C 14 32, -12 34, -21 22 Z"
        fill={HERO_PAL.skinBase}
        stroke={HERO_PAL.skinLine}
        strokeWidth={2}
      />
      <path d="M -20 12 L -40 -8 C -45 -14, -37 -21, -31 -15 L -17 0 Z" fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
      {/* Светлые пятна контакта подушечек с холодным стеклом */}
      <ellipse cx={-5} cy={-4} rx={9} ry={7} fill="#fdf0e4" opacity={0.62} />
      <ellipse cx={8} cy={5} rx={8} ry={9} fill="#fdf0e4" opacity={0.62} />
      <circle cx={-5} cy={-54} r={3.5} fill="#fdf0e4" opacity={0.62} />
      <circle cx={10} cy={-50} r={3.2} fill="#fdf0e4" opacity={0.62} />
      {/* Стекающие от мокрой ладони капли воды */}
      <circle cx={-8} cy={28 + d1} r={2.8} fill="#9fd4ff" opacity={1 - d1 / 46} />
      <circle cx={10} cy={25 + d2} r={2.4} fill="#9fd4ff" opacity={1 - d2 / 38} />
    </g>
  );
};

const RelaxedHand: React.FC<{flipThumb?: boolean}> = ({flipThumb = false}) => (
  <g transform={flipThumb ? 'scale(-1 1)' : undefined}>
    <rect x={-16} y={-12} width={32} height={18} rx={8} fill={HERO_PAL.skinBase} />
    <path d="M -19 -2 Q -22 34 -10 50 Q 0 58 12 50 Q 22 34 19 -2 Z" fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
    <path d="M -18 12 Q -31 20 -27 38 Q -23 45 -15 38 Z" fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
    <path d="M -6 26 V 46 M 3 26 V 48 M 11 25 V 43" stroke={HERO_PAL.skinLine} strokeWidth={1.8} strokeLinecap="round" opacity={0.75} />
  </g>
);

const ConnectedArm: React.FC<{
  gid: string;
  elbowDeg: number;
  side: 'L' | 'R';
  handNode?: React.ReactNode;
}> = ({gid, elbowDeg, side, handNode}) => (
  <g>
    <defs>
      <linearGradient id={gid} x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stopColor={HERO_PAL.hoodLight} />
        <stop offset="55%" stopColor={HERO_PAL.hoodBase} />
        <stop offset="100%" stopColor={HERO_PAL.hoodDark} />
      </linearGradient>
    </defs>
    <circle cx={0} cy={0} r={31} fill={`url(#${gid})`} />
    <path d="M -30 0 Q -32 68 -27 146 L 27 146 Q 32 68 30 0 Z" fill={`url(#${gid})`} />
    <g transform={`translate(0 146) rotate(${elbowDeg})`}>
      <circle cx={0} cy={0} r={27} fill={HERO_PAL.hoodBase} />
      <path d="M -27 0 Q -26 58 -23 128 L 23 128 Q 26 58 27 0 Z" fill={`url(#${gid})`} />
      <rect x={-25} y={110} width={50} height={24} rx={8} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={1.8} />
      <g transform="translate(0 132)">
        {handNode !== undefined ? handNode : <RelaxedHand flipThumb={side === 'R'} />}
      </g>
    </g>
  </g>
);

export type HeroFigureProps = {
  id: string;
  x: number;
  y: number;
  scale?: number;
  anchor?: [number, number];
  flip?: boolean;
  emotion?: HeroEmotion;
  look?: [number, number];
  tilt?: number;
  headYaw?: number;
  wideSmile?: number;
  talkOpen?: number;
  armL?: number;
  armR?: number;
  elbowL?: number;
  elbowR?: number;
  handLNode?: React.ReactNode;
  handRNode?: React.ReactNode;
  frontLeftArm?: boolean; // рисует поднятую левую руку ПЕРЕД торсом (например, когда ладонь прижата к стеклу перед собой!)
  legs?: boolean;
  walkPhase?: number;
  dampShoulders?: boolean;
  shade?: number;
  shadeColor?: [number, number, number];
  opacity?: number;
  blinkSeed?: number;
};

export const HeroFigure: React.FC<HeroFigureProps> = ({
  id,
  x,
  y,
  scale = 1,
  anchor = [505, 930],
  flip = false,
  emotion = 'calm',
  look = [0, 0],
  tilt = 0,
  headYaw = 0,
  wideSmile = 0,
  talkOpen = 0,
  armL = 82,
  armR = 82,
  elbowL = 6,
  elbowR = 6,
  handLNode,
  handRNode,
  frontLeftArm = false,
  legs = true,
  walkPhase,
  dampShoulders = false,
  shade = 0,
  shadeColor = [0.05, 0.08, 0.18],
  opacity = 1,
  blinkSeed = 0,
}) => {
  const frame = useCurrentFrame();
  const breathe = Math.sin(frame / 22 + blinkSeed) * 1.2;
  const walkBob = walkPhase !== undefined ? Math.abs(Math.sin(walkPhase)) * -8 : 0;

  const rL = 90 - armL;
  const rR = -(90 - armR);
  const legSwingL = walkPhase !== undefined ? Math.sin(walkPhase) * 14 : 0;
  const legSwingR = walkPhase !== undefined ? -Math.sin(walkPhase) * 14 : 0;

  const [sr, sg, sb] = shadeColor;
  const matrix = `${1 - shade} 0 0 0 ${shade * sr}  0 ${1 - shade} 0 0 ${shade * sg}  0 0 ${1 - shade} 0 ${shade * sb}  0 0 0 1 0`;

  const leftArmElem = (
    <g transform={`translate(432 ${370 + breathe * 0.4}) rotate(${rL})`}>
      <ConnectedArm gid={`${id}-armL`} elbowDeg={-elbowL} side="L" handNode={handLNode} />
    </g>
  );

  return (
    <g
      transform={`translate(${x} ${y + walkBob}) scale(${flip ? -scale : scale} ${scale}) translate(${-anchor[0]} ${-anchor[1]})`}
      opacity={opacity}
    >
      <defs>
        <filter id={`${id}-shf`} colorInterpolationFilters="sRGB">
          <feColorMatrix type="matrix" values={matrix} />
        </filter>
        <linearGradient id={`${id}-torsoG`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={HERO_PAL.hoodBase} />
          <stop offset="48%" stopColor={HERO_PAL.hoodLight} />
          <stop offset="100%" stopColor={HERO_PAL.hoodDark} />
        </linearGradient>
        <linearGradient id={`${id}-pantsG`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={HERO_PAL.pantsLight} />
          <stop offset="100%" stopColor={HERO_PAL.pantsDark} />
        </linearGradient>
      </defs>

      <g filter={shade > 0.005 ? `url(#${id}-shf)` : undefined}>
        {legs && (
          <g>
            <g transform={`rotate(${legSwingL} 464 564)`}>
              <path d="M 424 560 L 502 560 L 484 880 L 414 880 Z" fill={`url(#${id}-pantsG)`} />
              <path d="M 414 878 L 484 878 L 487 908 Q 486 926 468 928 L 382 929 Q 368 924 375 906 Q 382 892 414 878 Z" fill={HERO_PAL.shoeBase} />
              <path d="M 374 911 Q 371 928 386 930 L 472 929 Q 487 926 486 912 Z" fill={HERO_PAL.shoeSole} />
              <path d="M 406 894 l 20 -5 M 400 903 l 24 -6 M 416 886 l 16 -3" stroke="#626673" strokeWidth={2.8} strokeLinecap="round" />
            </g>
            <g transform={`rotate(${legSwingR} 546 564)`}>
              <path d="M 508 560 L 586 560 L 596 880 L 526 880 Z" fill={`url(#${id}-pantsG)`} />
              <path d="M 526 878 L 596 878 Q 628 892 635 906 Q 642 924 628 929 L 542 928 Q 524 926 523 908 Z" fill={HERO_PAL.shoeBase} />
              <path d="M 524 912 Q 523 926 538 929 L 624 930 Q 639 928 636 911 Z" fill={HERO_PAL.shoeSole} />
              <path d="M 604 894 l -20 -5 M 610 903 l -24 -6 M 594 886 l -16 -3" stroke="#626673" strokeWidth={2.8} strokeLinecap="round" />
            </g>
            <path d="M 492 560 L 518 560 L 510 605 L 500 605 Z" fill={HERO_PAL.pantsDark} />
          </g>
        )}

        {!frontLeftArm && leftArmElem}
        <g transform={`translate(578 ${370 + breathe * 0.4}) rotate(${rR})`}>
          <ConnectedArm gid={`${id}-armR`} elbowDeg={elbowR} side="R" handNode={handRNode} />
        </g>

        <g transform={`translate(0 ${breathe * 0.4})`}>
          <path
            d="M 426 338 Q 505 322 584 338 Q 596 346 592 380 L 588 552 L 422 552 L 418 380 Q 414 346 426 338 Z"
            fill={`url(#${id}-torsoG)`}
          />
          <path d="M 418 392 Q 428 358 446 346" fill="none" stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} opacity={0.45} />
          <path d="M 592 392 Q 582 358 564 346" fill="none" stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} opacity={0.45} />

          <rect x={420} y={538} width={170} height={34} rx={11} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
          <path
            d="M 452 476 L 558 476 Q 568 476 572 486 L 583 538 L 427 538 L 438 486 Q 442 476 452 476 Z"
            fill={HERO_PAL.hoodDark}
            opacity={0.62}
            stroke={HERO_PAL.hoodDeep}
            strokeWidth={2.8}
          />

          <rect x={479} y={292} width={52} height={60} rx={14} fill={HERO_PAL.skinShade} />
          <path
            d="M 428 350 C 424 318, 448 298, 480 304 L 505 352 L 530 304 C 562 298, 586 318, 582 350 L 560 358 C 546 344, 524 348, 505 368 C 486 348, 464 344, 450 358 Z"
            fill={HERO_PAL.hoodLight}
            stroke={HERO_PAL.hoodDeep}
            strokeWidth={3}
            strokeLinejoin="round"
          />
          <path d="M 487 360 V 436 M 523 360 V 436" stroke={HERO_PAL.hoodDeep} strokeWidth={7} strokeLinecap="round" />
          <circle cx={487} cy={439} r={4.5} fill={HERO_PAL.hoodDeep} />
          <circle cx={523} cy={439} r={4.5} fill={HERO_PAL.hoodDeep} />

          {/* Два различимых мокрых следа ладоней на левом и правом плечах Героя (преемственность со 2-й серией!) */}
          {dampShoulders && (
            <g>
              <WetShoulderHandprintMark cx={452} cy={368} side="left" opacity={0.72} />
              <WetShoulderHandprintMark cx={558} cy={368} side="right" opacity={0.72} />
            </g>
          )}
        </g>

        <g transform={`translate(0 ${breathe * 0.55})`}>
          <HeroHeadCanonical
            id={id}
            emotion={emotion}
            look={look}
            tilt={tilt}
            headYaw={headYaw}
            wideSmile={wideSmile}
            talkOpen={talkOpen}
            blinkSeed={blinkSeed}
          />
        </g>

        {frontLeftArm && leftArmElem}
      </g>
    </g>
  );
};

export const HeroSteppingBackToPole: React.FC<{
  id: string;
  backX: number;
  floorY: number;
  stepCycle: number;
  impactJolt: number;
}> = ({id, backX, floorY, stepCycle, impactJolt}) => {
  const legA = Math.sin(stepCycle) * 10;
  const legB = -Math.sin(stepCycle) * 10;

  return (
    <g transform={`translate(${backX} ${floorY})`}>
      <g transform="translate(82 -480) rotate(-6)">
        <circle cx={0} cy={0} r={24} fill={HERO_PAL.hoodDark} />
        <rect x={-22} y={0} width={44} height={118} rx={20} fill={HERO_PAL.hoodDark} />
        <g transform="translate(0 110) rotate(-8)">
          <rect x={-20} y={0} width={40} height={105} rx={18} fill={HERO_PAL.hoodDark} />
          <ellipse cx={0} cy={114} rx={17} ry={22} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2} />
        </g>
      </g>

      <g transform={`translate(56 -330) rotate(${legA})`}>
        <path d="M -28 0 L 34 0 L 38 286 L -22 286 Z" fill={HERO_PAL.pantsDark} />
        <path d="M -24 284 L 40 284 Q 76 296 82 314 Q 86 328 70 330 L -18 330 Q -28 328 -24 284 Z" fill={HERO_PAL.shoeBase} />
        <rect x={-24} y={318} width={104} height={12} rx={5} fill={HERO_PAL.shoeSole} />
      </g>
      <g transform={`translate(96 -330) rotate(${legB})`}>
        <path d="M -30 0 L 36 0 L 42 286 L -22 286 Z" fill={HERO_PAL.pantsBase} />
        <path d="M -24 284 L 44 284 Q 82 296 88 314 Q 92 328 76 330 L -18 330 Q -28 328 -24 284 Z" fill={HERO_PAL.shoeBase} />
        <rect x={-24} y={318} width={110} height={12} rx={5} fill={HERO_PAL.shoeSole} />
        <path d="M 48 298 l -18 -4 M 56 306 l -20 -4" stroke="#636775" strokeWidth={2.6} strokeLinecap="round" />
      </g>

      <path
        d={`M 0 -495
            C 2 -430, 0 -375, 3 -330
            L 146 -330
            L 152 -492
            C 150 -528, 122 -546, 76 -546
            C 28 -546, 2 -528, 0 -495 Z`}
        fill={HERO_PAL.hoodBase}
        stroke={HERO_PAL.hoodDeep}
        strokeWidth={3}
      />
      {impactJolt > 0.05 && (
        <path d="M 3 -480 Q 16 -445 4 -410 M 3 -395 Q 14 -368 4 -345" fill="none" stroke={HERO_PAL.hoodDeep} strokeWidth={3} opacity={impactJolt * 0.85} />
      )}
      <rect x={2} y={-354} width={146} height={28} rx={9} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
      <path d="M 62 -412 L 142 -412 L 147 -354 L 52 -354 Z" fill={HERO_PAL.hoodDark} opacity={0.6} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />

      <rect x={58} y={-586} width={48} height={54} rx={12} fill={HERO_PAL.skinShade} />
      <path
        d="M 4 -528 C 6 -558, 38 -570, 74 -562 L 116 -528 L 142 -554 C 156 -542, 156 -518, 140 -512 C 102 -504, 34 -506, 4 -528 Z"
        fill={HERO_PAL.hoodLight}
        stroke={HERO_PAL.hoodDeep}
        strokeWidth={3}
      />
      <path d="M 106 -514 V -446 M 128 -514 V -448" stroke={HERO_PAL.hoodDeep} strokeWidth={6} strokeLinecap="round" />
      {/* Мокрый след ладони на ближнем плече */}
      <WetShoulderHandprintMark cx={82} cy={-496} side="right" opacity={0.68} />

      <g transform={`translate(${82 - 505} ${-560 - 300}) rotate(${-impactJolt * 4} 505 300)`}>
        <HeroHeadCanonical
          id={`${id}-head`}
          emotion="scared"
          look={[0.68, 0.35]}
          headYaw={0.34}
          blinkSeed={31}
        />
      </g>

      <g transform="translate(86 -484) rotate(-52)">
        <circle cx={0} cy={0} r={27} fill={HERO_PAL.hoodLight} />
        <path d="M -25 0 L 25 0 L 23 128 L -23 128 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
        <g transform="translate(0 124) rotate(-18)">
          <circle cx={0} cy={0} r={24} fill={HERO_PAL.hoodBase} />
          <path d="M -23 0 L 23 0 L 21 114 L -21 114 Z" fill={HERO_PAL.hoodLight} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />
          <rect x={-23} y={98} width={46} height={20} rx={7} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2} />

          <g transform="translate(0 122)">
            <ellipse cx={0} cy={12} rx={19} ry={22} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
            <g transform="translate(8 20) rotate(24)">
              <rect x={-16} y={-34} width={34} height={74} rx={8} fill="#0c101d" stroke="#536694" strokeWidth={2.6} />
              <circle cx={18} cy={18} r={8} fill="#ffffff" />
              <circle cx={18} cy={18} r={20} fill="#d4e8ff" opacity={0.48} />
              {[-18, -5, 8, 20].map((fy, fi) => (
                <rect key={fi} x={-21} y={fy} width={18} height={10} rx={5} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={1.6} />
              ))}
              <path d="M -6 -22 C 8 -28, 20 -18, 16 -4 C 12 6, -2 4, -8 -8 Z" fill={HERO_PAL.skinTop} stroke={HERO_PAL.skinLine} strokeWidth={1.8} />
            </g>
          </g>
        </g>
      </g>
    </g>
  );
};

/**
 * СЦЕНА 7 (Раздел 7): Настоящий Герой в понятном ракурсе 3/4 со спины и в профиль ЛИЦОМ К ОКНУ!
 * Зритель одновременно видит:
 * 1) что герой стоит лицом к стеклу (видна спина толстовки, капюшон, мокрые следы на плечах и опущенные руки),
 * 2) его профиль (бровь, расширенный испуганный глаз и щеку, обращённые к стеклу — живая реакция на отражение!).
 */
export const HeroThreeQuarterFacingWindow: React.FC<{
  x: number;
  y: number;
  scale?: number;
  shockAmount?: number; // 0..1 расширение глаза и подъём брови при виде самостоятельного отражения
}> = ({x, y, scale = 1, shockAmount = 0}) => (
  <g transform={`translate(${x} ${y}) scale(${scale}) translate(-505 -930)`}>
    {/* Ноги в A-стойке */}
    <path d="M 424 560 L 502 560 L 486 895 L 418 895 Z" fill={HERO_PAL.pantsBase} />
    <path d="M 508 560 L 586 560 L 592 895 L 524 895 Z" fill={HERO_PAL.pantsDark} />

    {/* Обе руки спокойно опущены вдоль тела (НЕ повторяет жест отражения!) */}
    <path d="M 398 366 Q 388 468 394 590 L 434 590 L 438 366 Z" fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />
    <ellipse cx={412} cy={612} rx={17} ry={24} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2} />
    <path d="M 572 366 L 576 590 L 616 590 Q 622 468 612 366 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />
    <ellipse cx={598} cy={612} rx={17} ry={24} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />

    {/* Спина синей толстовки и капюшон сзади */}
    <path
      d="M 424 340 Q 505 324 586 340 Q 598 350 594 384 L 590 562 L 420 562 L 416 384 Q 412 350 424 340 Z"
      fill={HERO_PAL.hoodBase}
      stroke={HERO_PAL.hoodDeep}
      strokeWidth={3}
    />
    <rect x={420} y={538} width={170} height={30} rx={10} fill={HERO_PAL.hoodDark} />
    <path
      d="M 432 344 C 436 416, 476 444, 507 446 C 538 444, 578 416, 582 344 C 556 330, 458 330, 432 344 Z"
      fill={HERO_PAL.hoodLight}
      stroke={HERO_PAL.hoodDeep}
      strokeWidth={3.2}
    />
    <path d="M 507 340 V 442" stroke={HERO_PAL.hoodDeep} strokeWidth={3} opacity={0.5} />
    {/* Мокрые следы ладоней на обоих плечах */}
    <WetShoulderHandprintMark cx={448} cy={358} side="left" opacity={0.68} />
    <WetShoulderHandprintMark cx={564} cy={358} side="right" opacity={0.68} />

    {/* Шея и голова в ракурсе 3/4 в профиль ВЛЕВО-ВГЛУБЬ К СТЕКЛУ ОКНА (видна реакция левого глаза!) */}
    <rect x={478} y={290} width={52} height={58} rx={12} fill={HERO_PAL.skinShade} />
    {/* Контур левой щеки, носа и подбородка, обращённых к стеклу окна */}
    <path
      d="M 428 192 C 414 212, 412 232, 402 246 C 398 252, 405 258, 414 259 C 414 282, 428 302, 462 306 L 520 302 L 520 182 Z"
      fill={HERO_PAL.skinBase}
    />
    {/* Выразительный глаз и приподнятая бровь в профиль (реакция испуга при взгляде на отражение!) */}
    <path
      d={`M 418 ${208 - shockAmount * 8} L 446 ${205 - shockAmount * 4}`}
      stroke={HERO_PAL.brow}
      strokeWidth={7}
      strokeLinecap="round"
    />
    <ellipse cx={430} cy={229} rx={11 + shockAmount * 2} ry={12 + shockAmount * 3} fill="#fffaf2" />
    <circle cx={425} cy={229} r={6.8} fill={HERO_PAL.iris} />
    <circle cx={424} cy={229} r={3.5} fill="#231108" />
    <circle cx={423} cy={226.5} r={2} fill="#ffffff" />
    <path d={`M 418 ${222 - shockAmount * 3} Q 430 ${214 - shockAmount * 4} 442 224`} fill="none" stroke="#2b160b" strokeWidth={3.8} strokeLinecap="round" />
    {/* Приоткрытый от удивления уголок рта в профиль */}
    <path d={`M 417 276 Q 426 ${277 + shockAmount * 5} 433 276`} fill="none" stroke="#7d4332" strokeWidth={3.2} strokeLinecap="round" />

    {/* Ухо и каштановый затылок с 3 фирменными прядями */}
    <ellipse cx={484} cy={244} rx={13} ry={21} fill={HERO_PAL.skinShade} />
    <path d="M 481 237 q 5 -4 7 6" fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.4} strokeLinecap="round" />
    <path d="M 468 134 L 480 98 L 500 126 L 520 96 L 530 124 L 548 108 L 546 140 Z" fill={HERO_PAL.hairBase} />
    <path
      d="M 426 196 C 430 144, 466 116, 516 118 C 578 120, 600 168, 588 232 C 578 272, 548 296, 500 296 C 488 296, 484 274, 488 250 C 492 224, 476 202, 448 198 Z"
      fill={HERO_PAL.hairBase}
    />
    <path d="M 492 258 C 516 276, 558 272, 584 242 C 572 276, 542 296, 500 296 Z" fill={HERO_PAL.hairDark} opacity={0.52} />
  </g>
);

export const DoubleCountingHandCloseUp: React.FC<{
  mode: 'threeToTwo' | 'one';
  bendProgress?: number;
  raiseProgress?: number;
}> = ({mode, bendProgress = 0, raiseProgress = 1}) => {
  const ySlide = lerp(210, 0, raiseProgress);
  const idxRatio = 1;
  const midRatio = mode === 'one' ? 0 : 1;
  const ringRatio = mode === 'one' ? 0 : 1 - clamp(bendProgress, 0, 1);
  const pinkyRatio = 0;

  const drawFinger = (fx: number, baseY: number, fullLen: number, fw: number, up: number, key: string) => {
    const curLen = lerp(-36, fullLen, up);
    if (curLen >= 18) {
      return (
        <g key={key}>
          <rect
            x={fx - fw / 2}
            y={baseY - curLen}
            width={fw}
            height={curLen + 20}
            rx={fw / 2}
            fill={HERO_PAL.skinBase}
            stroke={HERO_PAL.skinLine}
            strokeWidth={3.2}
          />
          <line x1={fx - fw * 0.3} y1={baseY - curLen * 0.36} x2={fx + fw * 0.3} y2={baseY - curLen * 0.36} stroke={HERO_PAL.skinLine} strokeWidth={2.3} strokeLinecap="round" />
          <line x1={fx - fw * 0.28} y1={baseY - curLen * 0.68} x2={fx + fw * 0.28} y2={baseY - curLen * 0.68} stroke={HERO_PAL.skinLine} strokeWidth={2.1} strokeLinecap="round" />
        </g>
      );
    }
    const foldH = lerp(28, 54, -curLen / 36);
    return (
      <g key={key}>
        <rect x={fx - fw / 2} y={baseY - 16} width={fw} height={foldH} rx={fw / 2} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={3.2} />
        <ellipse cx={fx} cy={baseY + foldH - 26} rx={fw * 0.32} ry={6.5} fill="#fae2cb" opacity={0.65} />
      </g>
    );
  };

  return (
    <g transform={`translate(615 ${955 + ySlide}) scale(1.68)`}>
      <path d="M -82 178 L -102 390 L 104 390 L 84 178 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={3.8} />
      <rect x={-88} y={146} width={176} height={40} rx={13} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={3.4} />
      <rect x={-56} y={104} width={112} height={52} rx={16} fill={HERO_PAL.skinBase} />
      <path
        d="M -78 16 C -84 -18, -68 -38, -46 -38 L 48 -38 C 72 -38, 84 -16, 80 22 L 74 86 C 68 122, 38 136, 0 136 C -42 136, -72 118, -76 80 Z"
        fill={HERO_PAL.skinBase}
        stroke={HERO_PAL.skinLine}
        strokeWidth={3.4}
      />
      <path d="M -50 26 Q 6 12 54 34 M -34 58 Q 10 46 46 70" fill="none" stroke={HERO_PAL.skinLine} strokeWidth={2.5} strokeLinecap="round" opacity={0.7} />

      {idxRatio > 0.34 && drawFinger(-46, -28, 138, 27, idxRatio, 'u-idx')}
      {midRatio > 0.34 && drawFinger(-15, -34, 154, 28, midRatio, 'u-mid')}
      {ringRatio > 0.34 && drawFinger(16, -30, 140, 27, ringRatio, 'u-ring')}
      {pinkyRatio > 0.34 && drawFinger(46, -20, 112, 24, pinkyRatio, 'u-pnk')}

      {idxRatio <= 0.34 && drawFinger(-46, -28, 138, 27, idxRatio, 'f-idx')}
      {midRatio <= 0.34 && drawFinger(-15, -34, 154, 28, midRatio, 'f-mid')}
      {ringRatio <= 0.34 && drawFinger(16, -30, 140, 27, ringRatio, 'f-ring')}
      {pinkyRatio <= 0.34 && drawFinger(46, -20, 112, 24, pinkyRatio, 'f-pnk')}

      <path
        d={
          mode === 'one'
            ? 'M -76 66 C -92 34, -70 -4, -34 -2 L 18 8 C 34 12, 32 34, 14 36 L -38 38 C -48 56, -58 74, -76 66 Z'
            : 'M -76 70 C -90 40, -66 10, -28 14 L 38 22 C 54 25, 50 46, 32 46 L -32 46 C -46 62, -58 76, -76 70 Z'
        }
        fill={HERO_PAL.skinTop}
        stroke={HERO_PAL.skinLine}
        strokeWidth={3.4}
        strokeLinejoin="round"
      />
      <ellipse cx={mode === 'one' ? 14 : 32} cy={mode === 'one' ? 21 : 33} rx={7.5} ry={5.5} fill="#fae2cb" opacity={0.75} />
    </g>
  );
};

/**
 * Соразмерный, реалистичный металлический ключ от дверей автобуса, зажатый МЕЖДУ ПАЛЬЦАМИ (Раздел 8):
 * согнутый указательный/средний пальцы поддерживают головку ключа снизу, большой палец прижимает её сверху,
 * а компактный синий брелок естественно свисает вниз на стальном колечке!
 */
export const HandGrippingDoorKeyUnit: React.FC<{
  squeeze?: number; // 0..1 лёгкое сжатие ключа в финале
  glintPos?: number; // 0..1 пробегающий блик по металлу жала
}> = ({squeeze = 0, glintPos = 0.5}) => (
  <g transform={`rotate(${-squeeze * 4})`}>
    {/* Рукав куртки водителя и манжета, соединённые с запястьем */}
    <path d="M -88 32 L -175 110 L -142 156 L -48 68 Z" fill="#1e2b50" stroke="#354a82" strokeWidth={3} />
    <rect x={-94} y={24} width={54} height={24} rx={7} fill="#151e3a" stroke="#354a82" strokeWidth={2.5} transform="rotate(38 -67 36)" />

    {/* Ладонь и 3 согнутых пальца (средний, безымянный, мизинец) ПОД ключом */}
    <path
      d="M -62 34 C -48 10, -18 2, 12 8 C 28 12, 34 32, 22 48 C 8 64, -36 62, -62 34 Z"
      fill={HERO_PAL.skinBase}
      stroke={HERO_PAL.skinLine}
      strokeWidth={2.4}
    />
    {/* Подушечки согнутых пальцев снизу, на которые опирается головка ключа */}
    <rect x={-6} y={20} width={32} height={13} rx={6.5} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2} />
    <rect x={-10} y={32} width={30} height={12} rx={6} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2} />
    <rect x={-14} y={43} width={26} height={11} rx={5.5} fill={HERO_PAL.skinShade} stroke={HERO_PAL.skinLine} strokeWidth={2} />

    {/* МЕТАЛЛИЧЕСКИЙ КЛЮЧ (зажат между согнутым указательным пальцем снизу и большим пальцем сверху!) */}
    <g transform={`translate(18 14) rotate(${-12 - squeeze * 3})`}>
      {/* Брелок автобуса, естественно свисающий ВНИЗ под действием тяжести от колечка */}
      <g transform={`translate(-14 6) rotate(${12 + squeeze * 2})`}>
        <circle cx={0} cy={8} r={9} fill="none" stroke="#c8d4ef" strokeWidth={2.8} />
        <rect x={-11} y={15} width={22} height={38} rx={6} fill="#2859c9" stroke="#7aa7ff" strokeWidth={2} />
        <circle cx={0} cy={22} r={2.8} fill="#0e162e" />
        <rect x={-6} y={29} width={12} height={15} rx={2} fill="none" stroke="#dce8ff" strokeWidth={1.6} />
      </g>

      {/* Металлическая головка ключа (частично перекрыта большим пальцем сверху!) */}
      <rect x={-16} y={-13} width={28} height={26} rx={8} fill="#d7e2fa" stroke="#6f80ab" strokeWidth={2.4} />
      <circle cx={-9} cy={0} r={4} fill="#141e3a" />

      {/* Соразмерное стальное жало ключа с продольной канавкой и зубцами (длина 58px — реальный масштаб!) */}
      <path
        d="M 12 -6.5 L 68 -6.5 L 73 -2 L 67 2.5 L 61 -0.5 L 55 4.5 L 48 0.5 L 42 5 L 35 1 L 29 5 L 12 5 Z"
        fill="#edf3ff"
        stroke="#6f80ab"
        strokeWidth={2.2}
        strokeLinejoin="round"
      />
      <line x1={14} y1={-2.2} x2={64} y2={-2.2} stroke="#8fa0c9" strokeWidth={1.8} />
      {/* Живой металлический блик на грани ключа */}
      <circle cx={lerp(22, 64, glintPos)} cy={-2} r={8} fill="#ffffff" opacity={0.45} />
    </g>

    {/* БОЛЬШОЙ ПАЛЕЦ СВЕРХУ плотно прижимает головку ключа (настоящий физический хват!) */}
    <path
      d="M -36 16 C -22 -2, 2 -6, 18 2 C 26 6, 23 18, 11 19 C -2 20, -18 22, -36 16 Z"
      fill={HERO_PAL.skinTop}
      stroke={HERO_PAL.skinLine}
      strokeWidth={2.4}
    />
    <ellipse cx={12} cy={9} rx={6} ry={4} fill="#fae4ce" opacity={0.75} transform="rotate(10 12 9)" />
  </g>
);

/**
 * Водитель в кабине с ЗАМЕТНЫМ ПОВОРОТОМ КОРПУСА И ГОЛОВЫ (Раздел 3В):
 * - turnProgress = 0: сидит В ПРОФИЛЬ / ПОЛОБОРОТА ВЛЕВО к рулю и дороге, левая/правая руки на руле!
 * - turnProgress 0 -> 1: корпус, воротник, плечи и голова заметно разворачиваются ВПРАВО к Герою,
 *   а правая рука поднимается с зажатым в пальцах соразмерным ключом от дверей!
 */
export const DriverInCabFigure: React.FC<{
  id: string;
  x: number;
  y: number;
  scale?: number;
  turnProgress?: number; // 0 = повёрнут к дороге/рулю, 1 = развернулся к герою
  keyRaise?: number;     // 0..1 подъём руки с ключом
  keySqueeze?: number;   // 0..1 сжатие ключа в финале
  keyGlint?: number;
  talkOpen?: number;
  lookOverride?: [number, number];
}> = ({
  id,
  x,
  y,
  scale = 1,
  turnProgress = 0,
  keyRaise = 0,
  keySqueeze = 0,
  keyGlint = 0.5,
  talkOpen = 0,
  lookOverride,
}) => {
  const tp = clamp(turnProgress, 0, 1);
  // При tp=0 корпус узкий (в профиль влево к рулю, молния смещена влево x=456);
  // при tp=1 корпус разворачивается грудью к герою (широкие плечи, молния на x=514)!
  const torsoLeftX = lerp(432, 404, tp);
  const torsoRightX = lerp(562, 608, tp);
  const zipX = lerp(456, 514, tp);
  const headShiftX = lerp(-18, 8, tp);
  const headYaw = lerp(-0.68, 0.20, tp);
  const defaultLook: [number, number] = [lerp(-0.65, 0.32, tp), 0.06];

  return (
    <g transform={`translate(${x} ${y}) scale(${scale}) translate(-505 -620)`}>
      {/* Спинка водительского кресла */}
      <rect x={356} y={235} width={292} height={465} rx={44} fill="#17203a" stroke="#283761" strokeWidth={5} />

      {/* Дальняя (левая) рука водителя, лежащая на руле слева */}
      <path
        d={`M ${torsoLeftX + 12} 378 Q ${lerp(345, 368, tp)} 468 ${lerp(318, 352, tp)} 565 L ${lerp(362, 396, tp)} 575 Q 395 480 ${torsoLeftX + 34} 395 Z`}
        fill="#151e38"
        stroke="#293966"
        strokeWidth={2.5}
      />

      {/* Разворачивающийся торс куртки водителя */}
      <path
        d={`M ${torsoLeftX} 346
            Q ${(torsoLeftX + torsoRightX) / 2} 324 ${torsoRightX} 346
            Q ${torsoRightX + 14} 364 ${torsoRightX + 10} 404
            L ${torsoRightX + 4} 625
            L ${torsoLeftX - 6} 625
            L ${torsoLeftX - 10} 404
            Q ${torsoLeftX - 12} 364 ${torsoLeftX} 346 Z`}
        fill="#1c2747"
        stroke="#2f4070"
        strokeWidth={3.5}
      />

      {/* Шея и воротник куртки, смещающиеся вместе с поворотом корпуса */}
      <rect x={479 + headShiftX} y={292} width={52} height={58} rx={14} fill={HERO_PAL.skinShade} />
      <path
        d={`M ${zipX - 48} 340 L ${zipX - 18} 314 L ${zipX} 366 L ${zipX + 22} 314 L ${zipX + 54} 340 L ${zipX + 34} 378 L ${zipX} 366 L ${zipX - 30} 378 Z`}
        fill="#263561"
        stroke="#3b508a"
        strokeWidth={2.5}
      />
      <line x1={zipX} y1={366} x2={zipX} y2={620} stroke="#10172b" strokeWidth={5} />

      {/* Голова Водителя (в профиль к дороге при tp=0 -> поворачивается лицом к Герою при tp=1, БЕЗ улыбки!) */}
      <g transform={`translate(${headShiftX} 0) translate(505 240) scale(${lerp(0.64,1,tp)} 1) translate(-505 -240)`}>
        <HeroHeadCanonical
          id={id}
          emotion="serious"
          look={lookOverride ?? defaultLook}
          headYaw={headYaw}
          driverCap={true}
          wideSmile={0}
          talkOpen={talkOpen}
          blinkSeed={999}
        />
      </g>

      {/* Правая рука водителя: до поворота лежит на руле слева, при повороте плавно поднимается с КЛЮЧОМ В РУКЕ! */}
      {keyRaise <= 0.03 ? (
        <path
          d={`M ${torsoRightX - 28} 378 Q ${lerp(455, 560, tp)} 485 ${lerp(365, 535, tp)} 565 L ${lerp(395, 575, tp)} 588 Q ${lerp(495, 595, tp)} 495 ${torsoRightX + 4} 392 Z`}
          fill="#212e54"
          stroke="#354a82"
          strokeWidth={3}
        />
      ) : (
        <g>
          {/* Плечо и предплечье от правого плеча к кисти с ключом */}
          <path
            d={`M ${torsoRightX - 26} 368 Q ${torsoRightX + 16} 455 ${lerp(440, 465, keyRaise)} 555 L ${lerp(475, 505, keyRaise)} 575 Q ${torsoRightX + 32} 465 ${torsoRightX + 6} 382 Z`}
            fill="#1e2b50"
            stroke="#354a82"
            strokeWidth={3}
          />
          <g transform={`translate(${lerp(475, 562, keyRaise)} ${lerp(548, 472, keyRaise)}) scale(0.95)`}>
            <HandGrippingDoorKeyUnit squeeze={keySqueeze} glintPos={keyGlint} />
          </g>
        </g>
      )}
    </g>
  );
};
