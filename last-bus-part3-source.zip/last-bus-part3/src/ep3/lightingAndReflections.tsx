import React from 'react';
import {lerp, clamp} from '../common';
import {Street, StreetDefs} from '../components/Street';
import {
  HeroFigure,
  HeroHeadCanonical,
  HeroSteppingBackToPole,
  HeroRearFacingWindow,
  HERO_PAL,
} from './characters';
import {TEXTS3, W, H} from './storyEp3';

/**
 * Сцена 1 (план 3): Крупный план мокрой ладони Двойника, прижатой снаружи к стеклу закрытой двери
 * («А мокрая ладонь всё ещё лежала на стекле.»).
 * Показывает анатомичную 5-палую ладонь, соединённую с запястьем и синим рукавом, ореол конденсата и стекающие капли.
 */
export const WetPalmOnGlassCloseStage: React.FC<{t: number; zoom: number}> = ({t, zoom}) => {
  const dripA = (t * 24) % 92;
  const dripB = ((t + 1.6) * 19) % 76;

  return (
    <g transform={`translate(540 820) scale(${zoom}) translate(-540 -820)`}>
      <rect width={W} height={H} fill="#060a16" />
      <rect x={68} y={220} width={944} height={1140} rx={36} fill="#121b36" stroke="#2c3c68" strokeWidth={10} />
      <defs>
        <clipPath id="wetPalmCloseClip">
          <rect x={92} y={244} width={896} height={1092} rx={24} />
        </clipPath>
        <radialGradient id="palmMistG" cx="50%" cy="48%" r="52%">
          <stop offset="0%" stopColor="#cce6ff" stopOpacity={0.42} />
          <stop offset="62%" stopColor="#8bbce8" stopOpacity={0.16} />
          <stop offset="100%" stopColor="#8bbce8" stopOpacity={0} />
        </radialGradient>
      </defs>

      <g clipPath="url(#wetPalmCloseClip)">
        <rect x={92} y={244} width={896} height={1092} fill="#070d1e" />
        {/* Тёплое пятно фонаря позади за стеклом */}
        <circle cx={780} cy={460} r={240} fill="#ffc857" opacity={0.14} />

        {/* Рукав синей толстовки снаружи за стеклом, переходящий в запястье и прижатую ладонь */}
        <g transform="translate(540 855) rotate(-6) scale(2.35)">
          <ellipse cx={0} cy={-16} rx={112} ry={136} fill="url(#palmMistG)" />
          <path d="M -46 92 L -68 260 L 58 260 L 44 92 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={3} />
          <rect x={-50} y={68} width={98} height={28} rx={9} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />
          <rect x={-32} y={44} width={62} height={30} rx={10} fill={HERO_PAL.skinBase} />

          {/* Левая ладонь снаружи, прижатая вплотную к стеклу */}
          <path
            d="M -38 56
               C -46 22, -46 -8, -40 -28
               L -46 -84 C -48 -98, -32 -100, -29 -85 L -21 -32
               L -18 -98 C -18 -112, -2 -113, -1 -98 L 1 -34
               L 10 -92 C 12 -106, 28 -104, 27 -90 L 20 -30
               L 34 -72 C 38 -84, 52 -80, 49 -67 L 35 -14
               C 42 8, 42 28, 38 48
               C 28 68, -22 72, -38 56 Z"
            fill={HERO_PAL.skinBase}
            stroke={HERO_PAL.skinLine}
            strokeWidth={2.4}
          />
          <path
            d="M -36 36 L -74 -4 C -84 -15, -70 -28, -58 -18 L -32 12 Z"
            fill={HERO_PAL.skinBase}
            stroke={HERO_PAL.skinLine}
            strokeWidth={2.4}
          />
          {/* Светлые расплющенные подушечки пальцев и ладони на холодном стекле */}
          {[
            [-38, -76, 6, 9],
            [-10, -90, 6.5, 10],
            [19, -84, 6, 9.5],
            [42, -62, 5.5, 8],
            [-66, -10, 7, 6],
            [-12, 8, 18, 14],
            [14, 24, 15, 18],
          ].map(([cx, cy, rx, ry], idx) => (
            <ellipse key={idx} cx={cx} cy={cy} rx={rx} ry={ry} fill="#fdf0e4" opacity={0.65} />
          ))}

          {/* Водяная кайма и капли, стекающие вниз по стеклу */}
          <path d="M -42 46 Q 2 64 38 42" fill="none" stroke="#c2e5ff" strokeWidth={2.8} strokeLinecap="round" opacity={0.72} />
          <g transform={`translate(-16 ${58 + dripA * 0.65})`} opacity={1 - dripA / 95}>
            <path d="M 0 -7 Q 5 2 0 6 Q -5 2 0 -7 Z" fill="#a8dcff" />
          </g>
          <g transform={`translate(18 ${52 + dripB * 0.65})`} opacity={1 - dripB / 80}>
            <path d="M 0 -6 Q 4.5 2 0 5.5 Q -4.5 2 0 -6 Z" fill="#a8dcff" />
          </g>
        </g>

        <polygon points="106,244 315,244 162,1336 106,1336" fill="#ffffff" opacity={0.07} />
      </g>
    </g>
  );
};

/**
 * Мокрый след подошвы в ПЕРСПЕКТИВНОМ СОКРАЩЕНИИ СТРОГО НА ПОВЕРХНОСТИ ПОЛА!
 * Отношение высоты к ширине 0.30 создаёт реалистичную горизонтальную плоскость пола (след НЕ висит в воздухе!).
 */
export const PerspectiveWetFloorPrint: React.FC<{
  x: number;
  y: number;
  scale: number;
  side: 'L' | 'R';
  angleDeg?: number;
  opacity: number;
}> = ({x, y, scale, side, angleDeg = 0, opacity}) => {
  if (opacity <= 0.01) return null;
  const sx = side === 'L' ? 1 : -1;
  return (
    <g transform={`translate(${x} ${y}) scale(1 0.30) rotate(${angleDeg}) scale(${sx * scale} ${scale})`} opacity={opacity}>
      {/* Расплывающееся тёмное пятно воды на линолеуме пола */}
      <ellipse cx={0} cy={4} rx={52} ry={88} fill="#061229" opacity={0.88} />
      {/* Носок подошвы */}
      <path
        d="M -24 -54 C -12 -72, 16 -72, 26 -52 C 33 -32, 30 -6, 22 8 L -20 8 C -28 -8, -30 -34, -24 -54 Z"
        fill="#15356b"
        stroke="#6db4ff"
        strokeWidth={2.6}
        strokeOpacity={0.72}
      />
      {/* Каблук подошвы */}
      <path
        d="M -18 20 L 18 20 C 22 38, 20 58, 8 64 C -4 68, -19 60, -20 42 Z"
        fill="#15356b"
        stroke="#6db4ff"
        strokeWidth={2.6}
        strokeOpacity={0.72}
      />
      {/* Рисунок протектора и влажные блики на полу */}
      <path d="M -20 -34 H 22 M -21 -16 H 23 M -15 38 H 15" stroke="#9cd0ff" strokeWidth={2.8} opacity={0.5} />
      <ellipse cx={34} cy={-14} rx={6} ry={10} fill="#9cd0ff" opacity={0.72} />
      <ellipse cx={-30} cy={34} rx={5} ry={8} fill="#bce0ff" opacity={0.68} />
    </g>
  );
};

/**
 * СЦЕНА 5: Тёмный салон -> невидимые мокрые шаги -> включение фонарика на телефоне (телефон крепко в руке!) ->
 * луч освещает проход и пустые сиденья -> НА ПОЛУ один за другим появляются мокрые следы и приближаются!
 */
export const DarkAisleFlashlightStage: React.FC<{
  flashlightOn: number;       // 0..1
  beamSweepToFloor: number;   // 0 = по сиденьям, 1 = на пол прохода
  visiblePrintsCount: number; // 0..6
  darkStepRipples?: [number, number, number];
}> = ({
  flashlightOn,
  beamSweepToFloor,
  visiblePrintsCount,
  darkStepRipples = [0, 0, 0],
}) => {
  const spotX = lerp(495, 540, beamSweepToFloor);
  const spotY = lerp(1040, 1455, beamSweepToFloor);

  // Все 6 следов расположены СТРОГО внутри трапеции пола (y = 1315..1655, ниже границы пола y = 1250!)
  const floorPrints: {x: number; y: number; sc: number; side: 'L' | 'R'; ang: number}[] = [
    {x: 512, y: 1315, sc: 0.62, side: 'L', ang: -3},
    {x: 568, y: 1368, sc: 0.72, side: 'R', ang: 3},
    {x: 502, y: 1428, sc: 0.84, side: 'L', ang: -4},
    {x: 578, y: 1495, sc: 0.96, side: 'R', ang: 4},
    {x: 492, y: 1572, sc: 1.10, side: 'L', ang: -4},
    {x: 588, y: 1652, sc: 1.24, side: 'R', ang: 4},
  ];

  return (
    <g>
      <defs>
        <radialGradient id="aisleTorchPool" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#eff7ff" stopOpacity={0.44} />
          <stop offset="60%" stopColor="#9ec4ff" stopOpacity={0.18} />
          <stop offset="100%" stopColor="#142347" stopOpacity={0} />
        </radialGradient>
        <linearGradient id="aisleTorchBeam" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor="#ffffff" stopOpacity={0.46} />
          <stop offset="48%" stopColor="#cfe3ff" stopOpacity={0.18} />
          <stop offset="100%" stopColor="#8bb6ff" stopOpacity={0.02} />
        </linearGradient>
      </defs>

      {/* Тёмный ночной салон (различимы очертания потолка, поручней, пустых сидений и ребристого пола) */}
      <rect width={W} height={H} fill="#050914" />
      <polygon points="0,0 1080,0 840,510 240,510" fill="#080e1f" />
      {[100, 240, 370].map((ly, i) => (
        <rect key={i} x={540 - (105 - i * 22)} y={ly} width={(105 - i * 22) * 2} height={13} rx={6} fill="#1b243d" opacity={0.75} />
      ))}
      <rect x={240} y={510} width={600} height={740} rx={16} fill="#091022" stroke="#182444" strokeWidth={4} />
      <rect x={295} y={565} width={490} height={265} rx={20} fill="#040711" stroke="#182444" strokeWidth={4} />

      {/* ПОВЕРХНОСТЬ ПОЛА ПРОХОДА (начинается строго на y = 1250 и расширяется в перспективе до y = 1920) */}
      <polygon points="240,1250 840,1250 1080,1920 0,1920" fill="#091021" />
      <line x1={240} y1={1250} x2={840} y2={1250} stroke="#1b284a" strokeWidth={4} />
      {[-90, -45, 0, 45, 90].map((ofs, i) => (
        <line key={i} x1={540 + ofs * 0.48} y1={1250} x2={540 + ofs * 2.05} y2={1920} stroke="#131e3a" strokeWidth={3} />
      ))}

      {/* Пустые ряды сидений слева и справа от прохода */}
      {[0, 1, 2, 3].map((r) => {
        const p = r / 3;
        const sy = lerp(895, 1225, p);
        const sw = lerp(165, 335, p);
        const sh = lerp(175, 310, p);
        const gap = lerp(105, 195, p);
        const seatFill = flashlightOn > 0.2 ? '#1c2b50' : '#0d152b';
        return (
          <g key={r}>
            <rect x={540 - gap - sw} y={sy} width={sw} height={sh} rx={24} fill={seatFill} stroke="#14203f" strokeWidth={4} />
            <rect x={540 + gap} y={sy} width={sw} height={sh} rx={24} fill={seatFill} stroke="#14203f" strokeWidth={4} />
          </g>
        );
      })}
      <line x1={392} y1={510} x2={348} y2={1685} stroke="#566587" strokeWidth={9} opacity={0.75} />
      <line x1={688} y1={510} x2={732} y2={1685} stroke="#566587" strokeWidth={9} opacity={0.75} />

      {/* До включения фонарика: тонкие круги воды НА ПОЛУ от 3 невидимых мокрых шагов */}
      {flashlightOn < 0.1 &&
        darkStepRipples.map((rp, idx) =>
          rp > 0.02 ? (
            <g key={idx} transform={`translate(${idx % 2 === 0 ? 512 : 568} ${1340 + idx * 85})`} opacity={rp * 0.65}>
              <ellipse rx={22 + (1 - rp) * 34} ry={7 + (1 - rp) * 11} fill="none" stroke="#7ab4f5" strokeWidth={2.4} />
            </g>
          ) : null
        )}

      {/* Луч фонарика и проступающие на полу мокрые следы */}
      {flashlightOn > 0.02 && (
        <g opacity={flashlightOn}>
          {/* Конус света начинается ТОЧНО от светодиода телефона (540, 1732) */}
          <polygon
            points={`540,1732 ${spotX - 410},${spotY - 340} ${spotX + 410},${spotY - 340}`}
            fill="url(#aisleTorchBeam)"
          />
          <ellipse cx={spotX} cy={spotY} rx={410} ry={220} fill="url(#aisleTorchPool)" />

          {/* Мокрые следы в перспективе строго НА ПОВЕРХНОСТИ ПОЛА */}
          {floorPrints.map((fp, idx) => (
            <PerspectiveWetFloorPrint
              key={idx}
              x={fp.x}
              y={fp.y}
              scale={fp.sc}
              side={fp.side}
              angleDeg={fp.ang}
              opacity={clamp(visiblePrintsCount - idx, 0, 1)}
            />
          ))}
        </g>
      )}

      {/* Рука героя внизу экрана (видна и в полутьме, и при включении фонарика): ПАЛЬЦЫ КРЕПКО ДЕРЖАТ ТЕЛЕФОН! */}
      <g transform={`translate(540 ${lerp(1870, 1818, flashlightOn)})`}>
        {/* Синий рукав толстовки и манжета */}
        <path d="M -74 36 L -92 160 L 92 160 L 74 36 Z" fill={HERO_PAL.hoodBase} stroke={HERO_PAL.hoodDeep} strokeWidth={3} />
        <rect x={-78} y={14} width={156} height={28} rx={9} fill={HERO_PAL.hoodDark} stroke={HERO_PAL.hoodDeep} strokeWidth={2.5} />
        {/* Основание ладони, соединённое с манжетой */}
        <path d="M -62 18 L -68 -24 L 68 -24 L 62 18 Z" fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2.5} />
        {/* Корпус телефона в руке */}
        <rect x={-66} y={-92} width={132} height={112} rx={20} fill="#0c101d" stroke="#536694" strokeWidth={4} />
        {/* Большой палец слева обхватывает корпус телефона */}
        <path d="M -62 8 C -92 -6, -90 -52, -62 -58 C -48 -60, -46 -38, -56 -24 Z" fill={HERO_PAL.skinTop} stroke={HERO_PAL.skinLine} strokeWidth={2.4} />
        {/* 4 пальца справа обхватывают боковую грань телефона */}
        {[-72, -52, -32, -14].map((fy, fi) => (
          <rect key={fi} x={56} y={fy} width={28} height={16} rx={8} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
        ))}
        {/* Вспышка светодиода фонарика в (0, -86) -> мировые (540, 1732) */}
        {flashlightOn > 0.05 && (
          <g opacity={flashlightOn}>
            <circle cx={0} cy={-86} r={15} fill="#ffffff" />
            <circle cx={0} cy={-86} r={38} fill="#d2e7ff" opacity={0.48} />
          </g>
        )}
      </g>
    </g>
  );
};

/**
 * СЦЕНА 6: Герой отступает и ударяется спиной о вертикальный поручень (ТОЧНОЕ КАСАНИЕ СПИНОЙ x = 258!),
 * а мокрые следы на поверхности пола останавливаются совсем рядом!
 */
export const BackTouchesPoleStage: React.FC<{
  stepBackProgress: number; // 0..1: спина героя плавно доходит ровно до правого края поручня (x = 258) и останавливается!
  impactPulse: number;      // 0..1: лёгкая отдача в момент контакта спины с поручнем
  stoppedPrints: number;    // 0..2: финальная пара мокрых следов на полу рядом с ногами героя
}> = ({stepBackProgress, impactPulse, stoppedPrints}) => {
  const POLE_CENTER_X = 246;
  const POLE_RIGHT_EDGE = 258; // точная правая грань трубы поручня (246 + 12)
  const FLOOR_HORIZON_Y = 1410; // верхняя граница плоскости пола (ВСЕ следы и кроссовки строго ниже 1410!)

  // Спина героя движется от x=412 до ТОЧНОГО касания POLE_RIGHT_EDGE (258) — ни пикселя зазора и ни пикселя пересечения!
  const heroBackX = lerp(412, POLE_RIGHT_EDGE, clamp(stepBackProgress, 0, 1));
  const stepCycle = stepBackProgress < 0.98 ? stepBackProgress * Math.PI * 2 : 0;

  return (
    <g>
      <defs>
        <linearGradient id="sideHandTorchCone" x1="0" y1="0" x2="1" y2="0.45">
          <stop offset="0%" stopColor="#ffffff" stopOpacity={0.45} />
          <stop offset="55%" stopColor="#bfe0ff" stopOpacity={0.16} />
          <stop offset="100%" stopColor="#89b8ff" stopOpacity={0} />
        </linearGradient>
      </defs>

      {/* Тёмный интерьер автобуса (бок салона в понятном ракурсе) */}
      <rect width={W} height={H} fill="#050914" />
      {/* Ночное окно и спинки сидений на дальнем плане */}
      <rect x={70} y={320} width={940} height={540} rx={28} fill="#081022" stroke="#182546" strokeWidth={5} />
      {[380, 690, 975].map((sx, i) => (
        <rect key={i} x={sx - 105} y={790} width={210} height={360} rx={36} fill="#131e3a" stroke="#0d1428" strokeWidth={4} />
      ))}
      {/* Стеновая панель под сиденьями до линии пола y = 1410 */}
      <rect x={0} y={1150} width={W} height={FLOOR_HORIZON_Y - 1150} fill="#0b1224" />

      {/* ПОВЕРХНОСТЬ ПОЛА САЛОНА (y = 1410..1920) с чётким плинтусом и продольными рёбрами */}
      <rect x={0} y={FLOOR_HORIZON_Y} width={W} height={H - FLOOR_HORIZON_Y} fill="#080e1d" />
      <rect x={0} y={FLOOR_HORIZON_Y - 6} width={W} height={10} fill="#1d2a4d" />
      {[1485, 1575, 1680, 1800].map((fy, i) => (
        <line key={i} x1={0} y1={fy} x2={W} y2={fy} stroke="#111b36" strokeWidth={3} />
      ))}

      {/* Мягкий конус света фонарика ПРЯМО ИЗ СВЕТОДИОДА СМАРТФОНА В РУКЕ ГЕРОЯ вниз на пол к мокрым следам! */}
      <polygon
        points={`${heroBackX + 292},1282 1045,1515 535,1575`}
        fill="url(#sideHandTorchCone)"
      />
      {/* Световое пятно от фонарика НА ПОЛУ и мокрые следы СТРОГО НА ПОВЕРХНОСТИ ПОЛА (y = 1505..1585 > 1410!) */}
      <ellipse cx={775} cy={1545} rx={265} ry={74} fill="#b8d8ff" opacity={0.22} />
      <PerspectiveWetFloorPrint x={955} y={1518} scale={0.96} side="R" angleDeg={-82} opacity={0.85} />
      <PerspectiveWetFloorPrint x={825} y={1566} scale={1.00} side="L" angleDeg={-84} opacity={0.92} />
      <PerspectiveWetFloorPrint x={695} y={1516} scale={1.05} side="R" angleDeg={-82} opacity={clamp(stoppedPrints, 0, 1)} />
      <PerspectiveWetFloorPrint x={590} y={1568} scale={1.08} side="L" angleDeg={-84} opacity={clamp(stoppedPrints - 0.65, 0, 1)} />

      {/* МЕТАЛЛИЧЕСКИЙ ВЕРТИКАЛЬНЫЙ ПОРУЧЕНЬ (x = 234..258, опирается фланцем на пол в y = 1560) */}
      <ellipse cx={POLE_CENTER_X} cy={1562} rx={28} ry={10} fill="#5c6b8a" stroke="#313d59" strokeWidth={3} />
      <rect x={POLE_CENTER_X - 12} y={110} width={24} height={1452} rx={12} fill="#94a3c4" />
      <rect x={POLE_CENTER_X - 4} y={110} width={7} height={1452} fill="#e0eaff" opacity={0.6} />

      {/* Визуальный акцент точки контакта спины с поручнем в момент удара (83.97s) */}
      {impactPulse > 0.03 && (
        <g transform={`translate(${POLE_CENTER_X - 14} 1125)`} opacity={impactPulse * 0.9}>
          <path d="M -18 -38 Q -38 0 -18 38 M -34 -58 Q -60 0 -34 58" fill="none" stroke="#c4deff" strokeWidth={4} strokeLinecap="round" />
        </g>
      )}

      {/* Герой отступает и касается спиной ровно правой грани поручня (backX = 258), держа телефон В РУКЕ! */}
      <HeroSteppingBackToPole
        id="poleSceneHero"
        backX={heroBackX}
        floorY={1555}
        stepCycle={stepCycle}
        impactJolt={impactPulse}
      />
    </g>
  );
};

/**
 * СЦЕНА 7: Самостоятельное отражение в окне!
 * - Слева в салоне видна перегородка кабины и ЗЕРКАЛО ВОДИТЕЛЯ (куда указывает отражение).
 * - Справа строго внутри <clipPath> окна находится ОТРАЖЕНИЕ (не выходит за границы стекла ни на пиксель!),
 *   которое стоит за спиной героя и медленно поднимает руку, указывая на зеркало водителя.
 * - На переднем плане стоит НАСТОЯЩИЙ ГЕРОЙ лицом к окну с опущенными руками (не повторяет движение!).
 */
export const WindowAutonomousReflectionStage: React.FC<{
  reflAppear: number;  // 0..1
  pointMirror: number; // 0..1
}> = ({reflAppear, pointMirror}) => {
  // Указывающая кисть отражения (вытянутый указательный палец направлен влево к зеркалу водителя!)
  const pointingHand =
    pointMirror > 0.18 ? (
      <g transform="rotate(84) translate(0 14)">
        <rect x={-14} y={-12} width={28} height={16} rx={7} fill={HERO_PAL.skinBase} />
        <ellipse cx={4} cy={0} rx={19} ry={16} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
        <rect x={-10} y={-50} width={14} height={48} rx={7} fill={HERO_PAL.skinBase} stroke={HERO_PAL.skinLine} strokeWidth={2} />
        <circle cx={-3} cy={-44} r={3.2} fill="#fae2cb" opacity={0.75} />
      </g>
    ) : undefined;

  return (
    <g>
      <StreetDefs />
      <rect width={W} height={H} fill="#070c1b" />

      {/* Левая часть кадра: передняя перегородка кабины и ЗЕРКАЛО ВОДИТЕЛЯ (цель жеста отражения!) */}
      <rect x={24} y={240} width={206} height={1060} rx={18} fill="#0c142b" stroke="#223159" strokeWidth={5} />
      <rect x={116} y={290} width={18} height={74} fill="#273661" />
      <rect
        x={44}
        y={354}
        width={166}
        height={78}
        rx={16}
        fill="#152347"
        stroke={pointMirror > 0.5 ? '#8ec2ff' : '#4a629c'}
        strokeWidth={5}
      />
      <polygon points="52,360 98,360 72,426 52,426" fill="#ffffff" opacity={0.14} />

      {/* Правая часть кадра: БОКОВОЕ ОКНО АВТОБУСА (отражение СТРОГО ограничено clipPath поверхности стекла!) */}
      <rect x={256} y={240} width={776} height={1040} rx={36} fill="#101a34" stroke="#2b3c69" strokeWidth={8} />
      <defs>
        <clipPath id="strictBusWindowPaneClip">
          <rect x={276} y={260} width={736} height={1000} rx={26} />
        </clipPath>
      </defs>

      <g clipPath="url(#strictBusWindowPaneClip)">
        <rect x={276} y={260} width={736} height={1000} fill="#050914" />
        {/* Ночная улица за окном */}
        <g transform="translate(276 365) scale(1.32)">
          <Street camX={960} width={700} lampLit={0.35} lampFlicker={false} />
        </g>
        <rect x={276} y={260} width={736} height={1000} fill="#050915" opacity={0.58} />

        {/* САМОСТОЯТЕЛЬНОЕ ОТРАЖЕНИЕ ГЕРОЯ (полупрозрачное на поверхности стекла, указывает влево на зеркало!) */}
        <g opacity={reflAppear * 0.64}>
          <HeroFigure
            id="autonomousWinReflection"
            x={840}
            y={1235}
            scale={0.98}
            flip={true}
            emotion="serious"
            look={[0.58, -0.18]}
            armL={82}
            armR={lerp(82, 26, pointMirror)}
            elbowR={lerp(6, 16, pointMirror)}
            handRNode={pointingHand}
            shade={0.26}
            shadeColor={[0.20, 0.35, 0.62]}
            blinkSeed={999}
          />
        </g>

        {/* Стеклянные диагональные блики ПОВЕРХ отражения (подчёркивают, что оно находится внутри стекла окна!) */}
        <polygon points="310,260 475,260 315,1260 276,1260" fill="#ffffff" opacity={0.08} />
        <polygon points="790,260 855,260 705,1260 650,1260" fill="#a8d0ff" opacity={0.05} />
      </g>

      {/* Тонкая световая линия взгляда от указательного пальца отражения к зеркалу водителя слева */}
      {pointMirror > 0.65 && (
        <line
          x1={578}
          y1={798}
          x2={212}
          y2={402}
          stroke="#9bcaff"
          strokeWidth={2.5}
          strokeDasharray="10 10"
          opacity={(pointMirror - 0.65) * 1.1}
        />
      )}

      {/* НАСТОЯЩИЙ ГЕРОЙ В САЛОНЕ: стоит спиной к нам и ЛИЦОМ К ОКНУ, обе руки спокойно опущены! */}
      <HeroRearFacingWindow x={358} y={1695} scale={1.20} />
    </g>
  );
};

/**
 * Крупный план зеркала водителя над рулём (Сцены 4, 8, 11):
 * - взгляд водителя прямо на героя (Сцена 4),
 * - запотевшее зеркало с крупной читаемой надписью «НЕ ОТВЕЧАЙ ЕМУ» + моргание век и исчезновение (Сцена 8),
 * - широкая улыбка водителя ТОЛЬКО в зеркале (Сцена 11).
 */
export const RearviewMirrorStage: React.FC<{
  look?: [number, number];
  wideSmile?: number;
  fogAmount?: number;
  warningReveal?: number;
  blinkClose?: number;
  zoom?: number;
  cabinLit?: number;
}> = ({
  look = [0.16, 0.2],
  wideSmile = 0,
  fogAmount = 0,
  warningReveal = 0,
  blinkClose = 0,
  zoom = 1.04,
  cabinLit = 1,
}) => (
  <g>
    <g transform={`translate(540 740) scale(${zoom}) translate(-540 -740)`}>
      <defs>
        <linearGradient id="mirStageBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#060a16" />
          <stop offset="100%" stopColor="#0d152c" />
        </linearGradient>
        <radialGradient id="mirFogMist" cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#cbe0f7" stopOpacity={0.85} />
          <stop offset="68%" stopColor="#9cbadd" stopOpacity={0.64} />
          <stop offset="100%" stopColor="#6f90ba" stopOpacity={0.18} />
        </radialGradient>
        <clipPath id="bigRearMirrorClip">
          <rect x={84} y={516} width={912} height={404} rx={42} />
        </clipPath>
      </defs>

      <rect width={W} height={H} fill="url(#mirStageBg)" />
      {/* Кронштейн и корпус зеркала водителя */}
      <rect x={516} y={160} width={48} height={338} fill="#1d2746" />
      <circle cx={540} cy={494} r={34} fill="#27345b" stroke="#3e5185" strokeWidth={5} />
      <rect x={64} y={496} width={952} height={444} rx={54} fill="#10182f" stroke="#46598f" strokeWidth={10} />

      <g clipPath="url(#bigRearMirrorClip)">
        <rect x={84} y={516} width={912} height={404} fill={cabinLit > 0.3 ? '#14203f' : '#0a1022'} />
        <line x1={225} y1={516} x2={225} y2={920} stroke="#50608c" strokeWidth={8} opacity={0.4} />
        <line x1={855} y1={516} x2={855} y2={920} stroke="#50608c" strokeWidth={8} opacity={0.4} />

        {/* Лицо водителя (вариация нашего Героя) в зеркале */}
        <g transform="translate(540 806) scale(2.42) translate(-505 -242)" opacity={lerp(1, 0.25, fogAmount)}>
          <HeroHeadCanonical
            id="mirrorCloseDriverHead"
            emotion="serious"
            look={look}
            driverCap={true}
            wideSmile={wideSmile}
            blinkSeed={999}
          />
        </g>

        {/* Слой конденсата и крупная читаемая надпись «НЕ ОТВЕЧАЙ ЕМУ» */}
        {fogAmount > 0.02 && (
          <g opacity={fogAmount}>
            <ellipse cx={540} cy={718} rx={456} ry={208} fill="url(#mirFogMist)" />
            {[
              [185, 600, 3.4],
              [240, 820, 3.8],
              [845, 615, 3.6],
              [880, 805, 4.0],
              [500, 850, 3.2],
            ].map(([cx, cy, r], i) => (
              <circle key={i} cx={cx} cy={cy} r={r} fill="#eef7ff" opacity={0.65} />
            ))}
          </g>
        )}

        {warningReveal > 0.02 && (
          <g opacity={warningReveal}>
            <text
              x={540}
              y={740}
              textAnchor="middle"
              fontFamily="Inter, DejaVu Sans, sans-serif"
              fontWeight={900}
              fontSize={68}
              letterSpacing={3}
              fill="#0c162e"
              stroke="#e8f4ff"
              strokeWidth={3.2}
              paintOrder="stroke"
            >
              {TEXTS3.mirrorInscription}
            </text>
            <line x1={312} y1={748} x2={312} y2={784} stroke="#142244" strokeWidth={3} strokeLinecap="round" opacity={0.55} />
            <line x1={570} y1={748} x2={570} y2={792} stroke="#142244" strokeWidth={3} strokeLinecap="round" opacity={0.55} />
            <line x1={775} y1={748} x2={775} y2={780} stroke="#142244" strokeWidth={3} strokeLinecap="round" opacity={0.5} />
          </g>
        )}

        <polygon points="104,516 250,516 158,920 84,920" fill="#ffffff" opacity={0.08} />
      </g>
    </g>

    {/* Моргание век от первого лица («Я моргнул — и надпись исчезла») */}
    {blinkClose > 0.02 && (
      <g pointerEvents="none">
        <path
          d={`M 0 0 H ${W} V ${lerp(0, 1020, blinkClose)} Q 540 ${lerp(0, 1140, blinkClose)} 0 ${lerp(0, 1020, blinkClose)} Z`}
          fill="#02040a"
        />
        <path
          d={`M 0 ${H} H ${W} V ${lerp(H, 900, blinkClose)} Q 540 ${lerp(H, 780, blinkClose)} 0 ${lerp(H, 900, blinkClose)} Z`}
          fill="#02040a"
        />
      </g>
    )}
  </g>
);
