import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {EV3, TEXTS3, W, H} from './storyEp3';
import {ramp} from '../common';

export const VignetteEp3: React.FC<{darkness?: number}> = ({darkness = 0.44}) => (
  <g pointerEvents="none">
    <defs>
      <radialGradient id="vigEp3Grad" cx="50%" cy="46%" r="66%">
        <stop offset="52%" stopColor="#000000" stopOpacity={0} />
        <stop offset="100%" stopColor="#02040a" stopOpacity={darkness} />
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill="url(#vigEp3Grad)" />
  </g>
);

export const TopVoteBadgeEp3: React.FC<{timeOffsetSec?: number}> = ({timeOffsetSec = 0}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = timeOffsetSec + f / fps;

  const vis = ramp(t, 0.35, 0.85) * (1 - ramp(t, 5.2, 5.8));
  if (vis <= 0.01) return null;

  return (
    <g pointerEvents="none" opacity={vis} transform={`translate(0 ${(1 - vis) * -18})`}>
      <rect x={265} y={98} width={550} height={46} rx={23} fill="#0b1226" fillOpacity={0.9} stroke="#ffd24c" strokeWidth={2} strokeOpacity={0.55} />
      <text x={540} y={128} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={800} fontSize={21} letterSpacing={1.4} fill="#f6d36b">
        {TEXTS3.seriesBadge}
      </text>

      <rect x={180} y={160} width={720} height={76} rx={38} fill="#0d1630" fillOpacity={0.94} stroke="#ffd24c" strokeWidth={3.5} />
      <circle cx={236} cy={198} r={20} fill="#ffd24c" />
      <path d="M 227 198 l 6 6 l 13 -13" fill="none" stroke="#0d1630" strokeWidth={4.2} strokeLinecap="round" strokeLinejoin="round" />
      <text x={568} y={209} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={900} fontSize={33} letterSpacing={0.8} fill="#ffffff">
        {TEXTS3.stayBadge}
      </text>
    </g>
  );
};

export const InteractiveChoiceEp3: React.FC<{timeOffsetSec?: number}> = ({timeOffsetSec = 0}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = timeOffsetSec + f / fps;
  if (t < EV3.pollQuestion - 0.1) return null;

  const qIn = ramp(t, EV3.pollQuestion, EV3.pollQuestion + 0.45);
  const o1In = ramp(t, EV3.optBreakMirror - 0.1, EV3.optBreakMirror + 0.4);
  const o2In = ramp(t, EV3.optAnswerDriver - 0.1, EV3.optAnswerDriver + 0.4);
  const footIn = ramp(t, EV3.part4Footer - 0.1, EV3.part4Footer + 0.45);
  const pulse = 0.5 + 0.5 * Math.sin(f / 8);

  return (
    <g pointerEvents="none">
      {/* Заголовок вопроса сверху */}
      <g opacity={qIn} transform={`translate(0 ${(1 - qIn) * -20})`}>
        <rect x={135} y={128} width={810} height={112} rx={32} fill="#0b1226" fillOpacity={0.94} stroke="#ffd24c" strokeWidth={4} />
        <text x={540} y={199} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={900} fontSize={45} letterSpacing={1} fill="#ffffff">
          {TEXTS3.pollHeader}
        </text>
      </g>

      {/* Вариант 1: РАЗБИТЬ ЗЕРКАЛО */}
      <g opacity={o1In} transform={`translate(${(1 - o1In) * -36} 0)`}>
        <rect x={125} y={1275} width={830} height={108} rx={30} fill="#101b38" fillOpacity={0.95} stroke="#ffd24c" strokeWidth={3 + pulse * 1.2} />
        <circle cx={192} cy={1329} r={28} fill="#ffd24c" />
        <text x={192} y={1340} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={900} fontSize={32} fill="#0b1226">
          1
        </text>
        <text x={248} y={1341} fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={800} fontSize={36} fill="#ffffff">
          — {TEXTS3.pollOption1}
        </text>
      </g>

      {/* Вариант 2: ОТВЕТИТЬ ВОДИТЕЛЮ */}
      <g opacity={o2In} transform={`translate(${(1 - o2In) * 36} 0)`}>
        <rect x={125} y={1406} width={830} height={108} rx={30} fill="#101b38" fillOpacity={0.95} stroke="#ffd24c" strokeWidth={3 + (1 - pulse) * 1.2} />
        <circle cx={192} cy={1460} r={28} fill="#ffd24c" />
        <text x={192} y={1471} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={900} fontSize={32} fill="#0b1226">
          2
        </text>
        <text x={248} y={1472} fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={800} fontSize={36} fill="#ffffff">
          — {TEXTS3.pollOption2}
        </text>
      </g>

      {/* Плашка продолжения */}
      {footIn > 0.01 && (
        <g opacity={footIn} transform={`translate(0 ${(1 - footIn) * 18})`}>
          <rect x={125} y={1550} width={830} height={88} rx={26} fill="#ffd24c" />
          <text x={540} y={1606} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={900} fontSize={33} letterSpacing={0.8} fill="#0b1226">
            {TEXTS3.pollFooter}
          </text>
        </g>
      )}
    </g>
  );
};
