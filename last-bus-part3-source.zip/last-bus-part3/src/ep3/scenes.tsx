import React from 'react';
import {useCurrentFrame} from 'remotion';
import {useT, lerp, ramp, camT} from '../common';
import {InteriorDefs, BusWall, SeatFronts} from '../components/Interior';
import {HeroFigure} from './characters';
import {
  DoorClosingStayStage,
  DoubleWideSmileCloseStage,
  BusWindowStopStage,
  WindowHandCountStage,
  CabLightSwitchStage,
  EmptyCabinAisleStage,
  CabDirectAndTurnStage,
} from './busAndStop';
import {
  WetPalmOnGlassCloseStage,
  DarkAisleFlashlightStage,
  BackTouchesPoleStage,
  WindowAutonomousReflectionStage,
  RearviewMirrorStage,
} from './lightingAndReflections';
import {VignetteEp3} from './overlays';
import {EV3, ShotIdEp3, TEXTS3, W, H} from './storyEp3';

type ShotProps = {t0: number};

const StageEp3: React.FC<{children: React.ReactNode; darkness?: number}> = ({children, darkness = 0.44}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
    <InteriorDefs />
    {children}
    <VignetteEp3 darkness={darkness} />
  </svg>
);

const S01StayDoorsClosing: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const closeP = ramp(t, 3.45, EV3.doorsClosed + 0.35);
  const smileP = ramp(t, EV3.doubleSmiled - 0.1, 7.35);
  return (
    <StageEp3>
      <DoorClosingStayStage doorOpen={lerp(0.62, 0.0, closeP)} doubleSmile={smileP} />
    </StageEp3>
  );
};

const S02DoubleWideSmile: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const smile = lerp(0.55, 1.0, ramp(t, 7.55, EV3.tooWide));
  const zoom = lerp(1.0, 1.10, ramp(t, 7.45, 10.9));
  return (
    <StageEp3 darkness={0.48}>
      <DoubleWideSmileCloseStage smileProgress={smile} zoom={zoom} />
    </StageEp3>
  );
};

const S03WetPalmOnGlass: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const zoom = lerp(1.0, 1.08, ramp(t, 10.95, 13.9));
  return (
    <StageEp3 darkness={0.48}>
      <WetPalmOnGlassCloseStage t={t} zoom={zoom} />
    </StageEp3>
  );
};

const S04HeroWantsAskBusMoves: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const moving = ramp(t, EV3.busMoved - 0.1, 19.7);
  const streetX = 1560 + moving * moving * 540;
  const startSway = Math.sin(ramp(t, EV3.busMoved - 0.05, EV3.busMoved + 0.85) * Math.PI) * -12;
  const mouthTry = ramp(t, 14.7, 15.6) * (1 - ramp(t, EV3.busMoved - 0.15, EV3.busMoved + 0.2)) * 0.36;

  return (
    <StageEp3>
      <g
        transform={camT(t, [
          [13.95, 655, 855, 2.12],
          [19.7, 675, 845, 2.00],
        ])}
      >
        <BusWall streetX={streetX} doorOpen={0} lampLit={1} driver={false} />
        <HeroFigure
          id="s04HeroInside"
          x={655 + startSway}
          y={1320}
          scale={0.86}
          emotion={moving > 0.2 ? 'surprised' : 'worried'}
          look={[-0.62, 0.04]}
          tilt={startSway * 0.18}
          talkOpen={mouthTry}
          dampShoulders={true}
        />
        <SeatFronts />
      </g>
    </StageEp3>
  );
};

const S05StopRecedesLampOff: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const away = ramp(t, 19.8, 25.3);
  const stopScale = lerp(1.18, 0.52, away);
  const camXOff = lerp(0, 235, away);
  const preFlicker = t > 25.3 && t < 25.55 ? 0.35 : 1;
  const lampLit = (1 - ramp(t, EV3.lampOff, EV3.lampOff + 0.35)) * preFlicker;

  return (
    <StageEp3 darkness={lampLit < 0.3 ? 0.74 : 0.45}>
      <BusWindowStopStage
        camXOffset={camXOff}
        stopScale={stopScale}
        lampLit={lampLit}
        doubleSmile={0.45 * (1 - away)}
        rainStreakSpeed={0.85}
      />
    </StageEp3>
  );
};

const S06LampOnSameStop: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const lampOn = ramp(t, EV3.lampOn - 0.1, EV3.lampOn + 0.25);
  const z = lerp(1.06, 1.24, ramp(t, 28.0, 35.8));
  return (
    <StageEp3 darkness={lampOn < 0.3 ? 0.75 : 0.44}>
      <BusWindowStopStage camXOffset={0} stopScale={z} lampLit={lampOn} doubleSmile={0} rainStreakSpeed={0.12} />
    </StageEp3>
  );
};

const S07DoubleNotSmiling: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const z = lerp(1.42, 1.56, ramp(t, 35.85, 38.9));
  return (
    <StageEp3>
      <BusWindowStopStage camXOffset={0} stopScale={z} lampLit={1} doubleSmile={0} />
    </StageEp3>
  );
};

const S08DoubleRaisesArm: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const raise = ramp(t, 39.05, 40.45);
  return (
    <StageEp3>
      <BusWindowStopStage camXOffset={0} stopScale={1.48} lampLit={1} doubleSmile={0} doubleRaiseArm={raise} />
    </StageEp3>
  );
};

const S09HandThreeToTwo: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const enter = ramp(t, 40.55, 41.15);
  const bendOne = ramp(t, EV3.bentOne - 0.05, EV3.bentOne + 0.70);
  return (
    <StageEp3 darkness={0.46}>
      <WindowHandCountStage mode="threeToTwo" raiseProgress={enter} bendProgress={bendOne} />
    </StageEp3>
  );
};

const S10HeroWalksToDriver: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const p = ramp(t, 46.85, 48.65);
  const phase = (t - 46.85) * 13;
  return (
    <StageEp3>
      <g
        transform={camT(t, [
          [46.85, 760, 860, 1.85],
          [48.7, 520, 835, 2.22],
        ])}
      >
        <BusWall streetX={1920 + p * 180} doorOpen={0} lampLit={0.6} driver={true} />
        <HeroFigure
          id="s10WalkHero"
          x={lerp(815, 548, p)}
          y={1320}
          scale={0.86}
          flip={true}
          emotion="worried"
          look={[0.58, 0]}
          armL={lerp(72, 88, 0.5 + 0.5 * Math.sin(phase))}
          armR={lerp(88, 72, 0.5 + 0.5 * Math.sin(phase))}
          walkPhase={phase}
          dampShoulders={true}
        />
        <SeatFronts />
      </g>
    </StageEp3>
  );
};

const S11MirrorEyesOnHero: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const onMe = ramp(t, 52.6, EV3.eyesOnMe + 0.2);
  const lx = lerp(-0.42, 0.14, onMe);
  const ly = lerp(-0.08, 0.20, onMe);
  const z = lerp(1.0, 1.12, ramp(t, 48.75, 55.3));
  return (
    <StageEp3 darkness={0.46}>
      <RearviewMirrorStage look={[lx, ly]} zoom={z} />
    </StageEp3>
  );
};

const S12HeroAsksQuestion: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const talking = t >= EV3.heroQuestion && t <= 57.55 ? 0.32 + 0.44 * Math.abs(Math.sin(t * 15)) : 0;
  return (
    <StageEp3>
      <g
        transform={camT(t, [
          [55.35, 635, 835, 2.36],
          [58.5, 630, 825, 2.46],
        ])}
      >
        <BusWall streetX={2150} doorOpen={0} lampLit={0.4} driver={false} />
        <HeroFigure
          id="s12AskingHero"
          x={635}
          y={1320}
          scale={0.86}
          emotion="worried"
          look={[-0.68, -0.08]}
          talkOpen={talking}
          dampShoulders={true}
        />
        <SeatFronts />
      </g>
    </StageEp3>
  );
};

const S13DriverSwitchesLightOff: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const reach = ramp(t, 59.8, EV3.lightsOff + 0.35);
  const lightsOn = t < EV3.lightsOff + 0.36 ? 1 : 0;
  return (
    <StageEp3 darkness={lightsOn > 0.5 ? 0.45 : 0.76}>
      <CabLightSwitchStage reachProgress={reach} lightsOn={lightsOn} />
    </StageEp3>
  );
};

const S14DarkInvisibleWetSteps: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const r1 = Math.max(0, 1 - Math.abs(t - (EV3.step1 + 0.58)) / 0.42);
  const r2 = Math.max(0, 1 - Math.abs(t - (EV3.step2 + 0.65)) / 0.42);
  const r3 = Math.max(0, 1 - Math.abs(t - (EV3.step3 + 0.64)) / 0.42);
  const z = lerp(1.0, 1.06, ramp(t, 63.45, 73.4));
  return (
    <StageEp3 darkness={0.72}>
      <g transform={`translate(540 960) scale(${z}) translate(-540 -960)`}>
        <DarkAisleFlashlightStage
          flashlightOn={0}
          beamSweepToFloor={0}
          visiblePrintsCount={0}
          darkStepRipples={[r1, r2, r3]}
        />
      </g>
    </StageEp3>
  );
};

const S15FlashlightFloorFootprints: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const torchOn = ramp(t, EV3.flashlightOn - 0.05, EV3.flashlightOn + 0.20);
  const sweepDown = ramp(t, 77.2, 78.7);
  const prints = ramp(t, EV3.wetTracks - 0.05, 82.45) * 6;
  return (
    <StageEp3 darkness={0.58}>
      <DarkAisleFlashlightStage
        flashlightOn={torchOn}
        beamSweepToFloor={sweepDown}
        visiblePrintsCount={prints}
      />
    </StageEp3>
  );
};

const S16BackTouchesPole: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const stepBack = ramp(t, EV3.steppedBack - 0.05, EV3.hitPole + 0.08);
  const impact =
    ramp(t, EV3.hitPole - 0.02, EV3.hitPole + 0.14) *
    (1 - ramp(t, EV3.hitPole + 0.28, EV3.hitPole + 0.95));
  const stoppedPair = ramp(t, 84.3, EV3.stepsStopped + 0.35) * 2;
  return (
    <StageEp3 darkness={0.55}>
      <BackTouchesPoleStage
        stepBackProgress={stepBack}
        impactPulse={impact}
        stoppedPrints={stoppedPair}
      />
    </StageEp3>
  );
};

const S17IndependentWindowReflection: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const appear = ramp(t, EV3.sawRefl - 0.2, EV3.sawRefl + 1.2);
  const point = ramp(t, EV3.reflRaisedArm, EV3.pointedMirror + 0.6);
  const z = lerp(1.0, 1.06, ramp(t, 88.95, 99.2));
  return (
    <StageEp3 darkness={0.50}>
      <g transform={`translate(540 920) scale(${z}) translate(-540 -920)`}>
        <WindowAutonomousReflectionStage reflAppear={appear} pointMirror={point} />
      </g>
    </StageEp3>
  );
};

const S18FoggedMirrorBlinkVanish: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const blinkCenter = EV3.blinked + 0.38;
  const vanished = t >= blinkCenter;
  const fog = vanished ? 0 : ramp(t, EV3.foggedGlass, EV3.foggedGlass + 1.4);
  const words = vanished ? 0 : ramp(t, EV3.dontAnswer - 0.5, EV3.dontAnswer + 0.5);
  const blink = Math.max(0, 1 - Math.abs(t - blinkCenter) / 0.15);
  const z = lerp(1.04, 1.13, ramp(t, 99.25, 107.0));
  return (
    <StageEp3 darkness={0.48}>
      <RearviewMirrorStage
        look={[0.16, 0.2]}
        fogAmount={fog}
        warningReveal={words}
        blinkClose={blink}
        zoom={z}
        cabinLit={0.38}
      />
    </StageEp3>
  );
};

const S19DriverSpeaksMyVoice: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const talking = t >= EV3.driverQuestion - 0.05 && t <= 114.9 ? 0.28 + 0.44 * Math.abs(Math.sin(t * 14)) : 0;
  const z = lerp(1.04, 1.12, ramp(t, 107.05, 115.3));
  return (
    <StageEp3 darkness={0.48}>
      <g transform={`translate(410 780) scale(${z}) translate(-410 -780)`}>
        <CabDirectAndTurnStage driverTurn={0.18} driverTalk={talking} cabinLights={0.65} />
      </g>
    </StageEp3>
  );
};

const S20HeroDoubtsBusStops: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const mouthOpen = ramp(t, EV3.openedMouth, EV3.openedMouth + 0.65) * (1 - ramp(t, 117.1, 117.65)) * 0.55;
  const warnEcho = ramp(t, 117.0, 117.5) * (1 - ramp(t, 118.8, 119.4));
  const brakeSway = Math.sin(ramp(t, EV3.busStopped - 0.1, EV3.busStopped + 0.9) * Math.PI) * 14;
  const lookX = lerp(-0.58, -0.15, ramp(t, 117.0, 118.2));

  return (
    <StageEp3>
      <g
        transform={camT(t, [
          [115.35, 645, 835, 2.36],
          [122.3, 645, 845, 2.22],
        ])}
      >
        <BusWall streetX={2900} doorOpen={0} lampLit={0.6} driver={false} lights={0.75} />
        <HeroFigure
          id="s20DoubtHero"
          x={645 + brakeSway}
          y={1320}
          scale={0.86}
          emotion={t > 117.1 ? 'scared' : 'worried'}
          look={[lookX, -0.05]}
          tilt={brakeSway * 0.18}
          talkOpen={mouthOpen}
          dampShoulders={true}
        />
        <SeatFronts />
      </g>
      {warnEcho > 0.02 && (
        <g opacity={warnEcho * 0.52}>
          <rect x={220} y={240} width={640} height={106} rx={24} fill="#152548" stroke="#8ab8f0" strokeWidth={3} />
          <text x={540} y={308} textAnchor="middle" fontFamily="Inter, DejaVu Sans, sans-serif" fontWeight={900} fontSize={44} letterSpacing={2.5} fill="#e0eeff">
            {TEXTS3.mirrorInscription}
          </text>
        </g>
      )}
    </StageEp3>
  );
};

const S21SameStopAgain: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const z = lerp(1.16, 1.28, ramp(t, 122.35, 125.9));
  return (
    <StageEp3>
      <BusWindowStopStage camXOffset={0} stopScale={z} lampLit={1} doubleSmile={0} doubleRaiseArm={0.75} />
    </StageEp3>
  );
};

const S22HandOneFingerFlicker: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const enter = ramp(t, 125.95, 126.55);
  const flick =
    (t > EV3.lightFlicker + 0.1 && t < EV3.lightFlicker + 0.26) ||
    (t > EV3.lightFlicker + 0.36 && t < EV3.lightFlicker + 0.56)
      ? 0.78
      : 0;
  return (
    <StageEp3 darkness={0.46}>
      <WindowHandCountStage mode="one" raiseProgress={enter} cabinFlickerDark={flick} />
    </StageEp3>
  );
};

const S23MirrorDriverSmiles: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const smile = ramp(t, 130.05, 130.7);
  const z = lerp(1.06, 1.15, ramp(t, 129.95, 132.5));
  return (
    <StageEp3 darkness={0.48}>
      <RearviewMirrorStage look={[0.18, 0.2]} wideSmile={smile} zoom={z} cabinLit={0.82} />
    </StageEp3>
  );
};

const S24DirectDriverMotionless: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const z = lerp(1.22, 1.32, ramp(t, 132.55, 136.9));
  return (
    <StageEp3 darkness={0.46}>
      <g transform={`translate(385 835) scale(${z}) translate(-385 -835)`}>
        <CabDirectAndTurnStage driverTurn={0.12} driverKey={0} cabinLights={0.82} />
      </g>
    </StageEp3>
  );
};

const S25EmptyAisleVoice: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const cutMirror = t >= 141.65;
  const z = lerp(1.0, 1.07, ramp(t, 136.95, 141.65));
  return (
    <StageEp3 darkness={0.52}>
      {!cutMirror ? (
        <g transform={`translate(540 960) scale(${z}) translate(-540 -960)`}>
          <EmptyCabinAisleStage lightsLevel={0.62} />
        </g>
      ) : (
        <RearviewMirrorStage look={[0.18, 0.2]} wideSmile={0.28} zoom={1.12} cabinLit={0.75} />
      )}
    </StageEp3>
  );
};

const S26DriverTurnsWithKey: React.FC<ShotProps> = ({t0}) => {
  const t = useT(t0);
  const turn = ramp(t, EV3.driverTurned, EV3.driverTurned + 2.0);
  const keyUp = ramp(t, EV3.keyInHand - 0.9, EV3.keyInHand + 0.5);
  const z = lerp(1.10, 1.24, ramp(t, 144.25, 148.8));
  return (
    <StageEp3 darkness={0.46}>
      <g transform={`translate(430 905) scale(${z}) translate(-430 -905)`}>
        <CabDirectAndTurnStage driverTurn={turn} driverKey={keyUp} cabinLights={0.85} />
      </g>
    </StageEp3>
  );
};

const S27ViewerChoiceFinal: React.FC<ShotProps> = () => {
  const frame = useCurrentFrame();
  const flick = frame % 79 > 74 ? 0.52 : 0.86;
  return (
    <StageEp3 darkness={0.46}>
      <CabDirectAndTurnStage driverTurn={1} driverKey={1} cabinLights={flick} compactForPoll={true} />
    </StageEp3>
  );
};

export const SHOT_COMPONENTS_EP3: Record<ShotIdEp3, React.FC<ShotProps>> = {
  s01_stayDoorsClosing: S01StayDoorsClosing,
  s02_doubleWideSmile: S02DoubleWideSmile,
  s03_wetPalmOnGlass: S03WetPalmOnGlass,
  s04_heroWantsAskBusMoves: S04HeroWantsAskBusMoves,
  s05_stopRecedesLampOff: S05StopRecedesLampOff,
  s06_lampOnSameStop: S06LampOnSameStop,
  s07_doubleNotSmiling: S07DoubleNotSmiling,
  s08_doubleRaisesArm: S08DoubleRaisesArm,
  s09_handThreeToTwo: S09HandThreeToTwo,
  s10_heroWalksToDriver: S10HeroWalksToDriver,
  s11_mirrorEyesOnHero: S11MirrorEyesOnHero,
  s12_heroAsksQuestion: S12HeroAsksQuestion,
  s13_driverSwitchesLightOff: S13DriverSwitchesLightOff,
  s14_darkInvisibleWetSteps: S14DarkInvisibleWetSteps,
  s15_flashlightFloorFootprints: S15FlashlightFloorFootprints,
  s16_backTouchesPole: S16BackTouchesPole,
  s17_independentWindowReflection: S17IndependentWindowReflection,
  s18_foggedMirrorBlinkVanish: S18FoggedMirrorBlinkVanish,
  s19_driverSpeaksMyVoice: S19DriverSpeaksMyVoice,
  s20_heroDoubtsBusStops: S20HeroDoubtsBusStops,
  s21_sameStopAgain: S21SameStopAgain,
  s22_handOneFingerFlicker: S22HandOneFingerFlicker,
  s23_mirrorDriverSmiles: S23MirrorDriverSmiles,
  s24_directDriverMotionless: S24DirectDriverMotionless,
  s25_emptyAisleVoice: S25EmptyAisleVoice,
  s26_driverTurnsWithKey: S26DriverTurnsWithKey,
  s27_viewerChoiceFinal: S27ViewerChoiceFinal,
};
