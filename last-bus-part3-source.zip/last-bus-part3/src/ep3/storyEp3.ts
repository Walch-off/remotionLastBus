import eventsJson from '../data/events_ep3.json';

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const DURATION_SEC = 160.0;
export const TOTAL_FRAMES = Math.round(DURATION_SEC * FPS); // 4800 кадров (2 мин 40.0 с)
export const XFADE = 5;

// Тестовый фрагмент (Раздел 16 промпта: 73.0..87.5 с = 14.5 с — включение фонарика, мокрые следы на полу и поручень)
export const TEST_START_SEC = 73.0;
export const TEST_DURATION_SEC = 14.5;
export const TEST_FRAMES = Math.round(TEST_DURATION_SEC * FPS); // 435 кадров

export const EV3 = eventsJson;

export const TEXTS3 = {
  seriesBadge: 'ПОСЛЕДНИЙ АВТОБУС · ЧАСТЬ 3',
  stayBadge: 'ВЫ ВЫБРАЛИ ОСТАТЬСЯ',
  mirrorInscription: 'НЕ ОТВЕЧАЙ ЕМУ',
  pollHeader: 'ЧТО ДЕЛАТЬ ГЕРОЮ?',
  pollOption1: 'РАЗБИТЬ ЗЕРКАЛО',
  pollOption2: 'ОТВЕТИТЬ ВОДИТЕЛЮ',
  pollFooter: 'ПРОДОЛЖЕНИЕ — В ЧАСТИ 4',
};

export type ShotIdEp3 =
  | 's01_stayDoorsClosing'
  | 's02_doubleWideSmile'
  | 's03_wetPalmOnGlass'
  | 's04_heroWantsAskBusMoves'
  | 's05_stopRecedesLampOff'
  | 's06_lampOnSameStop'
  | 's07_doubleNotSmiling'
  | 's08_doubleRaisesArm'
  | 's09_handThreeToTwo'
  | 's10_heroWalksToDriver'
  | 's11_mirrorEyesOnHero'
  | 's12_heroAsksQuestion'
  | 's13_driverSwitchesLightOff'
  | 's14_darkInvisibleWetSteps'
  | 's15_flashlightFloorFootprints'
  | 's16_backTouchesPole'
  | 's17_independentWindowReflection'
  | 's18_foggedMirrorBlinkVanish'
  | 's19_driverSpeaksMyVoice'
  | 's20_heroDoubtsBusStops'
  | 's21_sameStopAgain'
  | 's22_handOneFingerFlicker'
  | 's23_mirrorDriverSmiles'
  | 's24_directDriverMotionless'
  | 's25_emptyAisleVoice'
  | 's26_driverTurnsWithKey'
  | 's27_viewerChoiceFinal';

export type ShotSpecEp3 = {id: ShotIdEp3; a: number};

// Монтажный лист привязан к реальным распознанным фразам из events_ep3.json
export const SHOTS3: ShotSpecEp3[] = [
  {id: 's01_stayDoorsClosing', a: 0.0},
  {id: 's02_doubleWideSmile', a: 7.45},
  {id: 's03_wetPalmOnGlass', a: 10.95},
  {id: 's04_heroWantsAskBusMoves', a: 13.95},
  {id: 's05_stopRecedesLampOff', a: 19.75},
  {id: 's06_lampOnSameStop', a: 27.45},
  {id: 's07_doubleNotSmiling', a: 35.85},
  {id: 's08_doubleRaisesArm', a: 38.95},
  {id: 's09_handThreeToTwo', a: 40.55},
  {id: 's10_heroWalksToDriver', a: 46.85},
  {id: 's11_mirrorEyesOnHero', a: 48.75},
  {id: 's12_heroAsksQuestion', a: 55.35},
  {id: 's13_driverSwitchesLightOff', a: 58.55},
  {id: 's14_darkInvisibleWetSteps', a: 63.45},
  {id: 's15_flashlightFloorFootprints', a: 73.45},
  {id: 's16_backTouchesPole', a: 82.85},
  {id: 's17_independentWindowReflection', a: 88.95},
  {id: 's18_foggedMirrorBlinkVanish', a: 99.25},
  {id: 's19_driverSpeaksMyVoice', a: 107.05},
  {id: 's20_heroDoubtsBusStops', a: 115.35},
  {id: 's21_sameStopAgain', a: 122.35},
  {id: 's22_handOneFingerFlicker', a: 125.95},
  {id: 's23_mirrorDriverSmiles', a: 129.95},
  {id: 's24_directDriverMotionless', a: 132.55},
  {id: 's25_emptyAisleVoice', a: 136.95},
  {id: 's26_driverTurnsWithKey', a: 144.25},
  {id: 's27_viewerChoiceFinal', a: 148.85},
];
