import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import wordsEp3 from '../data/words_ep3.json';
import {EV3} from './storyEp3';

type WordItem = {idx: number; word: string; start: number; end: number};

type SubtitleCue = {
  start: number;
  end: number;
  lines: WordItem[][];
};

const KEYWORD_STEMS = new Set([
  'выбрали', 'остаться', 'закрылись', 'двойник', 'улыбнулся', 'широкой', 'мокрая', 'ладонь',
  'тронулся', 'погас', 'загорелся', 'скамейка', 'фонарь', 'три', 'загнул', 'два', 'зеркале',
  'выключил', 'свет', 'шаги', 'один', 'второй', 'третий', 'фонарик', 'следы', 'поручень',
  'отражение', 'спиной', 'указало', 'отвечай', 'моргнул', 'исчезла', 'настоящий', 'зовут',
  'палец', 'мигнул', 'неподвижным', 'разбей', 'зеркало', 'ключ', 'дверей',
]);

// Предлоги, союзы и частицы, после которых НЕЛЬЗЯ обрывать строку или карточку субтитров!
const BIND_FORWARD = new Set([
  'в', 'во', 'на', 'о', 'об', 'от', 'до', 'к', 'ко', 'с', 'со', 'у', 'за', 'по', 'из',
  'над', 'под', 'перед', 'при', 'про', 'без', 'для', 'через', 'и', 'а', 'но', 'или',
  'не', 'ни', 'я', 'он', 'мы', 'ты', 'вы', 'мой', 'моё', 'моя', 'его', 'та', 'тот', 'ту', 'эту', 'этот',
]);

const cleanStem = (w: string) => w.toLowerCase().replace(/ё/g, 'е').replace(/[^а-яa-z0-9]/g, '');

const buildSubtitleCues = (tokens: WordItem[]): SubtitleCue[] => {
  const cues: SubtitleCue[] = [];
  let buf: WordItem[] = [];

  const flush = () => {
    if (!buf.length) return;
    const totalChars = buf.reduce((s, x) => s + x.word.length + 1, 0);
    let lines: WordItem[][];
    if (buf.length <= 3 || totalChars <= 21) {
      lines = [buf];
    } else {
      let acc = 0;
      let bestIdx = Math.ceil(buf.length / 2);
      let bestScore = 9999;
      for (let i = 1; i < buf.length; i++) {
        acc += buf[i - 1].word.length + 1;
        const diff = Math.abs(acc - (totalChars - acc));
        const prevIsDangling = BIND_FORWARD.has(cleanStem(buf[i - 1].word)) && !/[,.:;?!—]$/.test(buf[i - 1].word);
        const score = diff + (prevIsDangling ? 40 : 0);
        if (score < bestScore) {
          bestScore = score;
          bestIdx = i;
        }
      }
      lines = [buf.slice(0, bestIdx), buf.slice(bestIdx)];
    }
    cues.push({
      start: buf[0].start,
      end: buf[buf.length - 1].end + 0.20,
      lines,
    });
    buf = [];
  };

  for (let i = 0; i < tokens.length; i++) {
    const tk = tokens[i];
    buf.push(tk);
    const next = tokens[i + 1];
    const chars = buf.reduce((s, x) => s + x.word.length + 1, 0);
    const endsSentence = /[.?!»…]$/.test(tk.word);
    const endsClause = /[,:—]$/.test(tk.word) && buf.length >= 3;
    const gap = next ? next.start - tk.end : 1.0;
    const isBound = BIND_FORWARD.has(cleanStem(tk.word)) && !endsSentence && !/[,:—]$/.test(tk.word);

    if (endsSentence || endsClause || gap > 0.34 || (!isBound && (buf.length >= 6 || chars >= 35)) || buf.length >= 8) {
      flush();
    }
  }
  flush();

  for (let i = 0; i < cues.length - 1; i++) {
    if (cues[i].end > cues[i + 1].start) {
      cues[i].end = cues[i + 1].start - 0.02;
    }
  }
  return cues;
};

const CUES_EP3 = buildSubtitleCues(wordsEp3 as WordItem[]);

export const SubtitlesEp3: React.FC<{timeOffsetSec?: number}> = ({timeOffsetSec = 0}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = timeOffsetSec + frame / fps;

  if (t >= EV3.pollQuestion - 0.06) return null;

  const cue = CUES_EP3.find((c) => t >= c.start - 0.04 && t <= c.end);
  if (!cue) return null;

  const maxChars = Math.max(...cue.lines.map((ln) => ln.map((w) => w.word).join(' ').length));
  const boxW = Math.min(940, Math.max(420, maxChars * 28 + 104));
  const boxH = cue.lines.length === 1 ? 104 : 168;

  const isFloorActionZone = t >= 73.4 && t < 88.9;
  const centerY = isFloorActionZone ? 250 : 1560;

  return (
    <g pointerEvents="none">
      <rect
        x={540 - boxW / 2}
        y={centerY - boxH / 2}
        width={boxW}
        height={boxH}
        rx={28}
        fill="#060b18"
        fillOpacity={0.90}
        stroke="#2f4273"
        strokeWidth={2.5}
        strokeOpacity={0.72}
      />
      {cue.lines.map((line, li) => {
        const y = cue.lines.length === 1 ? centerY + 15 : centerY - 18 + li * 60;
        return (
          <text
            key={li}
            x={540}
            y={y}
            textAnchor="middle"
            fontFamily="Inter, DejaVu Sans, sans-serif"
            fontWeight={800}
            fontSize={43}
            stroke="#03060e"
            strokeWidth={7}
            paintOrder="stroke"
          >
            {line.map((w, wi) => {
              const isSpokenNow = t >= w.start - 0.03 && t <= w.end + 0.08;
              const isKey = KEYWORD_STEMS.has(cleanStem(w.word));
              const fill = isSpokenNow ? '#ffd24c' : isKey && t > w.end ? '#ffe799' : '#f7f9ff';
              return (
                <tspan key={w.idx} fill={fill}>
                  {wi > 0 ? ' ' : ''}
                  {w.word}
                </tspan>
              );
            })}
          </text>
        );
      })}
    </g>
  );
};
