import sys
from PIL import Image
fs=sys.argv[2:]; out=sys.argv[1]
ims=[Image.open(f).resize((405,720)) for f in fs]
W=405*len(ims); sheet=Image.new('RGB',(W,720))
for i,im in enumerate(ims): sheet.paste(im,(i*405,0))
sheet.save(out,quality=85)
