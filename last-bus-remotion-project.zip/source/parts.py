import numpy as np, json
from PIL import Image
from scipy import ndimage as ndi
im=np.array(Image.open('cutout.png')).astype(float)
rgb=im[...,:3]; A=im[...,3]/255
A=np.clip((ndi.minimum_filter(A,3)*0.5+A*0.5-0.08)/0.84,0,1)
core=ndi.binary_erosion(A>0.98,iterations=2)
idx=ndi.distance_transform_edt(~core,return_distances=False,return_indices=True)
near=rgb[idx[0],idx[1]]
fr=(A<0.99)
rgb[fr]=near[fr]
A=np.clip((A-0.12)/0.88,0,1)
H,W=A.shape
m=np.zeros((H,W),bool)
m[190:248,446:559]=True
m[240:265,500:520]=False
m[268:290,476:532]=True
skin=rgb.copy(); sk=np.array([243,194,146.])
for c in range(3): skin[...,c][m]=sk[c]
for _ in range(400):
    blur=np.stack([ndi.uniform_filter(skin[...,c],5) for c in range(3)],-1); skin[m]=blur[m]
rgb2=np.where(m[...,None],skin,rgb)
Y,X=np.mgrid[0:H,0:W]
info={}
def save(name,mask):
    a=A*mask; ys,xs=np.where(a>0.01)
    x0,x1,y0,y1=xs.min(),xs.max()+1,ys.min(),ys.max()+1
    Image.fromarray(np.dstack([rgb2,a*255])[y0:y1,x0:x1].astype(np.uint8),'RGBA').save(f'parts/{name}.png')
    info[name]=dict(x=int(x0),y=int(y0),w=int(x1-x0),h=int(y1-y0))
save('head',(Y<=313)&(X>=380)&(X<=630))
save('torso',(Y>=300)&(Y<=577)&(X>=420)&(X<=584))
save('armL',(X<=441)&(Y>=320)&(Y<=409))
save('armR',(X>=583)&(Y>=320)&(Y<=409))
save('legs',(Y>=574))
json.dump(info,open('parts/info.json','w')); print(info)
can=Image.new('RGBA',(1024,1024),(30,34,50,255))
def put(name,rot=0,piv=None):
    p=Image.open(f'parts/{name}.png'); i=info[name]
    layer=Image.new('RGBA',(1024,1024),(0,0,0,0)); layer.alpha_composite(p,(i['x'],i['y']))
    if rot: layer=layer.rotate(-rot,center=piv,resample=Image.BICUBIC)
    can.alpha_composite(layer)
put('legs'); put('torso'); put('armL',-84,(434,372)); put('armR',84,(574,372)); put('head')
can.crop((250,80,780,940)).save('test_stand.png')
