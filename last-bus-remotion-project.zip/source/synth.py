import numpy as np, soundfile as sf
from scipy.signal import butter, lfilter
SR=44100; DUR=115.72; N=int(SR*DUR)
rng=np.random.default_rng(7)
t=np.arange(N)/SR
def lp(x,f,o=2): b,a=butter(o,f/(SR/2),'low'); return lfilter(b,a,x)
def hp(x,f,o=2): b,a=butter(o,f/(SR/2),'high'); return lfilter(b,a,x)
def bp(x,f1,f2,o=2): b,a=butter(o,[f1/(SR/2),f2/(SR/2)],'band'); return lfilter(b,a,x)
def noise(n): return rng.standard_normal(n)
def env_seg(t0,t1,fn):
    e=np.zeros(N); i0=int(t0*SR); i1=min(N,int(t1*SR)); tt=(np.arange(i1-i0))/SR; e[i0:i1]=fn(tt,t1-t0); return e
def place(buf,sig,t0,gain=1.0):
    i0=int(t0*SR); n=min(len(sig),N-i0)
    if n>0: buf[i0:i0+n]+=sig[:n]*gain
def smooth(x,s): return lp(x,s,1)
# ---- ambience: engine + city
eng=np.zeros(N)
vib=1+0.01*np.sin(2*np.pi*0.7*t)
ph=2*np.pi*np.cumsum(38*vib)/SR
for k,a in [(1,1.0),(2,0.6),(3,0.35),(4,0.2),(6,0.1)]: eng+=a*np.sin(k*ph+k)
eng+=1.5*lp(noise(N),140,2)*(0.6+0.4*np.sin(2*np.pi*11*t))
eng=lp(eng,420,2)
# engine amplitude profile: intro pass-by, running, stop/idle after 40.3
amp=np.interp(t,[0,2,4,6.5,8,40.0,41.5,45,115.7],[0.25,0.55,0.75,0.35,0.5,0.55,0.28,0.22,0.16])
eng*=amp
# idle lower pitch after stop: crossfade a lower idle tone
idle=np.sin(2*np.pi*np.cumsum(27*vib)/SR)+0.5*np.sin(2*np.pi*np.cumsum(54*vib)/SR)+lp(noise(N),90,2)*1.2
idle=lp(idle,300)*np.interp(t,[40.0,41.8,115.7],[0,0.22,0.14])
city=lp(noise(N),520,2)*0.35+lp(noise(N),160,1)*0.6
city*=np.interp(t,[0,3,40,100,115.7],[0.5,0.45,0.4,0.25,0.15])
for _ in range(14):  # distant passing cars
    t0=rng.uniform(5,100); d=rng.uniform(2.5,4)
    sw=bp(noise(N),200,900)*env_seg(t0,t0+d,lambda tt,L:np.sin(np.pi*tt/L)**2)*0.35
    city+=sw
amb=eng+idle+city
amb/= np.max(np.abs(amb))
amb*=0.85
# ---- sfx
sfx=np.zeros(N)
def hiss(dur,f1,f2,attack=0.04,decay=3.0):
    n=int(dur*SR); x=bp(noise(n),f1,f2,2); tt=np.arange(n)/SR
    e=np.minimum(tt/attack,1)*np.exp(-tt*decay); return x*e
def thump(f0=70,f1=40,dur=0.6,decay=7):
    n=int(dur*SR); tt=np.arange(n)/SR; fr=f1+(f0-f1)*np.exp(-tt*18)
    return np.sin(2*np.pi*np.cumsum(fr)/SR)*np.exp(-tt*decay)
def click(f=2500):
    n=int(0.012*SR); return bp(noise(n),f*0.6,f*1.5)*np.exp(-np.arange(n)/SR*400)
def ding(f,dur=0.9):
    n=int(dur*SR); tt=np.arange(n)/SR; return (np.sin(2*np.pi*f*tt)+0.3*np.sin(2*np.pi*2.76*f*tt))*np.exp(-tt*6)
def swell(freqs,dur,attack=0.6,decay=1.8):
    n=int(dur*SR); tt=np.arange(n)/SR; x=sum(np.sin(2*np.pi*f*tt+i) for i,f in enumerate(freqs))
    x=x/len(freqs)*np.minimum(tt/attack,1)**2*np.exp(-np.maximum(tt-attack,0)*decay); return x
def rev_swell(dur=1.6):
    n=int(dur*SR); tt=np.arange(n)/SR; x=bp(noise(n),300,3000,2)+0.6*np.sin(2*np.pi*(110+120*tt/dur)*tt)
    return x*(tt/dur)**3
# intro pass-by whoosh
place(sfx,bp(noise(int(3*SR)),150,1200)*np.sin(np.pi*np.arange(int(3*SR))/(3*SR))**2,1.0,0.25)
# bus stops: brake hiss + thunk at ~40.35
place(sfx,hiss(1.8,2000,9000,0.12,1.6),40.2,0.55); place(sfx,thump(60,38,0.7,6),41.9,0.7)
# figure appears at stop (~35.4) soft dissonant swell
place(sfx,swell([164.8,174.6,246.9],2.8,0.9,1.0),34.8,0.30)
# reveal: lamp light on face (~42.6)
place(sfx,swell([110,116.5,220,233],3.0,0.5,1.2),42.0,0.34); place(sfx,thump(55,35,1.0,4),42.6,0.5)
# lamp buzz flickers
for t0 in [18.9,19.9,24.7,25.5,41.7,42.4]:
    b=bp(noise(int(0.5*SR)),100,400)*(np.random.default_rng(int(t0*10)).random(int(0.5*SR))>0.55)
    place(sfx,lp(b,900)*np.exp(-np.arange(len(b))/SR*4),t0,0.18)
# phone raised & first message
place(sfx,click(1800),56.55,0.5); place(sfx,ding(880),60.35,0.38); place(sfx,ding(1318),60.47,0.30)
# doors open ~65.03
place(sfx,hiss(1.6,900,7000,0.03,2.4),65.0,0.6); place(sfx,thump(95,55,0.35,12),65.0,0.6); place(sfx,click(900),65.55,0.5)
# head shake whoosh + typing
place(sfx,bp(noise(int(0.4*SR)),400,2500)*np.sin(np.pi*np.arange(int(0.4*SR))/(0.4*SR)),74.4,0.22)
tcur=75.7
while tcur<78.15:
    place(sfx,click(rng.choice([1800,2300,2800])),tcur,0.38); tcur+=rng.uniform(0.06,0.13)
place(sfx,ding(1046),78.25,0.40); place(sfx,ding(1568),78.37,0.30)
# reflection stays seated
place(sfx,rev_swell(1.3),89.9,0.42); place(sfx,thump(58,34,1.4,3.2),91.3,0.85)
# hand on shoulder
place(sfx,lp(noise(int(0.25*SR)),1200)*np.exp(-np.arange(int(0.25*SR))/SR*14),94.6,0.4)
place(sfx,thump(75,42,0.9,5),94.85,0.95); place(sfx,swell([98,103.8,155.6],3.5,0.3,1.0),94.85,0.3)
# heartbeat from 95.5
bpm_t=95.8
while bpm_t<115.0:
    sp=0.86-0.0045*(bpm_t-95.8)
    place(sfx,thump(62,42,0.35,14),bpm_t,0.5); place(sfx,thump(55,38,0.35,14),bpm_t+0.2,0.35); bpm_t+=sp
sfx/=np.max(np.abs(sfx)); sfx*=0.8
# ---- music: dark sparse drone
mus=np.zeros(N)
for f,a in [(55,1),(82.4,0.6),(110,0.45),(116.5,0.18),(164.8,0.12)]:
    mus+=a*np.sin(2*np.pi*f*t+rng.uniform(0,6))*(0.7+0.3*np.sin(2*np.pi*rng.uniform(0.05,0.12)*t+rng.uniform(0,6)))
mus*=np.interp(t,[0,3,30,60,90,99,106,115.7],[0.5,0.55,0.6,0.75,0.9,1.0,1.1,1.0])
for tn,f in [(18,329.6),(50,311.1),(80,261.6),(100,246.9)]:  # sparse plucks
    n=int(4*SR); tt=np.arange(n)/SR; place(mus,np.sin(2*np.pi*f*tt)*np.exp(-tt*1.3)*0.25,tn)
mus=lp(mus,900); mus/=np.max(np.abs(mus)); mus*=0.8
def w(name,x):
    x=np.clip(x,-1,1); fi=int(0.02*SR); x[:fi]*=np.linspace(0,1,fi); x[-fi:]*=np.linspace(1,0,fi)
    sf.write(name,x.astype(np.float32),SR,subtype='PCM_16')
w('ambience.wav',amb); w('sfx.wav',sfx); w('music.wav',mus); print('ok')
