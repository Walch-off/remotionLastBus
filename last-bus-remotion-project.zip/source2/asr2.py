import sherpa_onnx, numpy as np, soundfile as sf, json, re, subprocess
M="sherpa-onnx-nemo-ctc-giga-am-v2-russian-2025-04-19"
rec=sherpa_onnx.OfflineRecognizer.from_nemo_ctc(model=f"{M}/model.int8.onnx",tokens=f"{M}/tokens.txt",num_threads=4,debug=False)
y,sr=sf.read("voice2_16k.wav",dtype="float32"); dur=len(y)/sr
out=subprocess.run("ffmpeg -v info -i voice2_16k.wav -af silencedetect=noise=-38dB:d=0.35 -f null - 2>&1 | grep silence_",shell=True,capture_output=True,text=True).stdout
st=[float(x) for x in re.findall(r"silence_start: ([\d.]+)",out)]; en=[float(x) for x in re.findall(r"silence_end: ([\d.]+)",out)]
cuts=[0.0]+[(a+b)/2 for a,b in zip(st,en)]+[dur]
res=[]
for a,b in zip(cuts[:-1],cuts[1:]):
    s=rec.create_stream(); s.accept_waveform(sr,y[int(a*sr):int(b*sr)]); rec.decode_stream(s)
    r=s.result
    res.append({"seg":[round(a,3),round(b,3)],"text":r.text,"tokens":r.tokens,"ts":[round(a+t,3) for t in r.timestamps]})
    print(f"{a:7.2f}-{b:7.2f} {r.text}")
json.dump(res,open("asr2_raw.json","w"),ensure_ascii=False,indent=1)
