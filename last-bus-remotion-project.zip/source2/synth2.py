import numpy as np, soundfile as sf
from scipy.signal import butter, lfilter
SR=44100; DUR=126.73; N=int(SR*DUR)
rng=np.random.default_rng(21)
t=np.arange(N)/SR
def lp(x,f,o=2): b,a=butter(o,f/(SR/2),'low'); return lfilter(b,a,x)
def hp(x,f,o=2): b,a=butter(o,f/(SR/2),'high'); return lfilter(b,a,x)
def bp(x,f1,f2,o=2): b,a=butter(o,[f1/(SR/2),f2/(SR/2)],'band'); return lfilter(b,a,x)
def noise(n): return rng.standard_normal(n)
def place(buf,sig,t0,gain=1.0):
    i0=int(t0*SR); n=min(len(sig),N-i0)
    if n>0: buf[i0:i0+n]+=sig[:n]*gain
def thump(f0=70,f1=40,dur=0.6,decay=7):
    n=int(dur*SR); tt=np.arange(n)/SR; fr=f1+(f0-f1)*np.exp(-tt*18)
    return np.sin(2*np.pi*np.cumsum(fr)/SR)*np.exp(-tt*decay)
def hiss(dur,f1,f2,attack=0.04,decay=3.0):
    n=int(dur*SR); x=bp(noise(n),f1,f2,2); tt=np.arange(n)/SR
    return x*np.minimum(tt/attack,1)*np.exp(-tt*decay)
def click(f=2500):
    n=int(0.012*SR); return bp(noise(n),f*0.6,f*1.5)*np.exp(-np.arange(n)/SR*400)
def ding(f,dur=0.9):
    n=int(dur*SR); tt=np.arange(n)/SR; return (np.sin(2*np.pi*f*tt)+0.3*np.sin(2*np.pi*2.76*f*tt))*np.exp(-tt*6)
def swell(freqs,dur,attack=0.6,decay=1.8):
    n=int(dur*SR); tt=np.arange(n)/SR; x=sum(np.sin(2*np.pi*f*tt+i) for i,f in enumerate(freqs))
    return x/len(freqs)*np.minimum(tt/attack,1)**2*np.exp(-np.maximum(tt-attack,0)*decay)
def rev_swell(dur=1.6):
    n=int(dur*SR); tt=np.arange(n)/SR; x=bp(noise(n),300,3000,2)+0.6*np.sin(2*np.pi*(110+120*tt/dur)*tt)
    return x*(tt/dur)**3
def knock(f=520):
    n=int(0.28*SR); tt=np.arange(n)/SR
    return (np.sin(2*np.pi*f*tt)*np.exp(-tt*28)+0.6*bp(noise(n),300,1200)*np.exp(-tt*40))
def drip():
    n=int(0.25*SR); tt=np.arange(n)/SR; fr=900+1400*np.exp(-tt*30)
    return np.sin(2*np.pi*np.cumsum(fr)/SR)*np.exp(-tt*22)*0.6
def wet_slap():
    n=int(0.4*SR); tt=np.arange(n)/SR
    return lp(noise(n),900)*np.exp(-tt*16)+0.5*thump(110,60,0.4,12)[:n]
def squeak(dur=0.7):
    n=int(dur*SR); tt=np.arange(n)/SR; fr=700+500*np.sin(2*np.pi*3.2*tt)+300*tt
    return (np.sin(2*np.pi*np.cumsum(fr)/SR)*0.5+0.5*bp(noise(n),900,2600))*np.sin(np.pi*tt/dur)**1.5*0.7
# ---- ambience: тихий салон: электрический гул ламп, ветер; двигатель после запуска (106.4)
amb=np.zeros(N)
hum=np.sin(2*np.pi*100*t)*0.5+np.sin(2*np.pi*200*t)*0.2+lp(noise(N),400,1)*0.25
amb+=hum*0.35
amb+=lp(noise(N),300,2)*0.5*(0.7+0.3*np.sin(2*np.pi*0.13*t))
# мерцание: поднимается на «мерцающий свет» 26.4-28.3, на 85.7-87 и 92.3-93.6
def buzz(t0,t1,amp):
    seg=int((t1-t0)*SR); g=(rng.random(seg)>0.6).astype(float); g=lp(g,40,1)
    x=bp(noise(seg),150,900)*g*amp; place(amb,x,t0)
buzz(26.4,28.3,0.8); buzz(85.5,87.0,0.9); buzz(92.2,93.8,0.9); buzz(7,7.6,0.0)
# тёмный период: приглушаем гул ламп
dark=np.interp(t,[87.0,87.3,92.1,92.3],[1,0.15,0.15,1]); amb*=dark
# двигатель
vib=1+0.012*np.sin(2*np.pi*0.7*t)
ph=2*np.pi*np.cumsum(36*vib)/SR
eng=sum(a*np.sin(k*ph+k) for k,a in [(1,1),(2,0.6),(3,0.35),(4,0.2)])+1.4*lp(noise(N),130,2)*(0.6+0.4*np.sin(2*np.pi*11*t))
eng=lp(eng,400,2)*np.interp(t,[106.3,106.5,107.6,109,126.7],[0,0.9,0.55,0.5,0.45])
amb=amb/np.max(np.abs(amb))*0.5+eng/np.max(np.abs(eng))*0.7
amb/=np.max(np.abs(amb))
# ---- sfx
sfx=np.zeros(N)
# воспоминание: уведомление телефона на «Не выходи» (12.0) и ветер-вжух на автобус
place(sfx,ding(880),12.0,0.35); place(sfx,ding(1318),12.12,0.28)
place(sfx,bp(noise(int(2.4*SR)),150,1200)*np.sin(np.pi*np.arange(int(2.4*SR))/(2.4*SR))**2,5.5,0.18)
place(sfx,thump(75,42,0.9,5),14.5,0.7); place(sfx,swell([98,103.8,155.6],3.2,0.3,1.0),14.5,0.25)
# поворот головы — тихая шелестящая нота
place(sfx,rev_swell(1.5),19.7,0.28)
place(sfx,swell([110,116.5,220],3.0,0.8,1.0),22.0,0.22)
# рука исчезла
place(sfx,rev_swell(1.0),30.9,0.3); place(sfx,wet_slap(),33.7,0.55); place(sfx,drip(),34.5,0.3)
# отражение появляется 36.9; палец к губам 50.3; встаёт 52.9
place(sfx,rev_swell(1.3),36.2,0.35); place(sfx,thump(58,34,1.2,3.4),37.5,0.55)
place(sfx,hiss(0.9,3000,8000,0.2,3),50.2,0.18)
place(sfx,thump(55,35,1.3,3),52.6,0.55); place(sfx,squeak(0.6),52.9,0.25)
# отшатнулся; стук 58.4, 58.85, 59.25; телефон о стекло 59.9
place(sfx,lp(noise(int(0.3*SR)),1500)*np.exp(-np.arange(int(0.3*SR))/SR*10),56.0,0.3)
for tk in (58.4,58.85,59.25): place(sfx,knock(),tk,0.85)
place(sfx,knock(900),60.05,0.35)
place(sfx,ding(1046),64.0,0.4); place(sfx,ding(1568),64.12,0.3)
# водитель поднимает голову; лицо в зеркале
place(sfx,squeak(0.8),67.2,0.15)
place(sfx,swell([110,116.5,233],3.2,0.5,1.1),70.35,0.4); place(sfx,thump(55,35,1.2,3.4),70.7,0.75)
# второе сообщение
place(sfx,ding(1046),81.9,0.4); place(sfx,ding(1568),82.02,0.3)
tcur=79.9
while tcur<81.9: place(sfx,click(rng.choice([1800,2300,2800])),tcur,0.35); tcur+=rng.uniform(0.07,0.14)
# свет гаснет 86.66: щелчок+спад; скрип 88.3; свет включается 92.3
place(sfx,click(900),86.6,0.8); place(sfx,lp(noise(int(0.5*SR)),700)*np.exp(-np.arange(int(0.5*SR))/SR*7),86.6,0.4)
place(sfx,squeak(0.85),88.3,0.8)
place(sfx,click(900),92.3,0.7); place(sfx,click(1200),92.55,0.5); place(sfx,thump(60,40,0.5,8),92.9,0.4)
# второй след
place(sfx,wet_slap(),96.5,0.6); place(sfx,drip(),97.4,0.35); place(sfx,swell([123,130.8,185],3.0,0.3,1.0),96.5,0.25)
# ключ 105.6-106.1, стартёр и запуск 106.4
place(sfx,click(1200),105.55,0.7); place(sfx,click(1500),105.9,0.9)
n=int(0.9*SR); tt=np.arange(n)/SR; st=(np.sin(2*np.pi*np.cumsum(60+90*tt)/SR)+0.5*bp(noise(n),200,1500))*np.minimum(tt/0.1,1)*np.exp(-np.maximum(tt-0.6,0)*10)
place(sfx,st*0.7,105.95,0.7); place(sfx,thump(70,45,0.8,5),106.55,0.9)
# двери начинают закрываться 107.8
place(sfx,hiss(1.8,900,7000,0.05,1.6),107.8,0.6); place(sfx,thump(95,55,0.3,12),107.8,0.5)
# капли с ладони
for tk in (112.9,113.5,114.1,114.5): place(sfx,drip(),tk,0.4)
sfx/=np.max(np.abs(sfx)); sfx*=0.8
# ---- музыка: тёмный дрон, нарастание к финалу
mus=np.zeros(N)
for f,a in [(55,1),(82.4,0.6),(110,0.45),(116.5,0.2),(164.8,0.1)]:
    mus+=a*np.sin(2*np.pi*f*t+rng.uniform(0,6))*(0.7+0.3*np.sin(2*np.pi*rng.uniform(0.05,0.12)*t+rng.uniform(0,6)))
mus*=np.interp(t,[0,5,20,40,70,85,100,110,126.7],[0.5,0.45,0.6,0.7,0.85,0.8,1.0,1.1,1.0])
# сердцебиение в напряжённые моменты
def beats(t0,t1,sp0,sp1,g):
    tc=t0
    while tc<t1:
        place(sfx,thump(62,42,0.35,14),tc,g); place(sfx,thump(55,38,0.35,14),tc+0.2,g*0.7)
        tc+=sp0+(sp1-sp0)*(tc-t0)/(t1-t0)
beats(22.5,28.0,0.95,0.8,0.18); beats(99.3,126.0,0.85,0.62,0.3)
for tn,f in [(18,329.6),(45,311.1),(75,261.6),(103,246.9)]:
    n=int(4*SR); tt=np.arange(n)/SR; place(mus,np.sin(2*np.pi*f*tt)*np.exp(-tt*1.3)*0.25,tn)
mus=lp(mus,900); mus/=np.max(np.abs(mus)); mus*=0.8
def w(name,x):
    x=np.clip(x,-1,1); fi=int(0.02*SR); x[:fi]*=np.linspace(0,1,fi); x[-fi:]*=np.linspace(1,0,fi)
    sf.write(name,x.astype(np.float32),SR,subtype='PCM_16')
sfx=sfx/max(np.max(np.abs(sfx)),1e-6)*0.85
w('ambience2.wav',amb*0.85); w('sfx2.wav',sfx); w('music2.wav',mus); print('ok')
