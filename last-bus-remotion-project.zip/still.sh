#!/bin/sh
# usage: ./still.sh <seconds> -> out/still_<seconds>.jpg
F=$(python3 -c "print(round($1*30))")
npx remotion still LastBusPart1 out/still_$1.jpg --frame=$F --image-format=jpeg --jpeg-quality=85 2>&1 | tail -3
