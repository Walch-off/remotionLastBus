import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path';
const times = process.argv.slice(2).map(Number);
const browserExecutable='/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const comp = await selectComposition({serveUrl, id: process.env.COMP || 'LastBusPart1', browserExecutable});
for (const t of times) {
  await renderStill({composition: comp, serveUrl, frame: Math.round(t*30), output: `out/s_${t}.jpg`, imageFormat: 'jpeg', jpegQuality: 80, browserExecutable});
  console.log('ok', t);
}
