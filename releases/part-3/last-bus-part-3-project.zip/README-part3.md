# Последний автобус — часть 3 (Remotion)

Проект анимационной серии для TikTok «Последний автобус», часть 3.
Композиция `LastBusPart3` — вертикальное видео 1080×1920, 30 fps, H.264.

## Состав

- `src/ep3/` — сцены, субтитры и оверлеи третьей серии:
  - `story3.ts` — тайминги сцен и ключевые события (по словам озвучки);
  - `Shots3.tsx` — все планы (компоновка и анимация);
  - `Parts3.tsx` — элементы: улыбка двойника, рука с пальцами (3→2→1),
    ладонь на стекле, водитель лицом, зеркало с надписью, пол со следами и др.;
  - `Subtitles3.tsx` — русские субтитры по словам озвучки;
  - `Overlays3.tsx` — плашка «часть 3», результат голосования, финальный выбор.
- `src/components/`, `src/scenes/`, `src/ep2/`, `src/story.ts` — переиспользуемые
  компоненты и предыдущие серии (композиции `LastBusPart1`, `LastBusPart2`).
- `src/data/words3.json` — таймкоды слов озвучки (выравнивание по паузам).
- `public/audio3/` — звуковые дорожки:
  - `voice_final3.wav` — исходная озвучка ElevenLabs без изменений;
  - `ambience3.wav`, `sfx3.wav`, `music3.wav` — синтезированные атмосфера,
    эффекты и музыка (`source3/synth3.py`).
- `source3/` — вспомогательные скрипты и референс героя `hero.png`.
- `chrome-wrapper.sh` — обёртка для браузера (см. «Браузер»).

## Требования

- Node.js 18+ и npm;
- Chromium / Chrome Headless Shell (или любой Chrome).

## Установка

```bash
npm install
```

## Браузер

Remotion нужен исполняемый файл Chrome/Chromium. Укажите его в
`remotion.config.ts`:

```ts
Config.setBrowserExecutable('/путь/к/chrome-headless-shell');
```

Либо удалите эту строку — тогда Remotion попытается скачать Chrome Headless
Shell самостоятельно (нужен доступ в интернет).

В сборочной среде использовалась обёртка `chrome-wrapper.sh`, которая
задаёт `LD_LIBRARY_PATH` для chromium из пакета `@sparticuz/chromium`
(ставится отдельно: `npm i @sparticuz/chromium`, затем извлечь бинарник).
Для обычного окружения достаточно указать путь к системному Chrome.

## Рендер

```bash
# целиком (≈ 4700 кадров)
npx remotion render LastBusPart3 out/last-bus-part-3.mp4

# фрагмент для проверки
npx remotion render LastBusPart3 out/test.mp4 --frames=320-410

# один кадр
npx remotion still LastBusPart3 out/frame.png --frame=900
```

Параметры кодека (H.264, yuv420p, jpeg-кадры) заданы в `remotion.config.ts`.
При нехватке памяти/ядер оставьте `Config.setConcurrency(1)`.

## Звук

Оригинальный WAV озвучки не изменён. Дорожки атмосферы, эффектов и музыки
генерируются скриптом:

```bash
pip install numpy scipy soundfile
python3 source3/synth3.py   # перезапишет public/audio3/{ambience3,sfx3,music3}.wav
```

Времена звуковых событий в `synth3.py` привязаны к таймкодам слов из
`src/data/words3.json`.

## Субтитры

Субтитры строятся по `words3.json` (см. `src/ep3/Subtitles3.tsx`).
Слова, показанные графикой (надпись на зеркале, финальная плашка),
скрыты из субтитров, чтобы не дублировать текст.
