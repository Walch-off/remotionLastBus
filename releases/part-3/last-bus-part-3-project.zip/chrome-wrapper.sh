#!/bin/sh
export LD_LIBRARY_PATH="/tmp/al2023/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export FONTCONFIG_PATH="/tmp/fonts${FONTCONFIG_PATH:+:$FONTCONFIG_PATH}"
exec /tmp/chromium "$@"
