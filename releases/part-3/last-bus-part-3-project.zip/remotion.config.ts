import {Config} from '@remotion/cli/config';
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setCodec('h264');
Config.setPixelFormat('yuv420p');
Config.setBrowserExecutable('/home/user/work/project/chrome-wrapper.sh');
Config.setConcurrency(1);
