#!/usr/bin/env python3
"""Синтез звуковых дорожек части 3: атмосфера, эффекты, музыка.
Все события привязаны к таймкодам слов words3.json (см. E3 в story3.ts)."""
import numpy as np, soundfile as sf
from scipy.signal import butter, lfilter

SR = 44100
DUR = 155.6
N = int(SR * DUR)
rng = np.random.default_rng(33)
t = np.arange(N) / SR

def lp(x, f, o=2):
    b, a = butter(o, f / (SR / 2), 'low'); return lfilter(b, a, x)
def hp(x, f, o=2):
    b, a = butter(o, f / (SR / 2), 'high'); return lfilter(b, a, x)
def bp(x, f1, f2, o=2):
    b, a = butter(o, [f1 / (SR / 2), f2 / (SR / 2)], 'band'); return lfilter(b, a, x)
def noise(n):
    return rng.standard_normal(n)
def place(buf, sig, t0, gain=1.0):
    i0 = int(t0 * SR); n = min(len(sig), N - i0)
    if n > 0:
        buf[i0:i0 + n] += sig[:n] * gain
def thump(f0=70, f1=40, dur=0.6, decay=7):
    n = int(dur * SR); tt = np.arange(n) / SR
    fr = f1 + (f0 - f1) * np.exp(-tt * 18)
    return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-tt * decay)
def hiss(dur, f1, f2, attack=0.04, decay=3.0):
    n = int(dur * SR); x = bp(noise(n), f1, f2, 2); tt = np.arange(n) / SR
    return x * np.minimum(tt / attack, 1) * np.exp(-tt * decay)
def click(f=2500):
    n = int(0.012 * SR)
    return bp(noise(n), f * 0.6, f * 1.5) * np.exp(-np.arange(n) / SR * 400)
def ding(f, dur=0.9):
    n = int(dur * SR); tt = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2.76 * f * tt)) * np.exp(-tt * 6)
def swell(freqs, dur, attack=0.6, decay=1.8):
    n = int(dur * SR); tt = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * tt + i) for i, f in enumerate(freqs))
    return x / len(freqs) * np.minimum(tt / attack, 1) ** 2 * np.exp(-np.maximum(tt - attack, 0) * decay)
def rev_swell(dur=1.6):
    n = int(dur * SR); tt = np.arange(n) / SR
    x = bp(noise(n), 300, 3000, 2) + 0.6 * np.sin(2 * np.pi * (110 + 120 * tt / dur) * tt)
    return x * (tt / dur) ** 3
def drip():
    n = int(0.25 * SR); tt = np.arange(n) / SR
    fr = 900 + 1400 * np.exp(-tt * 30)
    return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-tt * 22) * 0.6
def wet_step():
    n = int(0.5 * SR); tt = np.arange(n) / SR
    tp = thump(105, 58, 0.5, 11)
    return lp(noise(n), 850) * np.exp(-tt * 13) + 0.55 * tp[:n]
def squeak(dur=0.7):
    n = int(dur * SR); tt = np.arange(n) / SR
    fr = 700 + 500 * np.sin(2 * np.pi * 3.2 * tt) + 300 * tt
    return (np.sin(2 * np.pi * np.cumsum(fr) / SR) * 0.5 + 0.5 * bp(noise(n), 900, 2600)) * np.sin(np.pi * tt / dur) ** 1.5 * 0.7

# ---------- АТМОСФЕРА ----------
amb = np.zeros(N)
# салон: гул ламп
hum = np.sin(2 * np.pi * 100 * t) * 0.5 + np.sin(2 * np.pi * 200 * t) * 0.2 + lp(noise(N), 400, 1) * 0.25
amb += hum * 0.32
# дождь за окном
rain = hp(noise(N), 1200, 1) * (0.55 + 0.25 * np.sin(2 * np.pi * 0.23 * t)) + lp(noise(N), 500, 1) * 0.16
amb += rain * 0.30
# мерцание ламп в напряжённые моменты
def buzz(t0, t1, amp):
    seg = int((t1 - t0) * SR)
    g = (rng.random(seg) > 0.6).astype(float); g = lp(g, 40, 1)
    place(amb, bp(noise(seg), 150, 900) * g * amp, t0)
buzz(122.6, 124.2, 0.7); buzz(124.2, 125.6, 0.5)
# тёмный период 62.5–71.5: приглушаем гул
dark = np.interp(t, [62.4, 62.8, 71.2, 71.8], [1, 0.18, 0.18, 1])
amb *= dark
# двигатель: старт 18.8, движение до 115.6, потом холостой
vib = 1 + 0.012 * np.sin(2 * np.pi * 0.7 * t)
ph = 2 * np.pi * np.cumsum(36 * vib) / SR
eng = sum(a * np.sin(k * ph + k) for k, a in [(1, 1), (2, 0.6), (3, 0.35), (4, 0.2)]) \
    + 1.4 * lp(noise(N), 130, 2) * (0.6 + 0.4 * np.sin(2 * np.pi * 11 * t))
eng = lp(eng, 400, 2) * np.interp(t, [18.6, 19.2, 26, 60, 90, 113, 116.2, 118, 155.6], [0, 0.85, 0.6, 0.65, 0.6, 0.55, 0.25, 0.18, 0.15])
amb = amb / np.max(np.abs(amb)) * 0.5 + eng / np.max(np.abs(eng)) * 0.62
amb /= np.max(np.abs(amb))

# ---------- ЭФФЕКТЫ ----------
sfx = np.zeros(N)
# двери закрываются ~5.6
place(sfx, hiss(1.2, 900, 7000, 0.05, 1.8), 4.55, 0.55)
place(sfx, thump(95, 55, 0.35, 12), 5.58, 0.6)
place(sfx, click(1100), 5.6, 0.5)
# улыбка — низкий стон-нарастание
place(sfx, swell([82.4, 87.3, 123.5], 3.2, 0.5, 0.9), 8.2, 0.30)
place(sfx, rev_swell(1.2), 11.9, 0.22)
# капли со ладони на стекле 12.5-15.3
for tk in (12.9, 13.6, 14.4, 15.0):
    place(sfx, drip(), tk, 0.35)
# автобус тронулся 18.8
n = int(1.1 * SR); tt = np.arange(n) / SR
starter = (np.sin(2 * np.pi * np.cumsum(55 + 80 * tt) / SR) + 0.5 * bp(noise(n), 200, 1500)) * np.minimum(tt / 0.12, 1) * np.exp(-np.maximum(tt - 0.7, 0) * 8)
place(sfx, starter, 18.5, 0.55)
place(sfx, thump(70, 45, 0.8, 5), 19.3, 0.55)
# рука поднимается 40.6, загиб пальца 44.0
place(sfx, rev_swell(1.1), 40.2, 0.26)
place(sfx, click(1600), 43.98, 0.35)
place(sfx, swell([98, 103.8, 155.6], 2.6, 0.35, 1.0), 44.1, 0.26)
# бег к водителю 46.9-50.5
for tk in (46.95, 47.35, 47.75, 48.15, 48.55, 48.95):
    place(sfx, wet_step(), tk, 0.28)
# свет выключили 62.0
place(sfx, click(900), 62.0, 0.85)
place(sfx, lp(noise(int(0.55 * SR)), 700) * np.exp(-np.arange(int(0.55 * SR)) / SR * 7), 62.02, 0.45)
# мокрые шаги в темноте: Один. Второй. Третий. и дальше
for tk, g in ((66.94, 0.85), (67.30, 0.9), (67.76, 0.95), (68.6, 0.9), (69.5, 0.85), (70.35, 0.8)):
    place(sfx, wet_step(), tk, g)
# фонарик 71.27
place(sfx, click(1400), 71.27, 0.7)
place(sfx, ding(1200, 0.3), 71.32, 0.12)
# следы на полу 75.5-80.2
for tk, g in ((75.6, 0.5), (76.4, 0.5), (77.4, 0.55), (78.3, 0.55), (79.2, 0.6), (79.9, 0.65)):
    place(sfx, wet_step(), tk, g)
# удар спиной о поручень 81.8
place(sfx, thump(220, 90, 0.5, 9), 81.78, 0.8)
place(sfx, bp(noise(int(0.4 * SR)), 700, 2400) * np.exp(-np.arange(int(0.4 * SR)) / SR * 16), 81.79, 0.5)
place(sfx, click(2200), 81.8, 0.4)
# шаги останавливаются 83.9
place(sfx, wet_step(), 83.45, 0.55)
place(sfx, rev_swell(1.2), 83.95, 0.30)
# отражение 87.5, указание 92.6-94.5
place(sfx, swell([73.4, 77.8, 110], 3.6, 0.35, 0.9), 87.3, 0.42)
place(sfx, thump(55, 34, 1.2, 3.2), 87.6, 0.5)
place(sfx, rev_swell(1.3), 92.3, 0.28)
place(sfx, hiss(0.9, 3000, 8000, 0.2, 3), 94.2, 0.16)
# зеркало: запотевание и надпись 96.3-100.3
place(sfx, swell([110, 116.5, 233], 3.4, 0.5, 1.0), 96.2, 0.34)
for tk, f in ((97.9, 880), (98.6, 1046), (99.4, 1318)):
    place(sfx, ding(f, 1.1), tk, 0.22)
# моргнул 100.7 — надпись исчезла
place(sfx, rev_swell(0.8), 100.55, 0.24)
place(sfx, hiss(0.5, 2000, 6000, 0.1, 5), 101.15, 0.14)
# водитель заговорил 104.2
place(sfx, swell([55, 82.4, 110], 4.2, 0.8, 0.8), 103.9, 0.34)
# вопрос — замирание + сердце
beats = [(110.6, 0.5), (111.5, 0.55), (112.35, 0.6), (113.15, 0.62), (113.9, 0.66)]
for tk, g in beats:
    place(sfx, thump(62, 42, 0.35, 14), tk, g * 0.5)
    place(sfx, thump(55, 38, 0.35, 14), tk + 0.22, g * 0.35)
# автобус остановился 115.7
place(sfx, hiss(1.6, 500, 5000, 0.05, 1.4), 115.2, 0.5)
place(sfx, thump(88, 52, 0.45, 10), 115.85, 0.65)
# один палец 121.3
place(sfx, rev_swell(1.0), 120.8, 0.24)
place(sfx, swell([98, 103.8, 146.8], 2.4, 0.3, 1.1), 121.3, 0.3)
# свет мигнул 123.3, улыбка в зеркале 125.5
place(sfx, click(700), 123.3, 0.5)
place(sfx, click(900), 123.75, 0.4)
place(sfx, swell([65.4, 69.3, 98], 3.6, 0.3, 0.8), 125.3, 0.5)
place(sfx, thump(52, 33, 1.3, 3.0), 125.7, 0.6)
# голос из прохода 133.3
place(sfx, swell([87.3, 92.5, 130.8], 3.6, 0.5, 0.9), 133.0, 0.36)
place(sfx, rev_swell(1.2), 136.0, 0.24)
# поворот водителя 138.7, ключ 141.0
place(sfx, squeak(0.85), 138.5, 0.4)
place(sfx, thump(60, 40, 0.5, 9), 139.0, 0.35)
place(sfx, click(1500), 140.96, 0.6)
place(sfx, ding(2093, 0.5), 141.02, 0.18)
place(sfx, ding(2637, 0.4), 141.12, 0.13)
# финал: сердце и акцент
tk = 142.4
while tk < 151.0:
    place(sfx, thump(60, 40, 0.35, 14), tk, 0.5)
    place(sfx, thump(53, 37, 0.35, 14), tk + 0.21, 0.36)
    tk += 0.95
place(sfx, swell([55, 58.3, 87.3], 5.0, 1.2, 0.7), 150.4, 0.5)
place(sfx, thump(48, 30, 1.6, 2.2), 151.37, 0.85)
place(sfx, rev_swell(1.8), 152.6, 0.3)
sfx /= np.max(np.abs(sfx))
sfx *= 0.85

# ---------- МУЗЫКА ----------
mus = np.zeros(N)
for f, a in [(55, 1), (82.4, 0.6), (110, 0.45), (116.5, 0.2), (164.8, 0.1)]:
    mus += a * np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) * (0.7 + 0.3 * np.sin(2 * np.pi * rng.uniform(0.05, 0.12) * t + rng.uniform(0, 6)))
mus *= np.interp(t, [0, 5, 18, 30, 44, 62, 72, 86, 100, 115, 130, 142, 151, 155.6],
                 [0.5, 0.5, 0.62, 0.7, 0.6, 0.5, 0.66, 0.8, 0.75, 0.7, 0.85, 1.05, 1.15, 1.0])
for tn, f in [(29.2, 329.6), (56, 311.1), (86, 261.6), (104, 246.9), (123.3, 220), (142, 207.7)]:
    n = int(4.5 * SR); tt = np.arange(n) / SR
    place(mus, np.sin(2 * np.pi * f * tt) * np.exp(-tt * 1.2) * 0.26, tn)
mus = lp(mus, 900)
mus /= np.max(np.abs(mus))
mus *= 0.8

def w(name, x):
    x = np.clip(x, -1, 1)
    fi = int(0.02 * SR)
    x[:fi] *= np.linspace(0, 1, fi)
    x[-fi:] *= np.linspace(1, 0, fi)
    sf.write(name, x.astype(np.float32), SR, subtype='PCM_16')

out = '/home/user/work/project/public/audio3/'
w(out + 'ambience3.wav', amb * 0.85)
w(out + 'sfx3.wav', sfx)
w(out + 'music3.wav', mus)
print('ok')
