import React from 'react';
import {useCurrentFrame} from 'remotion';
import {SKIN, clamp, lin, ramp} from '../common';
import {WetPrint} from '../components/Hero';

/* ============================================================
   Часть 3 — новые компоненты: улыбка двойника, рука с пальцами,
   ладонь на стекле, водитель лицом, зеркало с надписью, пол со
   следами, луч фонарика, остановка впереди.
   ============================================================ */

const cl = (v: number, a: number, b: number) => clamp((v - a) / (b - a));

/** Тревожная слишком широкая улыбка (в координатах лица героя: рот около 505,280). */
export const CreepySmile: React.FC<{grow?: number; color?: string}> = ({grow = 1, color}) => {
  const g = clamp(grow);
  const w = 26 + 68 * g;           // половина ширины
  const drop = 8 + 44 * g;         // глубина вниз
  const up = 4 + 14 * g;           // уголки вверх
  const id = color ? 'csm-dk' : 'csm';
  return (
    <g opacity={Math.min(1, 0.25 + g)}>
      <defs>
        <clipPath id={id}>
          <path d={`M${505 - w} ${280 - up} Q505 ${280 - up - 10} ${505 + w} ${280 - up} Q505 ${280 + drop} ${505 - w} ${280 - up}Z`} />
        </clipPath>
      </defs>
      {/* тёмный рот с объёмом */}
      <path d={`M${505 - w} ${280 - up} Q505 ${280 - up - 12} ${505 + w} ${280 - up} Q505 ${280 + drop + 6} ${505 - w} ${280 - up}Z`}
        fill={color ?? '#57202a'} stroke="#2b0d12" strokeWidth={3} strokeLinejoin="round" />
      <g clipPath={`url(#${id})`}>
        {/* внутренний объём */}
        <ellipse cx={505} cy={280 + drop * 0.75} rx={w * 0.8} ry={drop * 0.5} fill="#2b0d12" opacity={0.85} />
        {/* линия зубов — отдельные зубы, не полоска */}
        {[-2.4, -1.45, -0.5, 0.5, 1.45, 2.4].map((k, i) => (
          <rect key={i} x={505 + k * (w / 3.1) - w / 7} y={280 - up - 12} width={w / 3.5} height={26 + 16 * g} rx={7}
            fill="#f4ead8" stroke="#c9b394" strokeWidth={2} />
        ))}
        <path d={`M${505 - w} ${280 - up + 2} Q505 ${280 - up + 30 + 10 * g} ${505 + w} ${280 - up + 2}`} stroke="#8d5a52" strokeWidth={3} fill="none" opacity={0.6} />
        {/* нижняя губа */}
        <path d={`M${505 - w * 0.82} ${280 + drop * 0.62} Q505 ${280 + drop + 12} ${505 + w * 0.82} ${280 + drop * 0.62}`}
          stroke="#c98d80" strokeWidth={5} fill="none" strokeLinecap="round" opacity={0.8} />
      </g>
      {/* морщинки у уголков */}
      {g > 0.35 && (
        <g opacity={(g - 0.35) / 0.65} stroke="#b07060" strokeWidth={3.4} fill="none" strokeLinecap="round">
          <path d={`M${505 - w - 4} ${280 - up - 2} q-12 -10 -14 -22`} />
          <path d={`M${505 + w + 4} ${280 - up - 2} q12 -10 14 -22`} />
        </g>
      )}
    </g>
  );
};

/** Рука с поднятыми пальцами (счёт 3 → 2 → 1). Локально: запястье внизу, пальцы вверх. */
export const FingerHand: React.FC<{up: number; foldT?: number; skin?: string}> = ({up, foldT = 1, skin = SKIN}) => {
  const fingerX = [-52, -17, 17, 52];
  const lens = [128, 150, 142, 108];
  // пальцы 0..up-1 подняты; палец up — загибается (foldT: 0 = поднят, 1 = загнут); остальные загнуты
  return (
    <g>
      {/* ладонь */}
      <path d="M-72 30 Q-84 110 -62 178 L62 178 Q84 110 72 30 Q0 6 -72 30Z" fill={skin} stroke="#d49a6e" strokeWidth={3} />
      <path d="M-34 60 Q0 74 34 60 M-30 100 Q0 114 30 100" stroke="#d9a67a" strokeWidth={2.6} fill="none" opacity={0.7} />
      {/* большой палец (согнут вбок) */}
      <g transform="translate(-86 118) rotate(-24)">
        <rect x={-22} y={-46} width={44} height={96} rx={22} fill={skin} stroke="#d49a6e" strokeWidth={3} />
      </g>
      {fingerX.map((fx, i) => {
        const isRaised = i < up;
        const isFolding = i === up && foldT < 1;
        const rot = isFolding ? 88 * foldT : 0;
        return (
          <g key={i} transform={`translate(${fx} 40) rotate(${rot})`}>
            {isRaised || isFolding ? (
              <g>
                <rect x={-19} y={-lens[i]} width={38} height={lens[i] + 46} rx={19} fill={skin} stroke="#d49a6e" strokeWidth={3} />
                <path d={`M-8 ${-lens[i] + 34} v${lens[i] * 0.42}`} stroke="#fff" strokeWidth={5} strokeLinecap="round" opacity={0.35} />
                <path d={`M-13 ${-lens[i] * 0.45} h26`} stroke="#d9a67a" strokeWidth={2.4} opacity={0.7} />
              </g>
            ) : (
              /* согнутый палец — кулачок на ладони */
              <g>
                <rect x={-19} y={-16} width={38} height={72} rx={19} fill={skin} stroke="#d49a6e" strokeWidth={3} />
                <path d="M-16 -8 Q0 -26 16 -8" stroke="#d49a6e" strokeWidth={3} fill="none" />
              </g>
            )}
          </g>
        );
      })}
    </g>
  );
};

/** Ладонь, прижатая к стеклу (вид изнутри). Используется и в общем плане, и крупно. */
export const PalmOnGlass: React.FC<{x: number; y: number; scale?: number; dripT?: number; sleeve?: boolean}> = ({x, y, scale = 1, dripT = 0, sleeve = true}) => {
  const frame = useCurrentFrame();
  const fingers: [number, number, number][] = [[-46, -20, -18], [-16, -30, -6], [16, -28, 6], [46, -16, 18]];
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      {/* мокрое пятно на стекле вокруг */}
      <ellipse cx={0} cy={-10} rx={175} ry={215} fill="#bfe3ff" opacity={0.10} />
      {/* пальцы (начинаются внутри ладони) */}
      {fingers.map(([fx, fy, rot], i) => (
        <g key={i} transform={`translate(${fx} ${fy}) rotate(${rot})`}>
          <rect x={-27} y={-186} width={54} height={220} rx={27} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
          <path d={`M-10 ${-150} v62`} stroke="#fff" strokeWidth={8} strokeLinecap="round" opacity={0.42} />
          <path d={`M-14 ${-92} h28`} stroke="#d9a67a" strokeWidth={3} opacity={0.7} />
          <path d={`M-14 ${-42} h28`} stroke="#d9a67a" strokeWidth={3} opacity={0.7} />
        </g>
      ))}
      {/* большой палец влево */}
      <g transform="translate(-104 30) rotate(-62)">
        <rect x={-26} y={-72} width={52} height={128} rx={26} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
        <path d="M-10 -40 v34" stroke="#fff" strokeWidth={7} strokeLinecap="round" opacity={0.4} />
      </g>
      {/* ладонь */}
      <ellipse cx={0} cy={38} rx={92} ry={104} fill={SKIN} stroke="#d49a6e" strokeWidth={4} />
      <path d="M-56 4 Q0 -30 58 6 M-40 62 Q0 88 44 58" stroke="#d9a67a" strokeWidth={4} fill="none" opacity={0.75} />
      {/* мокрый блеск */}
      <ellipse cx={-34} cy={10} rx={44} ry={22} fill="#fff" opacity={0.28} transform="rotate(-18 -34 10)" />
      <ellipse cx={30} cy={70} rx={38} ry={16} fill="#fff" opacity={0.22} transform="rotate(12 30 70)" />
      {/* капли, стекающие вниз */}
      {[-72, -22, 30, 78].map((dx, i) => {
        const fall = ((frame * 0.9 + i * 24 + dripT * 30) % 70) / 70;
        return (
          <g key={i} opacity={0.85 - fall * 0.6}>
            <path d={`M${dx} ${120 + fall * 90} q-11 18 0 27 q11 -9 0 -27z`} fill="#bfe3ff" stroke="#7fb4e6" strokeWidth={2} />
          </g>
        );
      })}
      {/* капли на стекле */}
      {[[-150, -120, 8], [140, -60, 6], [120, 130, 9], [-140, 150, 7], [165, 40, 5]].map(([dx, dy, r], i) => (
        <ellipse key={i} cx={dx} cy={dy} rx={r} ry={r * 1.35} fill="#cfe6ff" opacity={0.3} />
      ))}
      {/* манжета и рукав толстовки */}
      {sleeve && (
        <g>
          <rect x={-88} y={128} width={176} height={54} rx={22} fill="#445f95" />
          <rect x={-88} y={128} width={176} height={10} rx={5} fill="#3a5287" />
          <path d="M-92 176 L-130 330 L130 330 L92 176Z" fill="#5470a6" />
        </g>
      )}
    </g>
  );
};

/** Водитель лицом к герою: кепка, куртка, спокойное лицо; опции — улыбка, ключ, поворот. */
export const DriverFront: React.FC<{
  x: number; y: number; scale?: number; turn?: number; smile?: number; keyT?: number; blinkOnce?: number; opacity?: number; look?: [number, number];
}> = ({x, y, scale = 1, turn = 1, smile = 0, keyT = 0, blinkOnce = 0, opacity = 1, look = [0, 0]}) => {
  const frame = useCurrentFrame();
  const jacket = '#2b3250', jacketL = '#3a4366', skin = '#cfae96', cap = '#1a1d29';
  const breathe = Math.sin(frame / 23) * 1.2 * (1 - clamp(turn < 1 ? 0 : 0)) * 0; // тело неподвижно
  const lidB = blinkOnce;
  return (
    <g transform={`translate(${x} ${y}) scale(${scale * Math.max(0.18, turn)} ${scale})`} opacity={opacity}>
      {/* плечи и куртка */}
      <path d="M-210 210 Q-230 90 -150 40 Q-70 0 0 0 Q70 0 150 40 Q230 90 210 210 L210 470 L-210 470Z" fill={jacket} />
      <path d="M0 30 V470" stroke="#1d2340" strokeWidth={5} />
      <path d="M-150 60 Q0 6 150 60" stroke={jacketL} strokeWidth={9} fill="none" opacity={0.55} />
      {/* шея */}
      <rect x={-44} y={-40} width={88} height={110} rx={26} fill="#b99580" />
      {/* голова */}
      <g transform={`translate(0 ${breathe})`}>
        <ellipse cx={0} cy={-120} rx={112} ry={128} fill={skin} />
        {/* уши */}
        <ellipse cx={-112} cy={-112} rx={16} ry={26} fill="#b99580" />
        <ellipse cx={112} cy={-112} rx={16} ry={26} fill="#b99580" />
        {/* кепка */}
        <path d="M-116 -160 Q-110 -262 0 -266 Q110 -262 116 -160 Q0 -132 -116 -160Z" fill={cap} />
        <path d="M-118 -164 Q0 -128 118 -164 L136 -150 Q0 -108 -136 -150Z" fill="#12151f" />
        <rect x={-16} y={-206} width={32} height={12} rx={6} fill="#3a3f55" />
        {/* брови */}
        <path d="M-74 -158 Q-46 -172 -18 -162" stroke="#22242e" strokeWidth={11} fill="none" strokeLinecap="round" />
        <path d="M18 -162 Q46 -172 74 -158" stroke="#22242e" strokeWidth={11} fill="none" strokeLinecap="round" />
        {/* глаза */}
        {[-46, 46].map((ex, i) => (
          <g key={i}>
            <ellipse cx={ex} cy={-118} rx={22} ry={15 * (1 - 0.9 * lidB)} fill="#fffaf0" />
            <circle cx={ex + look[0] * 7} cy={-118 + look[1] * 4} r={8.5} fill="#2a1a10" />
            <circle cx={ex + look[0] * 7 - 3} cy={-122 + look[1] * 4} r={2.6} fill="#fff" />
            {lidB > 0 && <rect x={ex - 24} y={-137} width={48} height={24} rx={8} fill={skin} />}
          </g>
        ))}
        {/* нос */}
        <path d="M-2 -108 q10 22 -4 30" stroke="#a5806c" strokeWidth={5} fill="none" strokeLinecap="round" />
        {/* рот: спокойный или улыбка */}
        {smile > 0.02 ? (
          <g transform="translate(-505 -322)">
            <CreepySmile grow={smile} />
          </g>
        ) : (
          <path d="M-30 -38 Q0 -31 30 -38" stroke="#7a4a3c" strokeWidth={8} fill="none" strokeLinecap="round" />
        )}
      </g>
      {/* рука с ключом */}
      {keyT > 0 && (
        <g opacity={keyT} transform={`translate(150 ${280}) rotate(-8)`}>
          {/* предплечье */}
          <path d={`M-46 -120 Q-30 -40 -20 10 L54 10 Q50 -60 30 -120Z`} fill={jacket} />
          {/* кисть */}
          <ellipse cx={16} cy={44} rx={52} ry={62} fill={skin} />
          {[-30, -10, 10, 30].map((fx) => <rect key={fx} x={fx - 2} y={62} width={22} height={54} rx={11} fill={skin} stroke="#a3836e" strokeWidth={2} />)}
          {/* ключ — соразмерен ладони */}
          <g transform="translate(16 30) rotate(-14)">
            <circle cx={-38} cy={0} r={34} fill="none" stroke="#d8c27a" strokeWidth={13} />
            <rect x={-8} y={-9} width={92} height={18} rx={8} fill="#d8c27a" stroke="#8a7a3a" strokeWidth={2.5} />
            <rect x={58} y={8} width={13} height={22} rx={4} fill="#d8c27a" stroke="#8a7a3a" strokeWidth={2} />
            <rect x={32} y={8} width={12} height={17} rx={4} fill="#d8c27a" stroke="#8a7a3a" strokeWidth={2} />
          </g>
        </g>
      )}
    </g>
  );
};

/** Крупный план зеркала: запотевшее стекло, надпись проступает и исчезает. */
export const MirrorCloseUp: React.FC<{
  textOp?: number; gone?: number; faceNode?: React.ReactNode; fog?: number;
}> = ({textOp = 0, gone = 0, faceNode, fog = 1}) => {
  const frame = useCurrentFrame();
  const letters = ['НЕ', 'ОТВЕЧАЙ', 'ЕМУ'];
  const total = letters.join('').length;
  let k = 0;
  return (
    <g>
      {/* салон вокруг */}
      <rect width={1080} height={1920} fill="#0b1226" />
      <rect x={0} y={0} width={1080} height={230} fill="#090e1e" />
      <rect x={60} y={210} width={960} height={18} rx={9} fill="#222c4c" />
      {/* корпус зеркала */}
      <rect x={120} y={430} width={840} height={640} rx={42} fill="#0b0f1d" stroke="#2f3a5c" strokeWidth={16} />
      <rect x={158} y={468} width={764} height={564} rx={22} fill="#8fa3c0" />
      <clipPath id="mcuClip"><rect x={158} y={468} width={764} height={564} rx={22} /></clipPath>
      <g clipPath="url(#mcuClip)">
        {/* запотевшее стекло */}
        <rect x={158} y={468} width={764} height={564} fill="url(#fogG)" opacity={fog} />
        {faceNode}
        {/* потёки конденсата */}
        {[[260, 470, 240], [420, 470, 320], [640, 470, 260], [790, 470, 380], [540, 560, 200]].map(([sx, sy, len], i) => {
          const slide = ((frame * 0.3 + i * 40) % 240) / 240;
          return <path key={i} d={`M${sx} ${sy + slide * 60} q-6 ${len / 2} 2 ${len}`} stroke="#c7d5e8" strokeWidth={5 + (i % 3) * 2} fill="none" opacity={0.16} strokeLinecap="round" />;
        })}
        {/* надпись */}
        <g opacity={(1 - gone) * 1} transform={`translate(540 760)`}>
          {letters.map((w, wi) => (
            <text key={wi} x={0} y={(wi - 1) * 130} textAnchor="middle" fontFamily="Inter" fontWeight={900} fontSize={wi === 1 ? 112 : 96}
              fill="#22345c" opacity={0.92} style={{paintOrder: 'stroke', stroke: '#d7e2f0', strokeWidth: 7, strokeLinejoin: 'round'}}>
              {w.split('').map((ch, ci) => {
                k += 1;
                return <tspan key={ci} opacity={clamp((textOp * total - (k - 1)) / 1.6)}>{ch}</tspan>;
              })}
            </text>
          ))}
        </g>
        <path d="M158 468 L340 468 L220 1032 L158 1032Z" fill="#fff" opacity={0.08} />
      </g>
      {/* блик стекла */}
      <rect x={158} y={468} width={764} height={564} rx={22} fill="url(#glassSheen)" />
    </g>
  );
};

/** Пол салона с мокрыми следами, приближающимися к герою, и светом фонарика. */
export const FloorPrints: React.FC<{
  count: number; beam?: number; heroFeet?: boolean;
}> = ({count, beam = 1, heroFeet = true}) => {
  const frame = useCurrentFrame();
  // перспектива пола: следы идут от центра-сверху к зрителю
  const spots: [number, number, number][] = [
    [545, 1010, 0.52], [505, 1130, 0.66], [565, 1265, 0.82], [505, 1425, 1.0], [575, 1600, 1.2], [480, 1785, 1.42],
  ];
  return (
    <g>
      <rect width={1080} height={1920} fill="#0a1128" />
      {/* потолок и стены для читаемости */}
      <rect x={0} y={0} width={1080} height={620} fill="#0c1430" />
      <rect x={0} y={560} width={1080} height={26} fill="#22305a" />
      {[-1, 1].map((sd) => (
        <polygon key={sd} points={sd < 0 ? '0,560 320,700 320,1920 0,1920' : '1080,560 760,700 760,1920 1080,1920'} fill="#111c3e" />
      ))}
      {/* пол */}
      <polygon points="0,1920 1080,1920 760,700 320,700" fill="#152142" />
      <polygon points="240,1920 840,1920 620,700 460,700" fill="#1a2850" />
      <path d="M330 700 L120 1920 M750 700 L960 1920" stroke="#22305a" strokeWidth={6} />
      {/* свет фонарика на полу */}
      <ellipse cx={540} cy={1330} rx={430} ry={520} fill="url(#flashG)" opacity={0.85 * beam} />
      {/* следы */}
      {spots.map(([px, py, s], i) => {
        const app = clamp((count - i) * 1.4);
        return (
          <g key={i} opacity={app}>
            <ellipse cx={px} cy={py} rx={120 * s} ry={52 * s} fill="#8fb6ff" opacity={0.30} />
            <g transform={`translate(${px} ${py}) scale(${s * 1.7} ${s * 0.72}) rotate(${i % 2 ? 6 : -6})`}>
              <WetPrint glow={0.25} frame={frame + i * 17} />
            </g>
          </g>
        );
      })}
      {/* ноги героя внизу */}
      {heroFeet && (
        <g>
          <path d="M330 1830 Q340 1770 380 1762 L430 1762 Q452 1772 450 1830Z" fill="#26262d" />
          <path d="M330 1848 Q340 1836 452 1836 L452 1862 Q380 1872 330 1862Z" fill="#6b6b73" />
        </g>
      )}
    </g>
  );
};

/** Луч фонарика из телефона. */
export const FlashBeam: React.FC<{
  x: number; y: number; rot?: number; len?: number; spread?: number; on?: number;
}> = ({x, y, rot = 0, len = 1500, spread = 210, on = 1}) => {
  const frame = useCurrentFrame();
  const wob = Math.sin(frame / 7) * 4;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot + wob})`} opacity={on}>
      <polygon points={`0,0 ${len},${-spread} ${len},${spread}`} fill="url(#beamG)" />
      <polygon points={`0,0 ${len * 0.7},${-spread * 0.45} ${len * 0.7},${spread * 0.45}`} fill="url(#beamG)" opacity={0.7} />
    </g>
  );
};

/** Остановка «прямо перед автобусом» — вид через лобовое стекло. */
export const StopAhead: React.FC<{lampLit?: number; doubleOp?: number; palm?: number}> = ({lampLit = 1, doubleOp = 1, palm = 0}) => {
  const frame = useCurrentFrame();
  const fl = ((frame * 7919) % 17) < 2 ? 0.5 : 1;
  const L = lampLit * fl;
  return (
    <g>
      {/* тротуар и земля */}
      <rect x={40} y={760} width={1000} height={320} fill="#131c38" />
      <rect x={40} y={760} width={1000} height={14} fill="#26355e" />
      {/* навес и скамейка */}
      <g transform="translate(210 420) scale(1.35)">
        <rect x={0} y={80} width={330} height={14} rx={4} fill="#262e4a" />
        <rect x={8} y={94} width={8} height={240} fill="#262e4a" />
        <rect x={314} y={94} width={8} height={240} fill="#262e4a" />
        <rect x={16} y={100} width={298} height={170} fill="#7aa0c8" opacity={0.16} />
        <rect x={44} y={230} width={240} height={14} rx={4} fill="#3b2c28" />
        <rect x={58} y={244} width={8} height={52} fill="#2b2220" />
        <rect x={264} y={244} width={8} height={52} fill="#2b2220" />
      </g>
      {/* фонарь */}
      <g transform="translate(700 300) scale(1.25)">
        <rect x={-7} y={222} width={14} height={240} fill="#1c2236" />
        <path d="M0 224 q-4 -50 -46 -56" stroke="#1c2236" strokeWidth={11} fill="none" strokeLinecap="round" />
        <g transform="translate(-60 166) rotate(-6)">
          <rect x={-34} y={-8} width={78} height={22} rx={6} fill="#1c2236" />
          <path d="M-30 14 l12 20 l10 -8 l12 22 l10 -20 l12 14 l8 -16 l10 12 l8 -28z" fill="#ffe29a" opacity={0.55 + 0.45 * L} />
          <circle cx={5} cy={30} r={22} fill="url(#bulbGlow)" opacity={L} />
        </g>
        <path d="M-120 462 L-20 244 L20 244 L120 462Z" fill="url(#lampCone)" opacity={0.75 * L} />
      </g>
      {/* двойник в свете фонаря */}
      <g opacity={doubleOp} transform={`translate(620 590) scale(0.82)`}>
        <ellipse cx={0} cy={330} rx={120} ry={18} fill="#000" opacity={0.35} />
        <rect x={-52} y={120} width={44} height={210} rx={18} fill="#363642" />
        <rect x={10} y={120} width={44} height={210} rx={18} fill="#363642" />
        <path d="M-64 20 Q0 -8 64 20 L70 150 L-70 150Z" fill="#5470a6" />
        <circle cx={0} cy={-46} r={62} fill={SKIN} />
        <path d="M-62 -52 Q-56 -118 0 -120 Q56 -118 62 -52 Q0 -30 -62 -52Z" fill="#8a5230" />
        <circle cx={-20} cy={-52} r={7} fill="#26130a" />
        <circle cx={20} cy={-52} r={7} fill="#26130a" />
        <path d="M-22 -16 L22 -16" stroke="#b0604a" strokeWidth={5} strokeLinecap="round" />
        {palm > 0 && (
          <g opacity={palm} transform="translate(88 -20) scale(0.5) rotate(8)">
            <PalmOnGlass x={0} y={0} scale={1} />
          </g>
        )}
      </g>
    </g>
  );
};

/** Светящиеся следы в темноте (для сцены с шагами). */
export const GhostSteps: React.FC<{count: number}> = ({count}) => {
  const frame = useCurrentFrame();
  const spots: [number, number, number][] = [[560, 980, 0.5], [505, 1120, 0.66], [575, 1280, 0.85], [505, 1460, 1.05], [585, 1650, 1.28]];
  return (
    <g>
      {spots.map(([px, py, s], i) => {
        const app = clamp((count - i) * 1.5);
        const pulse = 0.75 + 0.25 * Math.sin((frame - i * 22) / 9);
        return (
          <g key={i} opacity={app * pulse}>
            <ellipse cx={px} cy={py} rx={110 * s} ry={48 * s} fill="#8fb6ff" opacity={0.22} />
            <g transform={`translate(${px} ${py}) scale(${s * 1.5} ${s * 0.62})`}>
              <WetPrint glow={0.5} frame={frame + i * 11} />
            </g>
          </g>
        );
      })}
    </g>
  );
};

export const Part3Defs = () => (
  <defs>
    <linearGradient id="fogG" x1="0" y1="0" x2="0.4" y2="1">
      <stop offset="0" stopColor="#d3deee" stopOpacity={0.88} />
      <stop offset="0.5" stopColor="#aebfd8" stopOpacity={0.92} />
      <stop offset="1" stopColor="#93a7c4" stopOpacity={0.95} />
    </linearGradient>
    <radialGradient id="flashG">
      <stop offset="0" stopColor="#eaf4ff" stopOpacity={0.5} />
      <stop offset="0.55" stopColor="#cfe2ff" stopOpacity={0.22} />
      <stop offset="1" stopColor="#cfe2ff" stopOpacity={0} />
    </radialGradient>
    <linearGradient id="beamG" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stopColor="#eaf4ff" stopOpacity={0.5} />
      <stop offset="0.65" stopColor="#cfe2ff" stopOpacity={0.16} />
      <stop offset="1" stopColor="#cfe2ff" stopOpacity={0} />
    </linearGradient>
    <radialGradient id="stingG">
      <stop offset="0" stopColor="#8fb6ff" stopOpacity={0.5} />
      <stop offset="1" stopColor="#8fb6ff" stopOpacity={0} />
    </radialGradient>
  </defs>
);

export {cl};
