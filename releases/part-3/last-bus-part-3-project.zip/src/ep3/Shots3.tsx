import React from 'react';
import {useCurrentFrame, useVideoConfig, spring} from 'remotion';
import {Hero} from '../components/Hero';
import {BusWall, SeatFronts, BusFront, InteriorDefs} from '../components/Interior';
import {PhoneDefs} from '../components/Phone';
import {Vignette} from '../components/Overlays';
import {AisleView} from '../components/Aisle';
import {phoneSprite, Stage, lk} from '../scenes/parts';
import {CloseBg} from '../scenes/Shots';
import {camT, clamp, lin, ramp, useT, SKIN} from '../common';
import {E3} from './story3';
import {CreepySmile, FingerHand, PalmOnGlass, DriverFront, MirrorCloseUp, FloorPrints, FlashBeam, StopAhead, GhostSteps, Part3Defs, cl} from './Parts3';

type P = {t0: number};
type Cam = [number, number, number, number][];

/** Салон + часть 3 определения */
export const Stage3: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0}}>
    <InteriorDefs /><PhoneDefs /><Part3Defs />
    {children}
    <Vignette />
  </svg>
);

/* ---------- общий вид салона вдоль стены ---------- */
type WV3P = {
  t: number; cam: Cam; heroX?: number; heroY?: number; face?: any; face2?: any; mix?: number;
  look?: [number, number]; turn?: number; tilt?: number; prints?: {a?: number; b?: number}; printGlow?: string;
  windowOverlay?: React.ReactNode; doorOutside?: React.ReactNode; doorOpen?: number; lights?: number; dim?: number;
  streetX?: number; vib?: number; armR?: number; elbowR?: number; mouthNode?: React.ReactNode; blinkOnce?: number;
  heroScale?: number; extraArmR?: React.ReactNode; noArmR?: boolean; noHandR?: boolean; bodyBob?: number;
};
export const WV3: React.FC<WV3P> = ({t, cam, heroX = 700, heroY = 1500, face = 'worried', face2, mix = 0, look = [0, 0], turn = 0, tilt = 0,
  prints = {a: 1, b: 1}, printGlow, windowOverlay, doorOutside, doorOpen = 1, lights = 1, dim = 0, streetX = 2311, vib = 0,
  armR = 84, elbowR = 7, mouthNode, blinkOnce = 0, heroScale = 1.15, extraArmR, noArmR = false, noHandR = false, bodyBob = 0}) => {
  const frame = useCurrentFrame();
  const sh = vib > 0 ? Math.sin(frame * 2.3) * 1.6 * vib : 0;
  return (
    <Stage3>
      <g transform={camT(t, cam)}>
        <g transform={`translate(0 ${sh})`}>
          <BusWall streetX={streetX} doorOpen={doorOpen} doorOutside={doorOutside} lights={lights} windowOverlay={windowOverlay} />
          <SeatFronts />
          <Hero id="h3" x={heroX} y={heroY} scale={heroScale} anchor={[505, 930]} armL={84} armR={armR} elbowR={elbowR}
            face={face} face2={face2} faceMix={mix} look={look} turn={turn} tilt={tilt}
            prints={prints} printGlow={printGlow as any} mouthNode={mouthNode} blinkOnce={blinkOnce}
            extraArmR={extraArmR} noArmR={noArmR} noHandR={noHandR} bodyBob={bodyBob} />
          {dim > 0 && <rect x={-400} y={-900} width={2500} height={3600} fill="#040714" opacity={dim} />}
        </g>
      </g>
    </Stage3>
  );
};

/* ---------- крупный план героя ---------- */
const CloseUp3: React.FC<{t: number; cam?: Cam; face?: any; face2?: any; mix?: number; look?: [number, number];
  turn?: number; tilt?: number; mouthNode?: React.ReactNode; blinkOnce?: number; prints?: {a?: number; b?: number};
  tremble?: number; scale?: number; ghostText?: React.ReactNode}> = ({t, cam, face = 'worried', face2, mix = 0, look = [0, 0],
  turn = 0, tilt = 0, mouthNode, blinkOnce = 0, prints = {a: 1, b: 1}, tremble = 0.8, scale = 2.2, ghostText}) => (
  <Stage3>
    <CloseBg t={t} />
    <g transform={cam ? camT(t, cam) : undefined}>
      <Hero id="hz3" x={540} y={880} scale={scale} anchor={[505, 300]} legs={false} face={face} face2={face2} faceMix={mix}
        look={look} turn={turn} tilt={tilt} armL={80} armR={80} prints={prints} mouthNode={mouthNode} blinkOnce={blinkOnce}
        bodyBob={Math.sin(t * 50) * tremble} />
      {ghostText}
    </g>
  </Stage3>
);

/* ---------- двойник с произвольной рукой ---------- */
const DoubleArm: React.FC<{
  x: number; y: number; k?: number; smileG?: number; face?: any; hand?: React.ReactNode;
  handAt?: [number, number]; handRot?: number; armFrom?: 'r' | 'l'; shade?: number; look?: [number, number];
}> = ({x, y, k = 0.55, smileG = 0, face = 'calm', hand, handAt = [0, 0], handRot = 0, armFrom = 'r', shade = 0, look = [0, 0]}) => {
  const [hx, hy] = handAt;
  const sx = x + (armFrom === 'r' ? 69 : -69) * k;
  const sy = y - 558 * k;
  const cx = (sx + hx) / 2 + (armFrom === 'r' ? 60 : -60) * k;
  const cy = (sy + hy) / 2 + 150 * k;
  return (
    <g>
      <Hero id="dbl3" x={x} y={y} scale={k} anchor={[505, 930]} face={face} look={look} shade={shade}
        mouthNode={smileG > 0 ? <CreepySmile grow={smileG} /> : undefined} noArmR={!!hand} legs stain={false} />
      {hand && (
        <g>
          <path d={`M${sx} ${sy} Q${cx} ${cy} ${hx} ${hy}`} stroke="#5470a6" strokeWidth={76 * k} strokeLinecap="round" fill="none" />
          <path d={`M${sx} ${sy + 26 * k} Q${cx} ${cy + 26 * k} ${hx} ${hy}`} stroke="#3a5287" strokeWidth={16 * k} strokeLinecap="round" fill="none" opacity={0.35} />
          <g transform={`translate(${hx} ${hy}) rotate(${handRot})`}>{hand}</g>
        </g>
      )}
    </g>
  );
};

/** Остановка в миниатюре (в координатах окна/сцены), масштабируется для «удаления». */
const StopMini: React.FC<{x: number; y: number; s: number; lampLit: number; doubleOp: number; smileG?: number; fingers?: number | null}> =
  ({x, y, s, lampLit, doubleOp, smileG = 0, fingers = null}) => {
    const frame = useCurrentFrame();
    const fl = ((frame * 7919) % 17) < 2 ? 0.5 : 1;
    const L = lampLit * fl;
    return (
      <g transform={`translate(${x} ${y}) scale(${s})`}>
        {/* навес и скамейка */}
        <rect x={-260} y={-330} width={330} height={14} rx={4} fill="#262e4a" />
        <rect x={-252} y={-316} width={8} height={240} fill="#262e4a" />
        <rect x={62} y={-316} width={8} height={240} fill="#262e4a" />
        <rect x={-244} y={-310} width={298} height={170} fill="#7aa0c8" opacity={0.16} />
        <rect x={-216} y={-180} width={240} height={14} rx={4} fill="#3b2c28" />
        <rect x={-202} y={-166} width={8} height={52} fill="#2b2220" />
        <rect x={4} y={-166} width={8} height={52} fill="#2b2220" />
        {/* фонарь */}
        <g transform="translate(240 0)">
          <rect x={-7} y={-280} width={14} height={280} fill="#1c2236" />
          <path d="M0 -278 q-4 -50 -46 -56" stroke="#1c2236" strokeWidth={11} fill="none" strokeLinecap="round" />
          <g transform="translate(-60 -336) rotate(-6)">
            <rect x={-34} y={-8} width={78} height={22} rx={6} fill="#1c2236" />
            <path d="M-30 14 l12 20 l10 -8 l12 22 l10 -20 l12 14 l8 -16 l10 12 l8 -28z" fill="#ffe29a" opacity={0.55 + 0.45 * L} />
            <circle cx={5} cy={30} r={22} fill="url(#bulbGlow)" opacity={L} />
          </g>
          <path d="M-120 0 L-20 -258 L20 -258 L120 0Z" fill="url(#lampCone)" opacity={0.8 * L} />
          <ellipse cx={0} cy={4} rx={150} ry={20} fill="#ffc857" opacity={0.3 * L} />
        </g>
        {/* двойник */}
        <g opacity={doubleOp}>
          <DoubleArm x={120} y={4} k={0.62} smileG={smileG} face="calm"
            hand={fingers !== null ? <FingerHand up={fingers} /> : undefined}
            handAt={fingers !== null ? [210, -240] : [0, 0]} handRot={-18} />
        </g>
      </g>
    );
  };

/* ================= СЦЕНЫ ================= */

/** 1a: выбор зрителей, двери закрываются */
export const Choice: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const door = 1 - 0.85 * ramp(t, 4.35, 5.7);
  const vib = t > 5.2 ? Math.max(0, 1 - (t - 5.2) / 0.6) : 0;
  return (
    <WV3 t={t} cam={[[0, 640, 880, 0.98], [5.75, 620, 870, 1.06]]} heroX={700} face="scared" face2="worried" mix={cl(t, 2.2, 4.2)}
      look={[-0.85, 0]} turn={-0.35} doorOpen={door} vib={vib}
      doorOutside={<DoubleArm x={10} y={2} k={0.5} smileG={ramp(t, 2.8, 5.6)} hand={<PalmOnGlass x={0} y={0} scale={0.28} sleeve={false} />} handAt={[62, -148]} handRot={-24} />}
    />
  );
};

/** 1b: двойник слишком широко улыбается, ладонь на стекле */
export const Smile: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const g = ramp(t, 6.3, 11.6);
  return (
    <WV3 t={t} cam={[[5.75, 1230, 730, 1.32], [10.3, 1240, 710, 1.48], [12.35, 1255, 660, 1.78]]} heroX={860} face="worried" face2="scared"
      mix={cl(t, 8.6, 10.6)} look={[-0.9, -0.15]} turn={-0.55} prints={{a: 1, b: 1}}
      windowOverlay={
        <g>
          <DoubleArm x={1330} y={952} k={0.52} smileG={g} hand={<PalmOnGlass x={0} y={0} scale={0.5} sleeve={false} />} handAt={[1245, 628]} handRot={-12} />
          {/* мокрое стекло */}
          <rect x={620} y={340} width={1080} height={620} fill="#8fb6ff" opacity={0.05} />
        </g>
      } />
  );
};

/** 1c: крупный план ладони на стекле */
export const PalmGlassShot: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0c1734" />
      <rect x={0} y={0} width={1080} height={150} fill="#0b1124" />
      <rect x={0} y={1770} width={1080} height={150} fill="#0b1124" />
      <g transform={camT(t, [[12.35, 540, 960, 1.28], [15.5, 520, 930, 1.38]])}>
        <rect x={-200} y={120} width={1500} height={1700} fill="#12204a" />
        <rect x={-200} y={120} width={1500} height={1700} fill="url(#glassSheen)" />
        <g transform="rotate(-12 540 960)">
          <PalmOnGlass x={540} y={900} scale={1.55} />
        </g>
      </g>
    </Stage3>
  );
};

/** 2a: герой хотел спросить */
export const WantAsk: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return <CloseUp3 t={t} cam={[[15.5, 540, 950, 1.06], [18.95, 545, 930, 1.14]]} face="worried" look={[-0.85, 0.05]} turn={-0.35} tilt={-4} />;
};

/** 2b: автобус тронулся, двойник и остановка удаляются */
export const BusMoves: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const shrink = ramp(t, 19.6, 25.9);
  const s = 0.85 - 0.63 * shrink;
  const op = 1 - 0.4 * shrink;
  const slide = 90 * shrink;
  return (
    <WV3 t={t} cam={[[18.95, 1120, 820, 1.02], [26.1, 1080, 800, 1.1]]} heroX={880} face="worried" face2="scared" mix={cl(t, 20.2, 21.6)}
      look={[-0.95, 0]} turn={-0.6} streetX={2311 + 380 * ramp(t, 19.2, 26.1)}
      windowOverlay={
        <g opacity={op} transform={`translate(${slide} 0)`}>
          <StopMini x={1245} y={880} s={s} lampLit={1} doubleOp={1} smileG={0} fingers={null} />
        </g>
      } />
  );
};

/** 2c: фонарь гаснет */
export const LampOff: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const flick = t < E3.lampOff ? (Math.sin(t * 46) > 0.1 ? 1 : 0.3) : 0;
  const lit = t < E3.lampOff - 0.3 ? flick : 0;
  return (
    <WV3 t={t} cam={[[26.1, 1080, 800, 1.1], [28.95, 1100, 790, 1.16]]} heroX={880} face="scared" look={[-0.9, -0.1]} turn={-0.55}
      windowOverlay={
        <g transform="translate(0 0)">
          <StopMini x={1275} y={880} s={0.24} lampLit={lit} doubleOp={1 - 0.25 * (1 - lit)} smileG={0} fingers={null} />
        </g>
      } />
  );
};

/** 3a: фонарь снова горит — остановка прямо перед автобусом */
export const LampOn: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const lit = ramp(t, E3.lampOn - 0.25, E3.lampOn + 0.45);
  return (
    <Stage3>
      <g transform={camT(t, [[28.95, 540, 700, 1.0], [33.8, 540, 690, 1.06]])}>
        <BusFront doorOpen={0} />
        <defs>
          <clipPath id="ws3"><path d="M60 300 Q415 220 770 300 L790 1020 L40 1020Z" /></clipPath>
        </defs>
        <g clipPath="url(#ws3)">
          <StopAhead lampLit={lit} doubleOp={1} />
          <rect x={40} y={220} width={750} height={800} fill="#071022" opacity={0.55 * (1 - lit)} />
        </g>
      </g>
    </Stage3>
  );
};

/** 3b: та же скамейка, тот же фонарь, двойник не улыбается */
export const SameStop: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <WV3 t={t} cam={[[33.8, 1140, 780, 1.12], [40.15, 1150, 760, 1.22]]} heroX={880} face="worried" face2="scared" mix={cl(t, 38.4, 39.8)}
      look={[-0.95, 0.05]} turn={-0.6}
      windowOverlay={<StopMini x={1150} y={880} s={0.62} lampLit={1} doubleOp={1} smileG={0} fingers={null} />} />
  );
};

/** 3c: двойник поднимает руку — три пальца */
export const ThreeFingers: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const raise = ramp(t, E3.raiseHand - 0.2, E3.raiseHand + 1.4);
  return (
    <WV3 t={t} cam={[[40.15, 1220, 730, 1.32], [44.15, 1250, 640, 1.62]]} heroX={860} face="scared" look={[-0.95, -0.1]} turn={-0.6}
      windowOverlay={
        <DoubleArm x={1330} y={952} k={0.52} smileG={0} face="calm" look={[0, 0.1]}
          hand={<FingerHand up={3} />} handAt={[1245, 952 - 430 * raise]} handRot={-18 - 10 * raise} />
      } />
  );
};

/** 3d: загнул один — остаётся два */
export const FoldOne: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const fold = ramp(t, E3.foldOne + 0.25, E3.twoLeft - 0.1);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0c1734" />
      <rect width={1080} height={1920} fill="url(#glassSheen)" />
      <g transform={camT(t, [[44.15, 540, 900, 1.9], [46.85, 545, 880, 2.05]])}>
        <g transform="translate(540 980) rotate(-12)">
          <FingerHand up={2} foldT={fold} />
        </g>
      </g>
    </Stage3>
  );
};

/** 4a: герой бросается к водителю */
export const RunDriver: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const run = ramp(t, 46.95, 48.15);
  return (
    <WV3 t={t} cam={[[46.85, 800, 900, 1.05], [48.15, 560, 900, 1.14]]} heroX={820 - 330 * run} face="scared" look={[-1, 0.1]}
      turn={-0.75} bodyBob={Math.sin(t * 22) * 6 * run} vib={0.35} />
  );
};

/** 4b: в зеркале — моё лицо, глаза смотрят на меня */
export const MirrorEyes: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <Stage3>
      <g transform={camT(t, [[48.15, 480, 900, 1.18], [52.8, 415, 480, 2.1], [56.0, 415, 335, 3.6]])}>
        <BusFront doorOpen={0} mirrorFace={1} />
      </g>
    </Stage3>
  );
};

/** 4c: герой задаёт вопрос */
export const Question: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const speak = Math.max(0, Math.sin((t - E3.q) * 11)) * clamp((t - E3.q) / 0.3) * (1 - cl(t, E3.asked + 0.2, E3.asked + 0.6));
  return (
    <CloseUp3 t={t} cam={[[56.0, 545, 930, 1.12], [59.5, 540, 950, 1.2]]} face="worried" face2="surprised" mix={cl(t, 56.4, 57.2)}
      look={[0, 0.12]} mouthNode={
        <g>
          <ellipse cx={505} cy={281} rx={16 + 8 * speak} ry={4 + 10 * speak} fill="#5a2420" />
          <ellipse cx={505} cy={285 + 4 * speak} rx={9 + 4 * speak} ry={3 + 4 * speak} fill="#c4665a" />
        </g>
      } />
  );
};

/** 4d: водитель выключает свет */
export const LightsOut: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const flick = t > 62.35 && t < E3.lightsOut + 0.1 ? (Math.sin(t * 70) > 0 ? 1 : 0.3) : 1;
  const dim = 0.78 * ramp(t, E3.lightsOut, E3.lightsOut + 0.5);
  return (
    <Stage3>
      <g transform={camT(t, [[59.5, 540, 980, 1.06], [63.95, 520, 1000, 1.14]])}>
        <BusFront doorOpen={0} lights={flick} mirrorFace={0.85} />
        <rect x={-200} y={-200} width={1500} height={2400} fill="#040714" opacity={dim} />
      </g>
    </Stage3>
  );
};

/** 5a: в темноте слышны мокрые шаги */
export const DarkSteps: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const count = clamp((t - E3.step1 + 0.1) / 3.1) * 3 + clamp((t - E3.walking) / 2.2) * 2;
  return (
    <Stage3>
      <g transform={camT(t, [[63.95, 540, 820, 1.0], [71.4, 540, 810, 1.14]])}>
        <AisleView flicker={0.5} />
        <rect width={1080} height={1920} fill="#0a1430" opacity={0.22} />
        <GhostSteps count={count} />
      </g>
    </Stage3>
  );
};

/** 5b: фонарик на телефоне, луч выхватывает сиденья */
export const Flashlight: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const on = ramp(t, E3.flashlight, E3.flashlight + 0.18);
  const sweep = lk(t, [[71.6, -8], [75.4, 8]]);
  return (
    <Stage3>
      <g transform={camT(t, [[71.4, 700, 900, 1.05], [75.4, 640, 880, 1.12]])}>
        <AisleView flicker={0.25} />
        <rect width={1080} height={1920} fill="#060b1c" opacity={0.35} />
        <FlashBeam x={760} y={950} rot={180 + sweep} len={1250} spread={190} on={on} />
        {/* световое пятно на сиденьях */}
        <ellipse cx={310} cy={905} rx={260} ry={170} fill="#cfe2ff" opacity={0.20 * on} />
        <ellipse cx={310} cy={905} rx={150} ry={95} fill="#eaf4ff" opacity={0.16 * on} />
        {/* телефон в руке у правого края */}
        <g transform="translate(820 1000) rotate(-24)">
          <rect x={-120} y={-60} width={170} height={120} rx={46} fill={SKIN} />
          <g transform="translate(-120 -40) rotate(12)">{phoneSprite(0, 1)}</g>
        </g>
      </g>
    </Stage3>
  );
};

/** 5c: на полу появляются мокрые следы */
export const FloorPrintsShot: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const count = ramp(t, E3.prints - 0.3, E3.prints + 0.6) + ramp(t, E3.printsMore - 0.2, E3.printsMore + 0.5)
    + ramp(t, E3.approach - 0.6, E3.approach + 0.4) * 3;
  return (
    <Stage3>
      <g transform={camT(t, [[75.4, 540, 1100, 1.0], [80.55, 540, 1180, 1.1]])}>
        <FloorPrints count={count} beam={1} />
      </g>
    </Stage3>
  );
};

/** 6a: отступил и ударился спиной о поручень */
export const BackRail: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const move = ramp(t, E3.stepBack - 0.15, E3.hitRail + 0.1);
  const bump = Math.max(0, 1 - Math.abs(t - (E3.hitRail + 0.35)) / 0.24);
  const x = 760 - 214 * move + 12 * bump;
  return (
    <Stage3>
      <g transform={camT(t, [[80.55, 620, 900, 1.02], [84.0, 560, 900, 1.1]])}>
        <BusWall streetX={2311} lights={0.22} />
        <SeatFronts />
        {/* поручень: вертикальная стойка от пола до потолка */}
        <g>
          <rect x={396} y={340} width={30} height={1150} rx={15} fill="#8c93a8" />
          <rect x={396} y={340} width={10} height={1150} fill="#b4bad0" opacity={0.5} />
          <rect x={376} y={420} width={70} height={26} rx={12} fill="#6f7690" />
          <rect x={376} y={1240} width={70} height={26} rx={12} fill="#6f7690" />
        </g>
        <Hero id="rail3" x={x} y={1500} scale={1.15} anchor={[505, 930]} armL={84} armR={54} elbowR={-58}
          face="scared" look={[0.9, 0]} turn={0.55} tilt={6 * bump} prints={{a: 1, b: 1}}
          extraArmR={<g transform="translate(-10 -60) rotate(20)">{phoneSprite(0, 0.9)}</g>} bodyBob={-4 * bump} />
        <rect x={-400} y={-900} width={2500} height={3600} fill="#040714" opacity={0.25} />
      </g>
    </Stage3>
  );
};

/** 6b: шаги остановились совсем рядом */
export const StepsStop: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const last = ramp(t, 84.15, 84.55);
  return (
    <Stage3>
      <g transform={camT(t, [[84.0, 520, 1450, 1.28], [86.1, 505, 1500, 1.4]])}>
        <FloorPrints count={5.2 + last} beam={1} />
        <g opacity={last}>
          <ellipse cx={640} cy={1620} rx={150} ry={60} fill="#8fb6ff" opacity={0.12} />
        </g>
      </g>
    </Stage3>
  );
};

/** 7a: отражение в окне за спиной героя */
export const WindowRefl: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const app = ramp(t, E3.refl + 0.4, E3.refl + 1.6);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0a1226" />
      {/* окно */}
      <rect x={70} y={240} width={940} height={1120} rx={40} fill="#0b1124" />
      <clipPath id="reflWin"><rect x={110} y={280} width={860} height={1040} rx={26} /></clipPath>
      <g clipPath="url(#reflWin)">
        <rect x={110} y={280} width={860} height={1040} fill="#12204a" />
        <rect x={110} y={280} width={860} height={1040} fill="url(#glassSheen)" />
        {/* отражение героя — стоит «за спиной», чуть в стороне от физически верного места */}
        <g opacity={0.42 + 0.3 * app}>
          <Hero id="refl3" x={520 + 110 * (1 - app * 0.35)} y={1240} scale={1.05} anchor={[505, 930]} legs
            face="calm" look={[0.3, 0.12]} turn={0.15} shade={0.3} shadeColor={[0.25, 0.45, 0.85]} prints={{a: 1, b: 1}}
            armR={84 - 30 * ramp(t, E3.reflArm - 0.2, E3.reflArm + 1.2)}
            elbowR={7 - 70 * ramp(t, E3.reflArm - 0.2, E3.reflArm + 1.2)} />
          {/* стрелка-указание */}
          <g opacity={ramp(t, E3.point - 0.4, E3.point + 0.3)}>
            <path d={`M330 800 L210 740`} stroke="#8fb6ff" strokeWidth={10} strokeLinecap="round" opacity={0.5} />
            <path d={`M222 730 l34 6 l-24 20z`} fill="#8fb6ff" opacity={0.5} />
          </g>
        </g>
      </g>
      <rect x={110} y={280} width={860} height={1040} rx={26} fill="none" stroke="#2a3556" strokeWidth={16} />
      {/* настоящий герой — лицом к окну (вид со спины-сбоку), руки вниз */}
      <Hero id="real3" x={830} y={1620} scale={1.42} anchor={[505, 930]} legs face="worried" look={[-0.6, 0.2]}
        turn={-0.75} tilt={-6} prints={{a: 1, b: 1}} armR={80} />
    </Stage3>
  );
};

/** 7b: отражение указывает на зеркало водителя */
export const ReflPoints: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const raise = ramp(t, 92.2, 93.6);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0a1226" />
      <rect x={70} y={240} width={940} height={1120} rx={40} fill="#0b1124" />
      <clipPath id="reflWin2"><rect x={110} y={280} width={860} height={1040} rx={26} /></clipPath>
      <g clipPath="url(#reflWin2)">
        <rect x={110} y={280} width={860} height={1040} fill="#12204a" />
        <rect x={110} y={280} width={860} height={1040} fill="url(#glassSheen)" />
        <g opacity={0.72}>
          <Hero id="refl3b" x={560} y={1240} scale={1.05} anchor={[505, 930]} legs face="calm" look={[0.4, 0.1]} turn={0.2}
            shade={0.3} shadeColor={[0.25, 0.45, 0.85]} prints={{a: 1, b: 1}}
            armR={84 - 88 * raise} elbowR={7 - 66 * raise} />
          <g opacity={ramp(t, E3.point - 0.3, E3.point + 0.4)}>
            <path d="M330 770 L200 706" stroke="#8fb6ff" strokeWidth={11} strokeLinecap="round" opacity={0.55} />
            <path d="M212 694 l36 8 l-26 22z" fill="#8fb6ff" opacity={0.55} />
          </g>
        </g>
      </g>
      <rect x={110} y={280} width={860} height={1040} rx={26} fill="none" stroke="#2a3556" strokeWidth={16} />
      <Hero id="real3b" x={830} y={1620} scale={1.42} anchor={[505, 930]} legs face="worried" look={[-0.7, 0.15]}
        turn={-0.75} tilt={-6} prints={{a: 1, b: 1}} armR={80} />
    </Stage3>
  );
};

/** 8a: положение зеркала в автобусе, стекло запотевает */
export const MirrorPos: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const fog = ramp(t, 96.7, 98.05);
  return (
    <Stage3>
      <g transform={camT(t, [[96.35, 540, 800, 1.35], [98.05, 415, 420, 2.4]])}>
        <BusFront doorOpen={0} mirrorFace={0.9} />
        <g opacity={fog}>
          <rect x={301} y={282} width={228} height={96} rx={14} fill="#b9c8dd" opacity={0.75} />
        </g>
      </g>
    </Stage3>
  );
};

/** 8b: крупный план надписи на запотевшем стекле */
export const MirrorMsg: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const textOp = ramp(t, E3.wordsIn + 0.15, E3.msgB + 0.35);
  return (
    <Stage3>
      <g transform={camT(t, [[98.05, 540, 750, 1.18], [100.75, 540, 760, 1.24]])}>
        <MirrorCloseUp textOp={textOp} gone={0} />
      </g>
    </Stage3>
  );
};

/** 8c: моргнул — надпись исчезла */
export const BlinkGone: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const blinkA = Math.max(0, Math.sin(clamp((t - E3.blink) / 0.42) * Math.PI));
  const ghostOp = 1 - ramp(t, E3.blink + 0.1, E3.blink + 0.5);
  return (
    <CloseUp3 t={t} cam={[[100.75, 540, 950, 1.14], [102.75, 540, 940, 1.2]]} face="scared" look={[-0.2, 0.1]} turn={-0.15}
      blinkOnce={blinkA}
      ghostText={
        <g opacity={ghostOp * 0.8}>
          <text x={540} y={420} textAnchor="middle" fontFamily="Inter" fontWeight={900} fontSize={72} fill="#22345c"
            opacity={0.75} style={{paintOrder: 'stroke', stroke: '#c7d5e8', strokeWidth: 6, strokeLinejoin: 'round'}}>
            НЕ ОТВЕЧАЙ ЕМУ
          </text>
        </g>
      } />
  );
};

/** 9a: водитель заговорил — голос звучит как мой */
export const DriverVoice: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <Stage3>
      <g transform={camT(t, [[102.75, 540, 980, 1.1], [109.85, 520, 940, 1.2]])}>
        <BusFront doorOpen={0} mirrorFace={1} />
      </g>
    </Stage3>
  );
};

/** 9b: почти ответил, но вспомнил предупреждение */
export const AlmostAnswer: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const open = ramp(t, E3.openMouth - 0.15, E3.openMouth + 0.35) * (1 - ramp(t, E3.remember - 0.1, E3.remember + 0.45));
  return (
    <CloseUp3 t={t} cam={[[109.85, 540, 940, 1.18], [114.55, 545, 930, 1.24]]} face="surprised" face2="scared"
      mix={cl(t, E3.remember, E3.remember + 0.6)} look={[0.15 - 0.95 * ramp(t, E3.remember - 0.1, E3.remember + 0.5), 0.1]}
      turn={-0.4 * ramp(t, E3.remember - 0.1, E3.remember + 0.5)}
      mouthNode={
        <g>
          <ellipse cx={505} cy={281} rx={15 + 10 * open} ry={3.5 + 11 * open} fill="#5a2420" />
          <ellipse cx={505} cy={285 + 5 * open} rx={8 + 4 * open} ry={2.5 + 4 * open} fill="#c4665a" />
        </g>
      } />
  );
};

/** 10a: автобус снова остановился у той же остановки */
export const StopAgain: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const grow = ramp(t, E3.stopAgain - 0.2, E3.stopAgain + 1.3);
  const vib = t < E3.stopAgain + 1.2 ? Math.max(0, 1 - Math.abs(t - E3.stopAgain) / 1.2) : 0;
  return (
    <WV3 t={t} cam={[[114.55, 1100, 800, 1.1], [121.05, 1140, 780, 1.18]]} heroX={880} face="scared" face2="worried" mix={cl(t, 118.2, 119.6)}
      look={[-0.95, 0]} turn={-0.6} vib={vib}
      windowOverlay={<StopMini x={1150} y={880} s={0.2 + 0.42 * grow} lampLit={1} doubleOp={1} smileG={0} fingers={null} />} />
  );
};

/** 10b: двойник держит поднятым один палец */
export const OneFinger: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0c1734" />
      <rect width={1080} height={1920} fill="url(#glassSheen)" />
      <g transform={camT(t, [[121.05, 540, 900, 1.85], [123.4, 545, 890, 1.98]])}>
        {/* эхо прошлых жестов */}
        <g opacity={0.22} transform="translate(-90 40) rotate(-6)"><FingerHand up={3} /></g>
        <g opacity={0.34} transform="translate(-46 22) rotate(-3)"><FingerHand up={2} /></g>
        <g transform="translate(540 950) rotate(-12)"><FingerHand up={1} /></g>
      </g>
    </Stage3>
  );
};

/** 11a: свет мигнул, в зеркале водитель улыбается */
export const LightFlick: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const flick = t < 124.4 ? (Math.sin(t * 60) > -0.2 ? 1 : 0.25) : 1;
  const smileG = ramp(t, 124.6, 126.6);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#08101f" />
      <g opacity={flick}>
        <g transform={camT(t, [[123.4, 540, 760, 1.02], [127.25, 540, 770, 1.08]])}>
          <MirrorCloseUp textOp={0} gone={1} fog={0.55}
            faceNode={
              <g transform="translate(540 1030) scale(2.0)">
                <DriverFront x={0} y={0} scale={1} turn={1} smile={smileG} look={[0, 0.05]} />
              </g>
            } />
        </g>
      </g>
    </Stage3>
  );
};

/** 11b: прямой взгляд — лицо водителя неподвижно */
export const FaceStill: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0b1226" />
      <rect x={0} y={1420} width={1080} height={500} fill="#0d1328" />
      <g transform={camT(t, [[127.25, 540, 820, 1.16], [130.1, 540, 810, 1.24]])}>
        <DriverFront x={540} y={1080} scale={1.7} turn={1} smile={0} keyT={0} look={[0, 0]} />
      </g>
    </Stage3>
  );
};

/** 12a: голос из пустого прохода */
export const EmptyVoice: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <Stage3>
      <g transform={camT(t, [[130.1, 540, 800, 1.0], [137.05, 540, 790, 1.12]])}>
        <AisleView flicker={0.35} />
        <rect width={1080} height={1920} fill="#0a1430" opacity={0.18} />
      </g>
    </Stage3>
  );
};

/** 12b: водитель медленно повернулся ко мне */
export const DriverTurns: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const turn = ramp(t, E3.turn - 0.2, E3.turn + 1.1);
  return (
    <Stage3>
      {t < E3.turn + 0.15 ? (
        <g transform={camT(t, [[137.05, 540, 980, 1.12], [140.15, 520, 950, 1.2]])}>
          <BusFront doorOpen={0} headTurn={16 * turn} />
        </g>
      ) : (
        <g transform={camT(t, [[137.05, 540, 850, 1.1], [140.15, 540, 840, 1.16]])}>
          <rect width={1080} height={1920} fill="#0b1226" />
          <DriverFront x={540} y={1030} scale={1.55} turn={0.22 + 0.78 * turn} smile={0} keyT={0} look={[0, 0.05]} />
        </g>
      )}
    </Stage3>
  );
};

/** 12c: в руке ключ от дверей */
export const KeyHandShot: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0b1226" />
      <circle cx={540} cy={900} r={700} fill="url(#stingG)" opacity={0.35} />
      <g transform={camT(t, [[140.15, 540, 900, 1.0], [142.0, 545, 880, 1.08]])}>
        {/* кисть с ключом крупно */}
        <g transform="translate(540 920)">
          <path d="M-150 -300 Q-110 -120 -80 -20 L140 -20 Q120 -160 60 -300Z" fill="#2b3250" />
          <ellipse cx={20} cy={60} rx={150} ry={180} fill={SKIN} />
          {[-88, -30, 30, 88].map((fx) => <rect key={fx} x={fx - 30} y={170} width={62} height={150} rx={31} fill={SKIN} stroke="#a3836e" strokeWidth={3} />)}
          <g transform="translate(20 20) rotate(-12)">
            <circle cx={-110} cy={0} r={96} fill="none" stroke="#d8c27a" strokeWidth={38} />
            <rect x={-24} y={-26} width={264} height={52} rx={22} fill="#d8c27a" stroke="#8a7a3a" strokeWidth={5} />
            <rect x={162} y={22} width={38} height={62} rx={10} fill="#d8c27a" stroke="#8a7a3a" strokeWidth={5} />
            <rect x={88} y={22} width={34} height={50} rx={10} fill="#d8c27a" stroke="#8a7a3a" strokeWidth={5} />
          </g>
        </g>
      </g>
    </Stage3>
  );
};

/** 13: финал — напряжённый выбор */
export const Final3: React.FC<P> = ({t0}) => {
  const t = useT(t0);
  const smileG = ramp(t, 148.5, 154.5) * 0.5;
  return (
    <Stage3>
      <rect width={1080} height={1920} fill="#0b1226" />
      <rect x={0} y={1560} width={1080} height={360} fill="#0d1328" />
      <circle cx={540} cy={700} r={760} fill="url(#stingG)" opacity={0.3} />
      <g transform={camT(t, [[142.0, 540, 900, 1.02], [155.6, 545, 880, 1.1]])}>
        <DriverFront x={520} y={1060} scale={1.62} turn={1} smile={smileG} keyT={1} look={[0.12, 0.08]} />
        {/* плечо героя впереди */}
        <g>
          <path d="M760 1920 Q800 1560 1080 1520 L1080 1920Z" fill="#5470a6" />
          <path d="M800 1660 Q900 1600 1030 1590" stroke="#3a5287" strokeWidth={26} fill="none" opacity={0.5} />
          <g transform="translate(920 1620) rotate(12) scale(1.1)">
            <ellipse cx={0} cy={0} rx={30} ry={31} fill="#243f78" opacity={0.72} />
            {[[-23, 22, 34], [-8, 26, 42], [8, 26, 40], [23, 22, 31]].map(([fx, fy, fl], i) => <rect key={i} x={fx - 7} y={fy} width={14} height={fl} rx={7} fill="#243f78" opacity={0.72} />)}
          </g>
        </g>
      </g>
    </Stage3>
  );
};

export const SHOTS3_COMPONENTS: Record<string, React.FC<P>> = {
  choice: Choice, smile: Smile, palmGlass: PalmGlassShot, wantAsk: WantAsk, busMoves: BusMoves, lampOff: LampOff,
  lampOn: LampOn, sameStop: SameStop, threeFingers: ThreeFingers, foldOne: FoldOne, runDriver: RunDriver,
  mirrorEyes: MirrorEyes, question: Question, lightsOut: LightsOut, darkSteps: DarkSteps, flashlight: Flashlight,
  floorPrints: FloorPrintsShot, backRail: BackRail, stepsStop: StepsStop, windowRefl: WindowRefl, reflPoints: ReflPoints,
  mirrorPos: MirrorPos, mirrorMsg: MirrorMsg, blinkGone: BlinkGone, driverVoice: DriverVoice, almostAnswer: AlmostAnswer,
  stopAgain: StopAgain, oneFinger: OneFinger, lightFlick: LightFlick, faceStill: FaceStill, emptyVoice: EmptyVoice,
  driverTurns: DriverTurns, keyHand: KeyHandShot, final: Final3,
};
