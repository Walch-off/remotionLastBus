import words from '../data/words3.json';
export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const DURATION3 = 155.6; // озвучка 153.47 с + ~2.1 с финального экрана
export const TOTAL3 = Math.round(DURATION3 * FPS);
export type Word = {text: string; s: number; e: number};
export const WORDS3 = words as Word[];
const w = (i: number) => WORDS3[i].s;
/** Ключевые события — из выровненных таймкодов слов (индексы в words3.json) */
export const E3 = {
  doorsClosed: w(14), smile: w(18), smileWide: w(24), palmGlass: w(27), glass: w(32),
  wantAsk: w(34), move: w(43), smaller: w(60), lampOff: w(66), lampOn: w(70), sameBench: w(78),
  noSmile: w(94), raiseHand: w(97), three: w(102), foldOne: w(105), twoLeft: w(107),
  run: w(110), mirror: w(114), mirrorFace: w(120), eyesMe: w(124), q: w(132), asked: w(138),
  noAnswer: w(142), lightsOut: w(146), dark: w(151), step1: w(156), step2: w(157), step3: w(158),
  walking: w(159), flashlight: w(167), beam: w(171), seats: w(174), prints: w(178), printsMore: w(180),
  approach: w(185), stepBack: w(187), hitRail: w(189), rail: w(192), stepsStop: w(194), nearby: w(196),
  refl: w(201), reflThere: w(205), behind: w(208), faceWin: w(213), reflArm: w(217), point: w(221),
  mirrorWord: w(223), fogged: w(226), wordsIn: w(228), msgA: w(230), msgB: w(232), blink: w(234),
  msgGone: w(237), speaks: w(241), myVoice: w(247), qName: w(248), name: w(254), openMouth: w(257),
  remember: w(260), warn: w(261), moment: w(267), stopAgain: w(270), window: w(272), sameStop: w(275),
  watching: w(278), held: w(282), one: w(284), finger: w(285), flick: w(287), mirrorSmile: w(291),
  looked: w(295), still: w(302), empty: w(306), voice2: w(309), breakIt: w(311), until: w(313),
  memorized: w(317), drvWord: w(318), turn: w(320), inHand: w(325), key: w(327), whatDo: w(330),
  opt1: w(333), opt2: w(336), choose: w(338), decide: w(343), banner: w(347), part4: w(349),
};
export type Shot3 = {id: string; a: number; b: number};
export const SHOTS3: Shot3[] = [
  {id: 'choice', a: 0, b: 5.75},
  {id: 'smile', a: 5.75, b: 12.35},
  {id: 'palmGlass', a: 12.35, b: 15.5},
  {id: 'wantAsk', a: 15.5, b: 18.95},
  {id: 'busMoves', a: 18.95, b: 26.1},
  {id: 'lampOff', a: 26.1, b: 28.95},
  {id: 'lampOn', a: 28.95, b: 33.8},
  {id: 'sameStop', a: 33.8, b: 40.15},
  {id: 'threeFingers', a: 40.15, b: 44.15},
  {id: 'foldOne', a: 44.15, b: 46.85},
  {id: 'runDriver', a: 46.85, b: 48.15},
  {id: 'mirrorEyes', a: 48.15, b: 56.0},
  {id: 'question', a: 56.0, b: 59.5},
  {id: 'lightsOut', a: 59.5, b: 63.95},
  {id: 'darkSteps', a: 63.95, b: 71.4},
  {id: 'flashlight', a: 71.4, b: 75.4},
  {id: 'floorPrints', a: 75.4, b: 80.55},
  {id: 'backRail', a: 80.55, b: 84.0},
  {id: 'stepsStop', a: 84.0, b: 86.1},
  {id: 'windowRefl', a: 86.1, b: 92.05},
  {id: 'reflPoints', a: 92.05, b: 96.35},
  {id: 'mirrorPos', a: 96.35, b: 98.05},
  {id: 'mirrorMsg', a: 98.05, b: 100.75},
  {id: 'blinkGone', a: 100.75, b: 102.75},
  {id: 'driverVoice', a: 102.75, b: 109.85},
  {id: 'almostAnswer', a: 109.85, b: 114.55},
  {id: 'stopAgain', a: 114.55, b: 121.05},
  {id: 'oneFinger', a: 121.05, b: 123.4},
  {id: 'lightFlick', a: 123.4, b: 127.25},
  {id: 'faceStill', a: 127.25, b: 130.1},
  {id: 'emptyVoice', a: 130.1, b: 137.05},
  {id: 'driverTurns', a: 137.05, b: 140.15},
  {id: 'keyHand', a: 140.15, b: 142.0},
  {id: 'final', a: 142.0, b: DURATION3},
];
export const XFADE = 5;
